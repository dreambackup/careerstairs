<?php
include('../../db/config.php');
session_start();
$appid = test_input($_GET['appid']);

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['recruiter'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$stmt = $db->prepare("SELECT * FROM recruiter_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	//now fetch the job details
	$count = 0;
	$stm = $db->prepare("SELECT id FROM jobs WHERE id = ? AND rec_username = ?");
	$stm->bind_param("ss",$appid,$_SESSION['userData']);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1)
	{
		$stm = $db->prepare("SELECT * FROM jobs WHERE id = ? AND rec_username = ?");
		$stm->bind_param("ss",$appid,$_SESSION['userData']);
		$stm->execute();
		$ress = $stm->get_result();
		$rowwed = $ress->fetch_assoc();
		$stm->free_result();
	}
	else{
		header("Location: index.php");
	}

}
else{
	header('Location: ../../login.php');
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $rowwed['job_title'] ?> | Applications</title>

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css">

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="#">Post Job</a></li>
				<li><a href="manage-jobs.php" id="current">Manage Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-retweet"></i> <?php echo $rowwed['job_title'] ?> Applications </h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25" style="float: left;">The job applications for <strong><a <?php echo 'href="job-overview.php?id='.$appid.'"';?> target="_blank" > <?php echo $rowwed['job_title'] ?></a></strong> are listed below.</p>
		
		<div class="skills" style="float: right;margin-top: 0;margin-bottom: 10px">
				<p>Selected<span id="selected" style="background-color: lightseagreen">0</span></p>
				<p>Rejected<span id="rejected" style="background-color: crimson">0</span></p>
				<p>Pending <span id="pending" >0</span></p>
		</div>
		
		
	</div>

	<!-- Applications -->
	<div class="sixteen columns">

	<!--start query -->
	<?php 
		$user = json_decode($rowwed['applied_id']);
		$user_count = count($user);
		for($i=0;$i<$user_count;$i++)
			$users[$i] = $user[$i][0];
			
			$pending = 0;
			$selected = 0;
			$rejected = 0;
			
			
		if(!empty($user))
		{
			$count = 0;
			
			$stm = $db->prepare("SELECT id,oauth_provider,oauth_uid,name,email,phone,picture FROM users_login WHERE id IN (".implode(",", $users).") ");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				//now get the skills and title according to id
				$stm = $db->prepare("SELECT title FROM users_profile WHERE username = ?");
				$stm->bind_param("s",$rim['oauth_uid']);
				$stm->execute();
				$title = $stm->get_result()->fetch_object()->title;
				$stm->free_result();
				//title
				$stm = $db->prepare("SELECT skills FROM users_profile WHERE username = ?");
				$stm->bind_param("s",$rim['oauth_uid']);
				$stm->execute();
				$skill = $stm->get_result()->fetch_object()->skills;
				$stm->free_result();
				//skill
				$skills = json_decode($skill);
				
				if($rim['oauth_provider'] != 'normal')
					$picture = $rim['picture'];
				else
					$picture = "../user_pictures/".$rim['picture'];
				//will use counter to show details
				
				//get status
				
				for($i=0;$i<$user_count;$i++)
				{
					if($user[$i][0] == $rim['id'])
					{
						$status = $user[$i][1];
						
						if($status == 0)
						{
							$flag = 'Pending';
							$color = 'gray';
							$pending++;
						}
						else if($status == 1)
						{
							$flag = 'Selected';
							$color = 'green';
							$selected++;
						}
						else if($status == 2)
						{
							$flag = 'Rejected';
							$color = 'red';
							$rejected++;
							
						}
					}
				}
				
				echo '
				<div class="application">
			<div class="app-content">
				<!-- Name / Avatar -->
				<div class="info">
					<img src="'.$picture.'" alt="'.$rim['name'].'">
					<span id="name'.$rim['oauth_uid'].'">'.$rim['name'].'</span><span id="span'.$rim['oauth_uid'].'" style="font-size: 15px;color: '.$color.';padding-left: 10px">('.$flag.')</span>
					<ul>
						<li><a href="just_print.php?userid='.$rim['oauth_uid'].'" target="_blank"><i class="fa fa-file-text"></i> Download CV</a></li>
						<li><a href="mailto:'.$rim['email'].'"><i class="fa fa-envelope"></i> Mail</a></li>
						<li><a href="tel:'.$rim['phone'].'"><i class="fa fa-phone"></i>'.$rim['phone'].'</a></li>
					</ul>
				</div>
				
				<!-- Buttons -->
				<div class="buttons">
					<a href="view_profile.php?user='.$rim['oauth_uid'].'" class="button " target="_blank"><i class="fa fa-yelp" aria-hidden="true"></i> View Profile</a>
					<a href="#view-'.$count.'" class="button gray app-link"><i class="fa fa-plus-circle"></i> Show Details</a>
				</div>
				<div class="clearfix"></div>

			</div>

			<!--  Hidden Tabs -->
			<div class="app-tabs">
				<a href="#" class="close-tab button gray"><i class="fa fa-close"></i></a>
			    <!-- Third Tab -->
			    <div class="app-tab-content" id="view-'.$count.'">
					<div class="select-grid" style="float: right">';
						if($status == 0)
					  echo '<select data-placeholder="Application Status" class="chosen-select-no-single" id="select'.$count.'" onchange = swirl('.$count.',this,'.$rim['id'].',"'.$rim['oauth_uid'].'") >
								<option selected value="0">Application Status</option>
								<option value="1">Select</option>
								<option value="2">Reject</option>
							</select>';
						else if($status == 1)
							echo '<select data-placeholder="Application Status" class="chosen-select-no-single" id="select'.$count.'" onchange = swirl('.$count.',this,'.$rim['id'].',"'.$rim['oauth_uid'].'")>
								<option value="0">Application Status</option>
								<option selected value="1">Select</option>
								<option value="2">Reject</option>
							</select>';
						else if($status == 2)
							echo '<select data-placeholder="Application Status" class="chosen-select-no-single" id="select'.$count.'" onchange = swirl('.$count.',this,'.$rim['id'].',"'.$rim['oauth_uid'].'")>
								<option value="0">Application Status</option>
								<option value="1">Select</option>
								<option selected value="2">Reject</option>
							</select>';
					
					echo '<span style="float:right;display:none" id="status'.$count.'"></span></div>
					
					<i>Professional Title:</i>
					<span>'.$title.'</span>
					<i>Email:</i>
					<span>'.$rim['email'].'</span>
		    		<i>Skills:</i>
		    		<div class="skills">';
						for($i=0;$i<count($skills);$i++)
						{
							echo '<span>'.$skills[$i].'</span>';
						}
					echo '</div>
		    		<br/>
			    </div>
			</div>
		</div>
				';
				$count++;
			}
		}
		else
			echo '<h3>No one has applied for this job yet !</h3>';
			
	?>
		<!-- Application -->
		



	</div>
</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<script>
	var pending = '<?php echo $pending ?>';
	var selected = '<?php echo $selected ?>';
	var rejected = '<?php echo $rejected ?>';
	
	$(document).ready(function(){
	   $('#selected').text(selected);
	   $('#rejected').text(rejected);
	   $('#pending').text(pending);
	});
	
	function swirl(one,two,three,four)
	{
		var nine = $('#span'+four).text();
		var name = $('#name'+four).text();
		$.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:{value: two.value, id: three, username1: four, job_id: '<?php echo $appid  ?>', username2: '<?php echo $_SESSION['userData'] ?>'},
                success: function(dataParsed){
              		//console.log(dataParsed);
					if(dataParsed == 'Data')
					{
						if(two.value == 0){
							$('#span'+four).text('');
						$('#span'+four).attr('style','color: gray;font-size:15px;padding-left:10px');
							$('#span'+four).text('(Pending)');
							if(nine == '(Selected)')
								selected--;
							else if(nine == '(Rejected)')
								rejected--;
							pending++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
							
						}
						else if(two.value == 1){
						$('#span'+four).attr('style','color: green;font-size:15px;padding-left:10px');
							$('#span'+four).text('(Selected)');
							if(nine == '(Pending)')
								pending--;
							else if(nine == '(Rejected)')
								rejected--;
							selected++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
						}
						else if(two.value == 2){
							$('#span'+four).text('');
						$('#span'+four).attr('style','color: red;font-size:15px;padding-left:10px');
							$('#span'+four).text('(Rejected)');
							if(nine == '(Pending)')
								pending--;
							else if(nine == '(Selected)')
								selected--;
							rejected++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
						}
				
						swal(
						  'Response Saved !',
						  'Your response has been saved for User : '+name,
						  'success'
						)
						$('#status'+one).show();
						$('#status'+one).attr('style', 'color: green');
						$('#status'+one).text('Response Saved !');
					}
					else if(dataParsed != 'Data')
					{
						swal(
						  'Error',
						  dataParsed,
						  'error'
						)
					}
                }
            }); 
	}
	
	
</script>

</body>
</html>