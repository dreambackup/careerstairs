<?php
include('../../db/config.php');
error_reporting(0);
session_start();
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['recruiter'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$stmt = $db->prepare("SELECT * FROM recruiter_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	$date = date('Y-m-d',strtotime("+1 day"));
	$today = date('Y-m-d');
	$next_month = date('Y-m-d', strtotime("+30 day"));

	//getting hashed password
	$options = [
	'cost' => 11,
	];
	$link = password(10);
	$link_hash = password_hash($link, PASSWORD_BCRYPT, $options);
	
	//pending job post count
	$job_count = 0;

	$stm = $db->prepare("SELECT id FROM jobs WHERE rec_username = ? AND admin_verified = '0' AND CURRENT_DATE <= expiration ");
	$stm->bind_param("s",$_SESSION['userData']);
	$stm->execute();
	$stm->store_result();
	$job_count = $stm->num_rows;
	$stm->free_result();
	
}
else{
	header('Location: ../../login.php');
}
$email = $title = $location = $jobtype = $category = $skills = $about_job = $exper = $min_sal = $max_sal = $educations = $batch = $description = $close_date = $company_name = $company_website = $about_company = "";
$batch = ["2017"];
$min_sal = '0.5';
$max_sal = '10';
$exper = '0';
$locations = '["New Delhi"]';
$close_date = $date;
$skill = '["HTML"]';
$education='["B.Tech/B.E."]';
$category = 'Information Technology';
if(isset($_POST['save']))
{
if($job_count < 4){
	
	$err = "";
	$email = test_input(mb_strtolower($_POST["email"]));
	$title = test_input(ucname($_POST["title"]));
	$location = test_input($_POST["location"]);
	$jobtype = test_input($_POST['jobtype']);
	$category = test_input($_POST['category']);
	$skills = test_input($_POST["skills"]);
	$about_job = test_input($_POST["about_job"]);
	$exper = test_input($_POST["exper"]);
	$min_sal = test_input($_POST["min_sal"]);
	$max_sal = test_input($_POST["max_sal"]);
	$educations = test_input($_POST["educations"]);
	$batch = $_POST["batch"];
	$description = $_POST["description"];
	$close_date = test_input($_POST["close_date"]);
	$company_name = test_input($_POST["company_name"]);
	$company_website = test_input($_POST["company_website"]);
	$about_company = test_input($_POST["about_company"]);
	
	$tmp = explode('@', $email);
	$udomain = end($tmp);
	
 	$domains = array("aol.com", "gmail.com", "hotmail.com", "yahoo.com", "yahoo.co.uk", "email.com", "ymail.com","live.com", "msn.com");
	
	$allowed_type = array("Accounting / Finance","Software Developer","Marketing & Sales","Information Technology","Healthcare","Content & digital","UI / UX Developer","BPO & Telecomm","Management","Quality & Testing","Mobile App development","Hr & Company");
	
	//start validation
	if(isset($email) && !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)){
		//lets check domain
		if(!(in_array($udomain, $domains))) {
		}
		else
			$err = $err . "Public Email address are not allowed In Official Email </br>";
	}
	else
		$err = $err . "Invalid Email address inserted into Official Email </br>";
	
	if(isset($title) && !empty($title) && (strlen($title) <= 100) ){
	}
	else
		$err = $err . "Only Alphnumeric characters are allowed in Job Title (Max 100 Characters)</br>";
	
	if(isset($location) && !empty($location))
	{
		$temp_location = explode(",",$location);
		$location_count = count($temp_location);
		
		if($location_count > 5)
		{
			for($i=$location_count;$i>5;$i--)
			{
				array_pop($temp_location);
			}
		}
$locations = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($temp_location))));
	}
	else
		$err = $err . "Problem with location Input </br>";
	
	
	if(isset($jobtype) && !empty($jobtype)){
		if($jobtype == 'Full-Time' || $jobtype == 'Part-Time' || $jobtype == 'Internship' && $jobtype == 'Freelance'){
			if($jobtype == 'Full-Time'){
				$jobtypes = '1';
			}
			else if($jobtype == 'Part-Time'){
				$jobtypes = '2';
			}
			else if($jobtype == 'Internship'){
				$jobtypes = '3';
			}
			else if($jobtype == 'Freelance'){
				$jobtypes == '4';
			}
		}
		else
			$err = $err . "There is a Problem With Job Type </br>";
	}
	else
		$err = $err . "Job Type Input Cannot Be Empty </br>";
	
	if(isset($category) && !empty($category) && in_array($category,$allowed_type)){
	}
	else
		$err = $err . "Only these Categories are available to select </br>";
	
	if(isset($skills) && !empty($skills))
	{
		$temp_skills = explode(",",$skills);
		$skills_count = count($temp_skills);
		if($skills_count > 10)
		{
			for($i=$skills_count;$i>10;$i--)
			{
				array_pop($temp_skills);
			}
		}
	$skill = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($temp_skills))));
	}
	else
		$err = $err . "Problem with skills Input </br>";
	
	if(isset($about_job) && !empty($about_job) && (strlen($about_job)<1000)){
	}
	else
		$err = $err . "Only 1000 characters are allowed to fill the about job </br>";
	
	if(isset($exper) && $exper >= '0' && $exper <= '7'){
	}
	else
		$err = $err . "Experience of Max 7 years are allowed </br>";
	
	if(isset($min_sal) && !empty($min_sal)){
		if($min_sal >= '0.5'){
		}
		else
			$err = $err . "Minimum Salary Should be Greater than  0.5 LPA <br/>";
		if($min_sal < $max_sal){
		}
		else
			$err = $err . "Minimum Salary Should be Less than  Max Salary <br/>";
	}
	else
		$err = $err . "There is a problem with minimum salary <br/>";
	
	if(isset($max_sal) && !empty($max_sal)){
		if($min_sal < '15'){
		}
		else
			$err = $err . "Maximum Salary Should be Less than 15.0 LPA <br/>";
		if($min_sal < $max_sal){
		}
		else
			$err = $err . "Maximum Salary Should be Greater than  Min Salary <br/>";
	}
	else
		$err = $err . "There is a problem with Maximum salary <br/>";
	
	if(isset($educations) && !empty($educations))
	{
		$temp_educations = explode(",",$educations);
		$educations_count = count($educations);
		if($educations_count > 5)
		{
			for($i=$educations_count;$i>5;$i--)
			{
				array_pop($educations);
			}
		}
$education= json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($temp_educations))));
	}
	else
		$err = $err . "There is a Problem with Education Input </br>";
	
  if(isset($batch) && !empty($batch)){
		$batch_count = count($batch);
		
		for($i=0;$i<$batch_count;$i++)
		{
			if(($batch[$i] >= 2010) && ($batch[$i] <= (2017 - $exper))){
			}
			else
				$err = $err . "Problem with batch year Input </br>";
		}
	}
	else
		$err = $err . "Problem with batch year Input </br>";
	
	if(isset($description) && !empty($description) ){
$descriptions = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($description))));
	}
	else
		$err = $err . "Problem with Job Description </br>";
	
	if(isset($close_date) && !empty($close_date)){	
	}
	else
		$err = $err . "Problem with Job Expiration date </br>";
	
	if(isset($company_name) && !empty($company_name) && (strlen($company_name) < 255)){
	}
	else
		$err = $err . "Problem with Company Name </br>";
	
	if(isset($company_website) && !empty($company_website) && (strlen($company_website) < 100)){
	}
	else
		$err = $err . "Problem with Company Website </br>";
	
	if(isset($about_company) && !empty($about_company) && (strlen($about_company)<1000)){
	}
	else
		$err = $err . "Only 1000 characters are allowed to fill the about company </br>";
	
	//if email is not changed then just update the stuff
	//get image
	//starting profile pic coding
	$imgFile = $_FILES['file']['name'];
	$tmp_dir = $_FILES['file']['tmp_name'];
	$imgSize = $_FILES['file']['size'];
	
	if(isset($_SESSION['userpic']) && !empty($_SESSION['userpic'])){
	}
	if($imgFile)
  	{
   		$upload_dir = '../company_pictures/'; // upload directory 
		unlink($upload_dir.$_SESSION['userpic']);
   		$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
   		$valid_extensions = array('jpeg', 'jpg', 'png'); // valid extensions
   		$userpic = $_SESSION['userData'].$link.".".$imgExt;
   		if(in_array($imgExt, $valid_extensions)){   
   			if($imgSize < 500000){	// don't want to delete the default pic
				move_uploaded_file($tmp_dir,$upload_dir.$userpic);
				$_SESSION['userpic'] = $userpic;
    		}
    		else{
     			$err = "Sorry, Your Company Logo is too large it should be less then 500 Kb </br>";
    		}
   		}
   		else{
    		$err = "Sorry, only JPG, JPEG, PNG files are allowed.";  
   		} 
  	}
	else if(!isset($_SESSION['userpic']) && empty($_SESSION['userpic']))
		$err = $err . 'There is a Problem with Image </br>';
	
	if($err == ""){
		
		$flag = 0;
		
		if (($stmt = $db->prepare("INSERT INTO jobs(rec_username, rec_email, job_category, job_type, job_title, company_name, company_website, company_description, exp, package_min, package_max, location, job_details, company_pic, job_description, skills, education, batch, created, expiration) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)  "))) {
			if($stmt->bind_param("ssssssssssssssssssss",$_SESSION['userData'],$email,$category,$jobtypes,$title,$company_name,$company_website,$about_company,$exper,$min_sal,$max_sal,$locations,$about_job,$_SESSION['userpic'],$descriptions,$skill,$education,json_encode($batch),$today,$next_month)) {
				if ($stmt->execute()) {
					$last_id = $db->insert_id;
					if(($stmtt = $db->prepare("INSERT INTO verify_email(username, link,job_id, start_time, end_time) VALUES (?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP + INTERVAL '6:00' HOUR_MINUTE) "))){
						if($stmtt->bind_param("sss",$_SESSION['userData'],$link_hash,$last_id)){
							if($stmtt->execute()){
									$_SESSION['verify_email'] = true;
									$_SESSION['company_name'] = $company_name;
									$_SESSION['title'] = $title;
									$_SESSION['email'] = $email;
									$_SESSION['name'] = $row['name'];
									$_SESSION['ssl'] = $link_hash;
									$_SESSION['page'] = '../dashboard/recruiter/index.php';
									header("Location: ../../email/verify_email.php");	
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;

		if($flag == 1){
			$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>";
		}  	 
		
		
	}
	if($err != ""){
		echo '<script type="text/javascript">';
		echo 'setTimeout(function () { swal("Error !","'.$err.'","error");';
		echo '}, 100);</script>';
	}
}
	else {
		echo '<script type="text/javascript">';
		echo 'setTimeout(function () { swal("Warning !","You have already 3 pending job post and you need to wait for them to process !","warning");';
		echo '}, 100);</script>';
	}
	
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
//function to change the lowercase data to capitalize the first letter of every word
function ucname($string) {
    $string =ucwords(strtolower($string));

    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
//function to produce a random number password by using md5 algo
function password($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
{
    $str = '';
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $str .= $keyspace[random_int(0, $max)];
    }
  return $str;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Post Job</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css">
<link rel="stylesheet" href="../../css/custom.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<style>
.errspan {
    float: right;
    margin-right: 6px;
    margin-top: -40px;
    position: relative;
    z-index: 3;
	}

.range-slider {
    position: relative;
    height: 80px;
}
.extra-controls {
    position: relative;
    border-top: 3px solid #000;
    padding: 10px 0 0;
}

.inp {
    font-size: 18px;
    text-align: center;
    
}

	
.input-file-container {
  position: relative;
  width: 225px;
} 
.js .input-file-trigger {
  display: block;
  padding: 14px 45px;
  background: #39D2B4;
  color: #fff;
  font-size: 1em;
  transition: all .4s;
  cursor: pointer;
}
.js .input-file {
  position: absolute;
  top: 0; left: 0;
  width: 225px;
  opacity: 0;
  padding: 14px 0;
  cursor: pointer;
}
.js .input-file:hover + .input-file-trigger,
.js .input-file:focus + .input-file-trigger,
.js .input-file-trigger:hover,
.js .input-file-trigger:focus {
  background: #34495E;
  color: #39D2B4;
}

.file-return {
  margin: 0;
}
.file-return:not(:empty) {
  margin: 1em 0;
}
.js .file-return {
  font-style: italic;
  font-size: .9em;
  font-weight: bold;
}
.js .file-return:not(:empty):before {
  content: "Selected file: ";
  font-style: normal;
  font-weight: normal;
}

</style>
</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="Work Scout" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="post_job.php" id="current">Post Job</a></li>
				<li><a href="manage-jobs.php">Manage Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-external-link"></i> Post Job </h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Submit Page -->
	<div class="sixteen columns">
		<div class="submit-page">
		
		<div class="notification notice closeable margin-bottom-40">
				<p><span>Note: </span> After a successfull job post, a email will be sent with a verification link to your official email. If you do not verify the email within 6 hours then the job will be deleted !</p>
		</div>
		
		<?php if($job_count > 3) 
			echo '<script type="text/javascript">setTimeout(function(){ swal("Warning !" ,"You have already 3 pending job post and you need to wait for them to process !", "warning");}, 100);</script>';
		?>
		
		<form method="post" onsubmit="return checkSize(500000)" autocomplete="off" enctype="multipart/form-data">
			<!-- Email -->
			<div class="form">
				<h5>Official Email</h5>
				<input class="search-field" type="email" placeholder="mail@domain.com" required maxlength="255" id="email" required style="text-transform: lowercase;" onBlur="checkemail()" name="email" value="<?php echo $email ?>" />
				<div id="email-loading" class="errspan" >
                	<i id="email-i"></i>
                </div>
				<p class="note">The email should be official not to be of gmail, outlook, yahoo,  reddiff, aol, aim, yandex, protonmail etc</p>
			</div>

			<!-- Title -->
			<div class="form">
				<h5>Job Title</h5>
				<input class="search-field" type="text" placeholder="ex Web Developer" required title="Please Use only Alphabets with a Max length of 100 characters" name="title" style="text-transform: capitalize" value="<?php echo $title ?>"  />
				<p class="note">Enter job title like : Web Developer/Backend Developer/IOS Developer</p>
			</div>

			<!-- Location -->
			<div class="form">
				<h5>Location</h5>
				<input class="search-field" data-role="tagsinput" id="locations" type="text" placeholder="e.g. New Delhi" required name="location" value="<?php echo implode(",",json_decode($locations)) ?>"/>
				<p class="note">You can select multiple locations (Max 5)</p>
			</div>

			<!-- Job Type -->
			<div class="form">
				<h5>Job Type</h5>
				<select class="chosen-select-no-single" required name="jobtype">
					<option <?php echo ($jobtype == 'Full-Time')?"selected":"" ?>value="Full-Time">Full-Time</option>
					<option <?php echo ($jobtype == 'Part-Time')?"selected":"" ?>value="Part-Time">Part-Time</option>
					<option <?php echo ($jobtype == 'Internship')?"selected":"" ?>value="Internship">Internship</option>
					<option <?php echo ($jobtype == 'Freelance')?"selected":"" ?>value="Freelance">Freelance</option>
				</select>
			</div>


			<!-- Choose Category -->
			<div class="form">
				<div class="select">
					<h5>Category</h5>
					<select data-placeholder="Choose Categories" class="chosen-select" required name="category">
						<option value="">Select a Category</option>
						<option <?php echo ($category == 'Accounting / Finance')?"selected":"" ?> value="Accounting / Finance" >Accounting / Finance</option>
						<option <?php echo ($category == 'Software Developer')?"selected":"" ?> value="Software Developer" >Software Developer</option>
						<option <?php echo ($category == 'Marketing & Sales')?"selected":"" ?> value="Marketing & Sales">Marketing & Sales</option>
						<option <?php echo ($category == 'Information Technology')?"selected":"" ?> value="Information Technology">Information Technology</option>
						<option <?php echo ($category == 'Healthcare')?"selected":"" ?> value="Healthcare">Healthcare</option>
						<option <?php echo ($category == 'Content & digital')?"selected":"" ?> value="Content & digital">Content & digital</option>
						<option <?php echo ($category == 'UI / UX Developer')?"selected":"" ?> value="UI / UX Developer">UI / UX Developer</option>
						<option <?php echo ($category == 'BPO & Telecomm')?"selected":"" ?> value="BPO & Telecomm">BPO & Telecomm</option>
						<option <?php echo ($category == 'Management')?"selected":"" ?> value="Management">Management</option>
						<option <?php echo ($category == 'Quality & Testing')?"selected":"" ?> value="Quality & Testing">Quality & Testing</option>
						<option <?php echo ($category == 'Mobile App development')?"selected":"" ?> value="Mobile App development">Mobile App development</option>
						<option <?php echo ($category == 'Hr & Company')?"selected":"" ?> value="Hr & Company">Hr & Company</option>
					</select>
				</div>
			</div>

			<!-- Tags -->
			<div class="form">
				<h5>Job Tags</h5>
				<input type="text" data-role="tagsinput" id="skills" required name="skills" placeholder="ex html, css etc" value="<?php echo implode(",",json_decode($skill)) ?>" />
				<p class="note">You can select multiple tags for this job (Max 10)</p>
			</div>


			<!-- Description -->
			<div class="form">
				<h5>Job Description</h5>
				<textarea rows="10" style="resize:none" name="about_job" spellcheck="true" maxlength="1000" required placeholder="Enter about job role" ><?php echo $about_job ?></textarea>
			</div>

			<!-- Application email/url -->
			<div class="form">
				<h5>Experience</h5>
				<input class="search-field" type="number" min="0" max="6" value="<?php echo $exper ?>" onChange="exp(this.value)" name="exper" id="exper" >
			</div>
			
			<div class="form">
				<h5>Salary in LPA</h5>
				<div class="range-slider">
					<input type="text" class="js-range-slider" value="" />
				</div>
				<div class="extra-controls">
					<label style="display: inline; float: left">Min LPA</label>
					<label style="display: inline; float: right">Max LPA</label>
					<br/>
					<input type="number" max="15" min="0.5" step="0.1" value="<?php echo $min_sal ?>" class="inp js-from" style="display: inline; width: 100px" name="min_sal" />
					<input type="number" max="15" step="0.1" value="<?php echo $max_sal ?>" class="inp js-to" style="float: right; width: 100px" name="max_sal" />
				</div>
			</div>
			
			<div class="form">
				<h5>Education</h5>
				<input type="text" data-role="tagsinput" id="educations" name="educations" placeholder="ex B.E, M.tech, MCA" required value="<?php echo implode(",",json_decode($education)) ?>" >
				<p class="note">You are allowed to chose Max 5 Education degree</p>
			</div>
			
			
			<div class="form">
				<div class="select">
					<h5>Batch</h5>
					<select data-placeholder="Select Experience" class="chosen-select" multiple required id="batch" name="batch[]">
					<option <?php echo ($batch[0] == 2010)?"selected":"" ?> value="2010">2010</option>
					<option <?php if(($batch[0] == 2011 || $batch[1] == 2011 )) echo "selected"; ?> value="2011">2011</option>
					<option <?php if(($batch[0] == 2012 || $batch[1] == 2012 || $batch[2] == 2012 )) echo "selected"; ?> value="2012">2012</option>
					<option <?php if(($batch[0] == 2013 || $batch[1] == 2013 || $batch[2] == 2013 || $batch[3] == 2013 )) echo "selected"; ?> value="2013">2013</option>
					<option <?php if(($batch[0] == 2014 || $batch[1] == 2014 || $batch[2] == 2014 || $batch[3] == 2014 || $batch[4] == 2014)) echo "selected"; ?> value="2014">2014</option>
					<option <?php if(($batch[0] == 2015 || $batch[1] == 2015 || $batch[2] == 2015 || $batch[3] == 2015 || $batch[4] == 2015 || $batch[5] == 2015 )) echo "selected"; ?> value="2015">2015</option>
					<option <?php if(($batch[0] == 2016 || $batch[1] == 2016 || $batch[2] == 2016 || $batch[3] == 2016 || $batch[4] == 2016 || $batch[5] == 2017 || $batch[6] == 2016)) echo "selected"; ?> value="2016">2016</option>
					<option <?php if(($batch[0] == 2017 || $batch[1] == 2017 || $batch[2] == 2017 || $batch[3] == 2017 || $batch[4] == 2017 || $batch[5] == 2017 || $batch[6] == 2017 || $batch[7] == 2017)) echo "selected"; ?> value="2017">2017</option>
						
					</select>
				</div>
				<p class="note" id="batchnote" style="display: none"></p>
			</div>
			
			<div class="form">
				<h5>Job Skills and Expertise</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
						<h3 class="panel-title">*</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
								<!-- Adding dynamic boxes -->
							<div id="description">
				
								<?php 
								
								for($i=0;$i<count($description);$i++)
									echo '<div class="form boxed">
								<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
								<textarea required class="search-field" rows="2" style="resize: none" name="description[]" maxlength="255" placeholder="ex Integration of user-facing elements developed by a front-end developers with server side logic" title="Maxlength of 255">'.$description[$i].'</textarea></div>';
								?>
								
								
							</div>
							<a href="javascript:void(0)" onClick="addInput1('description');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
						</div>
					</div>
				</div>
			</div>
			
			<!-- TClosing Date -->
			<div class="form">
				<h5>Closing Date</h5>
				<input data-role="date" min="<?php echo $date ?>" max="<?php echo $next_month ?>" style="padding: 10px" type="date" placeholder="yyyy-mm-dd" name="close_date" value="<?php echo $close_date ?>">
				<p class="note">Deadline for new applicants with a max date of 1 month from now</p>
			</div>

			
			
			<!-- Company Details -->
			<div class="divider"><h3>Company Details</h3></div>

			<!-- Company Name -->
			<div class="form">
				<h5>Company Name</h5>
				<input type="text" placeholder="Enter the name of the company" maxlength="255" name="company_name" required value="<?php echo $company_name ?>">
			</div>

			<!-- Website -->
			<div class="form">
				<h5>Website <span>(Required)</span></h5>
				<input type="text" required placeholder="http://" name="company_website" maxlength="100" value="<?php echo $company_website ?>" >
			</div>

			<div class="form">
				<h5>About Company</h5>
				<textarea required maxlength="1000" placeholder="Write about company" rows="10" style="resize: none" name="about_company"><?php echo $about_company ?></textarea>
			</div>
	
			<!-- Logo -->
			<label class="fileContainer" for="file-input">Company Logo <span>(Required)</span></label>
				
				<div class="input-file-container"> 
   				
   				<?php
	
					if(isset($_SESSION['userpic']))
						echo '<input class="input-file" type="file" accept="image/*" onchange="loadFile(event)" id="upload" name="file">';
					else
						echo '<input class="input-file" type="file" accept="image/*" onchange="loadFile(event)" id="upload" name="file"  required>';

				?>
   				
    				<label tabindex="0" for="my-file" class="input-file-trigger" style="text-align: center">Select a file...</label>
  				</div>
  				<p class="file-return"></p>

			<?php
					
				if(isset($_SESSION['userpic']))
					echo '<img class="image" id="output" src="../company_pictures/'.$_SESSION['userpic'].'"';
				else
					echo '<img class="image" id="output" ';
			?>
			
			
			<div class="divider margin-top-0"></div>
			<button class="button big margin-top-5" type="submit" name="save">Submit <i class="fa fa-file-o"></i></button>
			<button class="button big margin-top-5" name="preview" type="submit" formaction="job_preview.php" formtarget="_blank" style="float: right">Preview <i class="fa fa-arrow-circle-right"></i></button>

			</form>
			
		</div>
	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>


<link rel="stylesheet" href="https://www.jqueryscript.net/demo/Customizable-Accessible-jQuery-Range-Slider-Plugin-asRange/dist/css/asRange.css">
<script src="https://www.jqueryscript.net/demo/Customizable-Accessible-jQuery-Range-Slider-Plugin-asRange/dist/jquery-asRange.js"></script>

<script src="range/ion.rangeSlider.js"></script>	
<link href="range/ion.rangeSlider.css" rel="stylesheet">
<link href="range/ion.rangeSlider.skinFlat.css" rel="stylesheet">



<!--taginputs-->
<link rel="stylesheet" href="../user/assets/bootstrap-tagsinput.css">
<link rel="stylesheet" href="../user/assets/bootstrap.min.css">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap-theme.min.css"> -->
<link rel="stylesheet" href="https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/assets/app.css">
<!--typeahead-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.11.1/typeahead.bundle.min.js"></script>
<script src="https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>


<!--image-->
<script>
	
	//try new
	localStorage.setItem('url', output.src);
	
	var loadFile = function(event) {
    	var output = document.getElementById('output');
    	output.src = URL.createObjectURL(event.target.files[0]);
		localStorage.setItem('url', output.src);
  	};
	
	document.querySelector("html").classList.add('js');
	var fileInput  = document.querySelector( ".input-file" ),  
    button     = document.querySelector( ".input-file-trigger" ),
    the_return = document.querySelector(".file-return");
      
	button.addEventListener( "keydown", function( event ) {  
		if ( event.keyCode == 13 || event.keyCode == 32 ) {  
			fileInput.focus();  
		}  
	});
	button.addEventListener( "click", function( event ) {
	   fileInput.focus();
	   return false;
	});  
	fileInput.addEventListener( "change", function( event ) {  
		the_return.innerHTML = this.value;  
	});  
	
</script>

<script>
	
var $range = $(".js-range-slider"),
    $from = $(".js-from"),
    $to = $(".js-to"),
    range,
    min = 0.5,
    max = 10,
    from,
    to;

var updateValues = function () {
    $from.prop("value", from);
    $to.prop("value", to);
};

$range.ionRangeSlider({
    type: "double",
    min: min,
    max: max,
    step: 0.1,
    prettify_enabled: false,
    grid: true,
    grid_num: 10,
    onChange: function (data) {
        from = data.from;
        to = data.to;
        
        updateValues();
    }
});

range = $range.data("ionRangeSlider");

var updateRange = function () {
    range.update({
        from: from,
        to: to
    });
};

$from.on("change", function () {
    from = +$(this).prop("value");
    if (from < min) {
        from = min;
    }
    if (from > to) {
        from = to;
    }

    updateValues();    
    updateRange();
});

$to.on("change", function () {
    to = +$(this).prop("value");
    if (to > max) {
        to = max;
    }
    if (to < from) {
        to = from;
    }

    updateValues();    
    updateRange();
});
	
</script>

<script>
	var citynames = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		prefetch: {
			url: '../user/assets/location.js',
			filter: function(list) {
				return $.map(list, function(cityname) {
							return { name: cityname }; });
				}
		}
	});
	citynames.initialize();
	$('#locations').tagsinput({
		typeaheadjs: {
			name: 'citynames',
			displayKey: 'name',
			valueKey: 'name',
			source: citynames.ttAdapter()
		}
	});
	
	var skills = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		prefetch: {
			url: '../user/assets/skill.js',
			filter: function(list) {
				return $.map(list, function(cityname) {
							return { name: cityname }; });
				}
		}
	});
	skills.initialize();
	$('#skills').tagsinput({
		typeaheadjs: {
			name: 'skills',
			displayKey: 'name',
			valueKey: 'name',
			source: skills.ttAdapter()
		}
	});
	
	var educations = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		prefetch: {
			url: 'assets/education.js',
			filter: function(list) {
				return $.map(list, function(cityname) {
							return { name: cityname }; });
				}
		}
	});
	educations.initialize();
	$('#educations').tagsinput({
		typeaheadjs: {
			name: 'educations',
			displayKey: 'name',
			valueKey: 'name',
			source: educations.ttAdapter()
		}
	});
	
</script>
<script>
$(document).on('click', '.panel-heading span.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.closest('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-minus-square').addClass('fa fa-plus-square ');
	} else {
		$this.closest('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-plus-square').addClass('fa fa-minus-square');
	}
})	
</script>
<script>
	var rejectList = [ "gmail.com", "outlook.com", "live.com", "yahoo.com", "rediff.com", "mail.com","gmx.com","hushmail.com","hushmail.me","hush.com","hush.ai","mac.hush.com","inbox.com" ];
function addInput1(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed'><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><textarea required class='search-field' rows='2' style='resize: none' name='description[]' placeholder='ex Hands on experience in Core Java, J2EE frameworks like Spring / Jersey, ORM framework and related technologies' maxlength='255' title='Maxlength of 255'></textarea></div>";
        document.getElementById(divName).appendChild(newdiv);
	}
	
	function checkemail() {
		
		var name = $("#email").val().toLowerCase();
		
		if(name.length > 7 && name != '<?php echo $row['email'] ?>' )
		{
			$('#email-loading').show();
			$("#email-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
			
			var splitArray = name.split('@');
			if(rejectList.indexOf(splitArray[1]) >= 0)
			{
				$("#email-i").removeClass();
				$("#email-i").addClass("fa fa-close fa-2x");
				$("#email-i").css("color", "red");
			}
			else{
				$("#email-i").removeClass();
				$("#email-i").addClass("fa fa-check fa-2x");
				$("#email-i").css("color", "green");
			}
		}
	else{
			$("#email-loading").hide();
			$("#email-i").removeClass();
			$("#email-i").css("color", "");
		}
}
	function checkSize(max_img_size)
	{
		var input = document.getElementById("upload");
		// check for browser support (may need to be modified)
		if(input.files && input.files.length == 1)
		{           
			if (input.files[0].size > max_img_size) 
			{
				swal(
					  'Warning',
					  'File Size Must be less than 500 Kb !',
					  'warning'
					)
				return false;
			}
		}
	
		return true;
	}
	
	
	function exp(nim)
	{
		
		$("#batch").val('');
		var select = [];
		var year  = new Date().getFullYear();
		var old = 2010;
		year++;
		var no = year - old -nim;
		
		for(i=0;i<no;i++){
			select[i] = old;
			old++;
		}
		select.toString();;
		console.log(select);
		$('#batch').val(select).trigger('chosen:updated');
		
		for(i = nim; i> 0;i--)
		{
			$('#batch').find('option:last').remove();
		}
		
		if(nim>0)
		{
			$('#batchnote').show();
			$('#batchnote').text('You cannot select batch between '+(year-nim)+' - 2017');
		}
	}
	
</script>


</body>

</html>