<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['recruiter'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();

	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}
if(isset($_POST['final_form']))
{
	$id = test_input($_POST['final_id']);
	$title = test_input($_POST['final_value']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM jobs WHERE id = ? AND job_title = ? AND rec_username = ?");
	$stm->bind_param("sss",$id,$title,$_SESSION['userData']);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		//now get the count of the application
		$stm = $db->prepare("SELECT applied_id FROM jobs WHERE id = ? AND rec_username = ?");
		$stm->bind_param("ss",$id,$_SESSION['userData']);
		$stm->execute();
		$counts = $stm->get_result()->fetch_object()->applied_id;
		$stm->free_result();
		
		$id_counts = count(json_decode($counts));
		if($id_counts == 0)
		{
			//unlink the picture of job too
			$stm = $db->prepare("SELECT company_pic FROM jobs WHERE id = ? AND rec_username = ?");
			$stm->bind_param("ss",$id,$_SESSION['userData']);
			$stm->execute();
			$picture = $stm->get_result()->fetch_object()->company_pic;
			$stm->free_result();
			
			$upload_dir = '../company_pictures/';
			unlink($upload_dir.$picture);
			
			//now delete the job row
			if(($stmtt = $db->prepare("DELETE FROM jobs WHERE id = ? AND job_title = ? AND rec_username = ?"))){
				if($stmtt->bind_param("sss",$id,$title,$_SESSION['userData'])){
					if($stmtt->execute()){
						header("Location: manage-jobs.php");	
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry You cannot Delete this job since users have applied for this job !", "error");}, 100);</script>';
	}
	else{
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	}
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!Doctype html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Manage Jobs</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css" >

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php" >Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="post_job.php">Post Job</a></li>
				<li><a href="manage-jobs.php" id="current" >Manage Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-dashboard"></i> Manage Jobs </h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25">Your listings are shown in the table below. <strong>If Job Email is not verified in 3 hours then Job will be deleted !</strong></p>

		<table class="manage-table resumes responsive-table">

			<tr>
				<th><i class="fa fa-file-text"></i>Job Title</th>
				<th><i class="fa fa-check-square-o"></i>Verified_?</th>
				<th><i class="fa fa-calendar"></i>Date Posted</th>
				<th><i class="fa fa-calendar"></i>Date Expires</th>
				<th><i class="fa fa-user"></i>Applications</th>
				<th><i class="fa fa-forumbee "></i> Status</th>
				<th></th>
			</tr>
			<?php  
			$stm = $db->prepare("SELECT * FROM jobs WHERE rec_username = ? ORDER BY created DESC");
			$stm->bind_param("s",$_SESSION['userData']);
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				echo '
				<tr>';$title = $rim["job_title"];
					if($rim['admin_verified'] == '0')
						echo '<td class="title"><a href="job-overview.php?id='.$rim['id'].'" target="_blank">'.$rim['job_title'].' <span class="pending"> (Pending Approval)</span></a></td>';
					else
						echo '<td class="title"><a href="job-overview.php?id='.$rim['id'].'" target="_blank">'.$rim['job_title'].' <span class="pending"></span></a></td>';
					if($rim['email_verified'] == '0')
						echo '<td class="centered"><i class="fa fa-close"></i></td>';
					else
						echo '<td class="centered"><i class="fa fa-check"></i></td>';
					echo '<td>'.$rim['created'].'</td>
					<td>'.$rim['expiration'].'</td>
					<td class="centered"><a target="_blank" href="manage-applications.php?appid='.$rim['id'].'" class="button">'.count(json_decode($rim['applied_id'])).'</a></td>';
					
					if($rim['admin_verified'] == '0' && $rim['email_verified'] == '0')
						echo '<td class="centered">Not Verified</td>';
					else if($rim['admin_verified'] == '0' && $rim['email_verified'] == '1')
						echo '<td class="centered">Not Visible</td>';
					else if($rim['admin_verified'] == '1' && $rim['email_verified'] == '1' && $today <= $rim['expiration'])
						echo '<td class="centered">Visible</td>';
					else if($rim['admin_verified'] == '1' && $rim['email_verified'] == '1' && $today > $rim['expiration'])
						echo '<td class="centered">Expired</td>';
				
					if(count(json_decode($rim['applied_id'])) == 0)
					echo '<td class="action">
						<a href="#small-dialog" onClick="delbox('.$rim['id'].')" class="popup-with-zoom-anim"><i class="fa fa-remove"></i> Delete</a>
					</td>';
					
					echo '<input type="text" value="'.$title.'" id="title'.$rim['id'].'" style="display:none" >
				</tr>';
			}
			
			?>
			
			<div id="small-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
					<div class="small-dialog-content">
						<!-- doc start -->
						<div id="wrapper">
							<div class="overlay"></div>
							<!-- Sidebar -->
							<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
								<ul class="nav sidebar-nav">
									<div id="threedot">
										<form autocomplete="off" method="post">
											<h3>Are you sure you want to delete </h3>
											<input type="text" id="final_id" name="final_id" style="display: none" >
											<input type="text" id="final_value" name="final_value" readonly >
											<h5>You won't be able to revert this !</h5><br/>
											<button type="submit" name="final_form">Delete it</button>
										</form>
									</div>
									
								</ul>
							</nav>
							<!-- /#sidebar-wrapper -->
						</div>
						<!-- /#wrapper -->
					</div>
				</div>
			
		</table>

		<br>
		<a href="post_job.php" class="button">Add Job</a>

	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2018 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<script>
function delbox(one)
	{
		var nai = document.getElementById('title'+one);
		document.getElementById('final_id').setAttribute("value",one);
		document.getElementById('final_value').setAttribute("value",nai.value);
	}
	
</script>
</body>

</html>