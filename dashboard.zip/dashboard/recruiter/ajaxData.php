<?php
session_start();
//Include database configuration file
include('../../db/config.php');

error_reporting(0);

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['recruiter'] == true) {
}
else{
	header('Location: ../../login.php');
}

// code to check email duplication

if(isset($_POST["email"]) && !empty($_POST["email"])){
    
	$stm = $db->prepare("SELECT email FROM users_login WHERE email = ? ");
	$stm->bind_param("s",$_POST["email"]);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

// code to check phone duplicasy
if(isset($_POST["phone"]) && !empty($_POST["phone"])){
   
	$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
	$stm->bind_param("s", $_POST["phone"]);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

if(isset($_POST['id']) && !empty($_POST['id']) && isset($_POST['username1']) && !empty($_POST['username1']) && isset($_POST['username2']) && !empty($_POST['username2']) && isset($_POST['job_id']) && !empty($_POST['job_id'])){
	
	$count = 0;
	$err = '';
	$id = test_input($_POST['id']);
	$username1 = test_input($_POST['username1']);
	$username2 = test_input($_POST['username2']);
	$value = test_input($_POST['value']);
	$job_id = test_input($_POST['job_id']);
	
	if($value >= 0 && $value < 3){
	}
	else
		$err = $err . 'Problem with Select Input Value <br/>';
	
	//check user details
	$stm = $db->prepare("SELECT id FROM users_login WHERE id = ? AND oauth_uid = ? ");
	$stm->bind_param("ss",$id,$username1);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	//now check that whether job id exist
	$stm = $db->prepare("SELECT id FROM jobs WHERE id = ? ");
	$stm->bind_param("s",$job_id);
	$stm->execute();
	$stm->store_result();
	$count1 = $stm->num_rows;
	$stm->free_result();
	
	//now check that whether the user has applied for it or not
	$stm = $db->prepare("SELECT jobs FROM users_profile WHERE username = ?");
	$stm->bind_param("s",$username1);
	$stm->execute();
	$jobs = $stm->get_result()->fetch_object()->jobs;
	$stm->free_result();
	
	$jobs_2 = json_decode($jobs);
	$jobs_count = count($jobs_2);
	for($i=0;$i<$jobs_count;$i++)
		$jobs_1[$i] = $jobs_2[$i][0];
	
	//now fetch the applied_id to verify one more time
	$stm = $db->prepare("SELECT applied_id FROM jobs WHERE id = ? AND rec_username = ?");
	$stm->bind_param("ss",$job_id,$username2);
	$stm->execute();
	$applied_id = $stm->get_result()->fetch_object()->applied_id;
	$stm->free_result();
	
	$applied_id_2 = json_decode($applied_id);
	$applied_id_count = count($applied_id_2);
	for($i=0;$i<$applied_id_count;$i++)
		$applied_id_1[$i] = $applied_id_2[$i][0];
	
	
	if(in_array($job_id,$jobs_1) && in_array($id,$applied_id_1) ){
	}
	else
		$err = $err . 'The user has not applied for this job <br/>';
	
	
	if($err == '')
	{
		if($count == 1 && $count1 == 1){
			
			//lets update the user data
			for($i=0;$i<$jobs_count;$i++){
				if($jobs_1[$i] == $job_id){
					$jobs_2[$i][1] = $value;
		
				}
			}
			
			//lets update the applied jobs data
			for($i=0;$i<$applied_id_count;$i++){
				if($applied_id_1[$i] == $id){
					$applied_id_2[$i][1] = $value;
					
				}
			}
			//now lets start update both tables
			
			//update both tables 
			$flag = 0;
		
			if (($stmt = $db->prepare("UPDATE jobs SET applied_id = ? WHERE id = ? AND rec_username = ?"))) {
				if ($stmt->bind_param("sis",json_encode($applied_id_2),$job_id,$username2)) {
					if ($stmt->execute()){
						if(($stmy = $db->prepare("UPDATE users_profile SET jobs = ? WHERE id = ? AND username = ? "))){
							if($stmy->bind_param("sis",json_encode($jobs_2),$id,$username1)){
								if($stmy->execute()){
									echo 'Data';
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;

			if($flag == 1)
			{
				$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
			}
			

		}
		else
			$err = $err . 'There is a problem with Input and Jobseeker data !';
	}
	
	if($err != '')
	{
		echo $err;
	}  	
		
    
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>