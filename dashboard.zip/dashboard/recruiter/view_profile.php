<?php
include('../../db/config.php');
session_start();
$userid = test_input($_GET['user']);

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['recruiter'] == true && isset($userid)) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//check that whether the username exist or not
	$count = 0;
	$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ?");
	$stm->bind_param("s",$userid);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1)
	{
		$stm = $db->prepare("SELECT * FROM users_login WHERE oauth_uid = ?");
		$stm->bind_param("s",$userid);
		$stm->execute();
		$ress = $stm->get_result();
		$roww = $ress->fetch_assoc();
		$stm->free_result();
		
		$stm = $db->prepare("SELECT * FROM users_profile WHERE username = ?");
		$stm->bind_param("s",$userid);
		$stm->execute();
		$ress = $stm->get_result();
		$rowws = $ress->fetch_assoc();
		$stm->free_result();
		
		
	}
	else{
		header("Location: index.php");
	}
	
	$url = $rowws['video'];
	preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+(?=\?)|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url, $videoid);

}
else{
	header('Location: ../../login.php');
}
function dateformat($new) {
	if($new == 'Present')
		return $new;
	else{
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $convert_month . " " . $year;
	return $final;
	}
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $roww['name'] ?> | Profile View</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php" >Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="#">Post Job</a></li>
				<li><a href="manage-jobs.php">Manage Jobs</a></li>
				<li><a href="#" id="current">Manage Application</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="resume">
	<div class="container">
		<div class="twelve columns">
			<div class="resume-titlebar">
				<?php 
				if($roww['oauth_provider'] != 'normal'){
					echo '<img src="'.$roww['picture'].'" alt="'.$roww['name'].'" /> ';
				} 
				else{
					echo '<img src="../user_pictures/'.$roww['picture'].'" alt="'.$roww['name'].'" /> ';
				}
				?>
				
				<div class="resumes-list-content">
					<h4><?php echo $roww['name'] ?><span><?php echo $rowws['title'] ?></span></h4>
					<?php if($rowws['city'] != NULL && $rowws['state'] != NULL){ 
						echo '<span class="icons"><i class="fa fa-map-marker"></i> '.$rowws['city']. ', '.$rowws['state'].'</span>';} 
					?>
						
					<?php if($roww['phone'] != NULL) echo '<span class="icons"><i class="fa fa-phone"></i> '.$roww['phone'].' </span>'; ?>
					
					<span class="icons"><a href="#"><i class="fa fa-envelope"></i> <?php echo $roww['email'] ?></a></span>
					<div class="skills">
						<?php 
						//getting skills as json then decode it in array
						$skills = json_decode($rowws['skills']);
						for($i=0;$i<count($skills);$i++)
						{
							echo '<span>'.$skills[$i].'</span>';
						}
						?>
						
					</div>
					<div class="clearfix"></div>

				</div>
			</div>
		</div>

		<div class="four columns">
			<div class="two-buttons" align="right">
				<a href="#small-dialog" class="popup-with-zoom-anim"><i class="fa fa-ellipsis-v fa-3x" aria-hidden="true"></i></a>
			
				<div id="small-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
					<div class="small-dialog-content">
						<!-- doc start -->
						<div id="wrapper">
							<div class="overlay"></div>
							<!-- Sidebar -->
							<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
								<ul class="nav sidebar-nav">
									<div id="threedot">
										<button onClick="window.open('view_resume.php?userid=<?php echo $userid ?>')" formtarget="_blank" >View Resume</button>
										<button onClick="window.open('just_print.php?userid=<?php echo $userid ?>')" formtarget="_blank" >Download Resume</button>
										<button <?php if(!empty($videoid[0])) echo 'onClick="video()"';  ?> >Video Resume</button>
									</div>
									<?php if(!empty($videoid[0])) 
							   echo '<div class="video-container" style="display: none">
										<iframe src="https://www.youtube.com/embed/'.$videoid[0].'?rel=0&showinfo=0&color=white" frameborder="0" allowfullscreen ></iframe>
									</div>'; ?>
								</ul>
							</nav>
							<!-- /#sidebar-wrapper -->
						</div>
						<!-- /#wrapper -->
					</div>
				</div>
				
			</div>
		</div>
		
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Recent Jobs -->
	<div class="eight columns">
	<?php if($rowws['objective'] == NULL && $rowws['acheivements'] == NULL && $rowws['projects'] == NULL && $rowws['work'] == NULL && $rowws['education'] == NULL)
		echo '
		<h1>The user has not filled details !</h1>
		';
	?>
	
	<div class="padding-right">
		<?php if($rowws['objective'] != NULL){
			echo ' <h3 class="margin-bottom-15" >Objective</h3>
			<p class="margin-reset" align="justify">
			 '.$rowws['objective'].'
		</p>';
		} ?>
		

		<br>

		<?php if($rowws['acheivements'] != NULL){
			echo '<p><strong>Acheivements</strong>:</p>
				  <ul class="list-1" style="text-align: justify">';
				  //getting acheivements as json then decode it in array
					$acheivements = json_decode($rowws['acheivements']);

					for($i=0;$i<count($acheivements);$i++)
					{
						echo '<li>'.$acheivements[$i].'</li>';
					}
			echo '</ul>';
			}
		?>

	</div>
	</div>

	<!-- Widgets -->
	<?php if($rowws['projects'] != NULL || $rowws['work'] != NULL || $rowws['education'] != NULL)
		echo '<h3 class="margin-bottom-20">Slills & Abilities</h3>
	
	<div class="eight columns">
		
		<!-- Resume Table -->
		<!--projects-->
		<div class="form with-line">';?>
			<?php if($rowws['projects'] != NULL){
			echo '
				<div class="form-inside">
				<div class="panel panel-success" data-toggle="collapse">
					<div class="panel-heading">
						<h3 class="panel-title">Total '.count(json_decode($rowws['projects'])).' projects</h3>
						<span class="pull-right clickable"><i class="fa fa-minus-square"></i></span>
					</div>
					<div class="panel-body">';
						
						 $projects = json_decode($rowws['projects']);
							for($i=0;$i<count($projects);$i++)
							{
								echo '<h5>'.$projects[$i][0].'</h5>
									  <div>'.dateformat($projects[$i][2]).' - '.dateformat($projects[$i][3]).'</div>
									  <div><a href = "'.$projects[$i][1].'" target = "_blank">'.$projects[$i][1].'</a></div>
									  <div class="description">'.$projects[$i][4].'</div><br/>';
							}
							
				echo'</div>
				</div>
			</div>
			';}
			?>
			
			<!-- experience -->
			<?php if($rowws['work'] != NULL){
			echo '
				<div class="form-inside">
				<div class="panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title">Total '.count(json_decode($rowws['work'])).' Work Experiences</h3>
						<span class="pull-right clickable"><i class="fa fa-minus-square"></i></span>
					</div>
					<div class="panel-body">';
					
						 $work = json_decode($rowws['work']);
							for($i=0;$i<count($work);$i++)
							{
								echo '<h5>'.$work[$i][0].'</h5>
									  <div>'.$work[$i][1].'('.$work[$i][2].')</div>
									  <div>'.dateformat($work[$i][3]).' - '.dateformat($work[$i][4]).'</div>
									  <div class="description">'.$work[$i][5].'</div><br/>';
							}

					echo '</div>
				</div>
			</div>
			';}
			?>
			
			<?php if($rowws['work'] != NULL){
			echo '
			<div class="form-inside">
				<div class="panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title">Education</h3>
						<span class="pull-right clickable"><i class="fa fa-minus-square"></i></span>
					</div>
					<div class="panel-body">';
						
						
						 $education = json_decode($rowws['education']);
							for($i=0;$i<count($education);$i++)
							{
								echo '<h5>'.$education[$i][0].'</h5>
									  <div>'.$education[$i][1].','.$education[$i][2].', '.$education[$i][3].'</div>
									  <div>'.$education[$i][4].' - '.$education[$i][5].'</div></br>';
							}
						
				echo '</div>
				</div>
			</div>
			
			';}
			?>
			<!-- education -->
			
		</div>
	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>


<script>
$(document).on('click', '.panel-heading span.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.closest('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-minus-square').addClass('fa fa-plus-square ');
	} else {
		$this.closest('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-plus-square').addClass('fa fa-minus-square');
	}
})
function video(){
	$('#threedot').hide();
	$('.video-container').show();
}
</script>

</body>

</html>