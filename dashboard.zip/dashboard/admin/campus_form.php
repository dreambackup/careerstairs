<?php
include('../../db/config.php');
session_start();
error_reporting(0);
$var = test_input($_GET['id']);
if(isset($var))
{
	$count = 0;
	$stm = $db->prepare("SELECT id FROM campus WHERE id = ? ");
	$stm->bind_param('s',$var);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		$stm = $db->prepare("SELECT * FROM campus WHERE id = ?");
		$stm->bind_param("s",$var);
		$stm->execute();
		$ress = $stm->get_result();
		$rows = $ress->fetch_assoc();
		$stm->free_result();
	}
	else{
		// Unset all session variables
		session_unset();
		// Delete all session variables
		session_destroy();
		header("Location: campus.php");
	}
}
else{
	header("Location: index.php");
}


//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $rows['college_name'] ?></title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->

<!--taginputs-->
<link rel="stylesheet" href="../user/assets/bootstrap-tagsinput.css">
<style>
@media print{*,:after,:before{color:#000!important;text-shadow:none!important;background:0 0!important;-webkit-box-shadow:none!important;box-shadow:none!important}
.table-bordered td,.table-bordered th{border:1px solid #ccc!important}}
.label-info{background-color: #58D68D;}
</style>
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap-theme.min.css"> -->
<link rel="stylesheet" href="https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/assets/app.css">

<link rel="stylesheet" media="all" href="https://cdn.littlelines.com/assets/application-9221995a61a6387726512f858bbfe32d0649b9b416b698422b35e281383d9279.css" data-turbolinks-track="true" />
	
<style>
	.image {
  		display: block;
  		width: 150px;
  		height: 150px;
  		margin: 1em auto;
  		background-size: cover;
  		background-repeat: no-repeat;
  		background-position: center center;
  		-webkit-border-radius: 99em;
  		-moz-border-radius: 99em;
  		border-radius: 99em;
 		border: 5px solid #eee;
  		box-shadow: 0 3px 2px rgba(0, 0, 0, 0.3);  
	}
</style>

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="header header--primary">
  <nav class="nav nav--primary" id="nav">
    <ul>
      <li class="nav__item nav--primary__item nav--primary__item--logo">
        <a title="careerstairs" data-instant="" class="nav__link nav--primary__link nav--primary__link--logo" href="../../index.php"><img src="../../images/logo.png" alt="Career Stairs" /></a>
      </li>
      <li class="nav__item nav--primary__item nav--primary__item--toggle">
        <button class="hamburger hamburger--squeeze nav__link nav--primary__link nav--primary__link--toggle" @click="toggle">
          <span class="hamburger-box">
            <span class="hamburger-inner">Toggle Menu</span>
          </span>
        </button>
      </li>
      <li>
        <ul class="nav--primary__right nav--primary__collapse">
			<?php
			if(isset($_SESSION['userData']) && !empty($_SESSION['userData'])){
				echo '<li class="nav__item nav--primary__item">
							<a data-instant="" class="nav--primary__button--primary" @click="close" href="login.php"><i class="fa fa-chevron-right"></i>&nbsp; Dashboard</a>
						  </li>';
			}
				else{
					echo '<li class="nav__item nav--primary__item">
							<a data-instant="" class="nav__link nav--primary__button nav--primary__button--primary" @click="close" href="login.php"><i class="fa fa-lock"></i> &nbsp; Log In</a>
						  </li>';
				}
		 ?>    
        </ul>
      </li>
    </ul>
  </nav>
</header>


<!-- Titlebar
================================================== -->
 	
<main class="main">
	<div class="hero hero--home b-lazy" data-src="http://media.beam.usnews.com/58/1a/f480ca024c2cb430ef1e3b1f31b8/160914-interview-stock.jpg">
	  <div class="hero--home__gradient"></div>
	  <div class="hero__content">
		<h1 class="hero__title" style="color: white">
		  Campus Connect<br class="hero__title-break">
		  <span class="color--subaccent">&</span> development program.
		</h1>
		<h3 class="hero__body" style="color: white">
		  The goal is to build a sustainable partnership with engineering education institutions across India.
		</h3>
	  </div>
	</div>

</main>

<!-- Content
================================================== -->
<div class="container">

<!-- contact form -->
<section id="contact">
  <div class="section text-align--center">
    <div class="content">
      <div class="heading">
        <h1 class="heading__title heading__title--large">
          Campus Connect [<strong><?php echo $rows['college_name'] ?></strong>]
        </h1>
      </div>
     
    	<!--basic form-->   
        <form class="form form--quick-start form--active" accept-charset="UTF-8" id="basicform" autocomplete="on" method="post" onsubmit="return checkform(500000)" enctype="multipart/form-data">
			<fieldset class="list">
			
				<label class="label">College Logo</label>
				<img class="image" src="../../images/colleges/<?php echo $rows['profile_pic'] ?>">
				
				<div class="list__item">
					<label class="label">Is he a TPO ?</label>
					<select class="select" disabled>
						<option>Select an option</option>
						<option value="yes" <?php echo ($rows['basic_question'] == 'yes')?"selected":"" ?>>Yes</option>
						<option value="no" <?php echo ($rows['basic_question'] == 'no')?"selected":"" ?>>No</option>
					</select>
				</div>
			
				<?php 
				
				if($rows['basic_question'] == 'no'){
					echo '
						<div class="list__item">
							<label class="label" required="required" for="non_tpo_basic_name">Your Name</label>
							<input class="input" type="text" id="non_tpo_basic_name" value="'.$rows['non_tpo_name'].'"  />
						</div>

						<div class="list__item">
							<label class="label" required="required" for="non_tpo_basic_email">Your Email</label>
							<input class="input" type="email" id="non_tpo_basic_email" value="'.$rows['non_tpo_email'].'" />
						</div>
					
						<div class="list__item">
							<label class="label">Your Position in College</label>
							<input class="input" type="text" value="'.$rows['non_tpo_position'].'" />
						</div>
					
						<div class="list__item">
							<label class="label" for="non_tpo_basic_mobile">Your Mobile Number:</label>
							<input class="input" type="text" id="non_tpo_basic_mobile" value="'.$rows['	non_tpo_mobile'].'" />
						</div>
					
					';
				}
				
				?>
				
				
				<!-- now tpo -->
				
				<div class="list__item">
					<label class="label" required="required" for="tpo_basic_name">TPO Name</label>
					<input class="input" type="text" id="tpo_basic_name" value="<?php echo $rows['tpo_name'] ?>" readonly />
				</div>

				<div class="list__item" id="tpo_email_div">
					<label class="label" required="required" for="tpo_basic_email">TPO Email</label>
					<input class="input" type="email" id="tpo_basic_email" value="<?php echo $rows['tpo_email'] ?>" readonly />
				</div>
				
				
				<div class="list__item" id="tpo_mobile_div">
					<label class="label" for="tpo_basic_mobile">TPO Mobile Number:</label>
					<input class="input" type="text" value="<?php echo $rows['tpo_mobile'] ?>" readonly />
				</div>
			
				<!--college and stuff-->
				<div class="list__item" >
					<label class="label" required="required" for="college_name">College Name</label>
					<input class="input" type="text" name="college_name" value="<?php echo $rows['college_name'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_uni">College University</label>
					<input class="input" type="text" value="<?php echo $rows['college_uni'] ?>" readonly />
				</div>
			
				<div class="list__item" >
					<label class="label" required="required">College Courses</label>
					<input class="input" type="text" data-role="tagsinput" id="educations" value="<?php echo implode(",",json_decode($rows['educations'])) ?>" >
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_departments">College Departments</label>
					<input class="input" type="number" id="college_departments" value="<?php echo $rows['college_departments'] ?>" readonly />
				</div>
				
				<fieldset class="list">

				  <div class="list__item">
					<div class="label">Student Strength ?</div>
					<input class="radio radio--button" type="radio" value="500 - 1000" name="students[]" id="student_strength_first" <?php echo ($rows['students'] == '500 - 1000')?"checked":"" ?> />
					<label class="label" for="student_strength_first">500 - 1000</label>

					<input class="radio radio--button" type="radio" value="1000 - 2500" name="students[]" id="student_strength_second" <?php echo ($rows['students'] == '1000 - 2500')?"checked":"" ?> />
					<label class="label" for="student_strength_second">1000 - 2500</label>

					<input class="radio radio--button" type="radio" value="2500 - 5000" name="students[]" id="student_strength_third" <?php echo ($rows['students'] == '2500 - 5000')?"checked":"" ?> />
					<label class="label" for="student_strength_third">2500 - 5000</label>

					<input class="radio radio--button" type="radio" value="More than 5000" name="students[]" id="student_strength_four" <?php echo ($rows['students'] == 'More than 5000')?"checked":"" ?> />
					<label class="label" for="student_strength_four">More than 5000</label>
				  </div>

				</fieldset>
				
				<fieldset class="list">

				  <div class="list__item">
					<div class="label">Faculty Strength ?</div>
					<input class="radio radio--button" type="radio" value="0 - 50" name="faculty[]" id="faculty_strength_first" <?php echo ($rows['faculty'] == '0 - 50')?"checked":"" ?>  />
					<label class="label" for="faculty_strength_first">0 - 50</label>

					<input class="radio radio--button" type="radio" value="50 - 150" name="faculty[]" id="faculty_strength_second" <?php echo ($rows['faculty'] == '50 - 150')?"checked":"" ?> />
					<label class="label" for="faculty_strength_second">50 - 150</label>

					<input class="radio radio--button" type="radio" value="150 - 300" name="faculty[]" id="faculty_strength_third" <?php echo ($rows['faculty'] == '150 - 300')?"checked":"" ?> />
					<label class="label" for="faculty_strength_third">150 - 300</label>

					<input class="radio radio--button" type="radio" value="More than 300" name="faculty[]" id="faculty_strength_four" <?php echo ($rows['faculty'] == 'More than 300')?"checked":"" ?> />
					<label class="label" for="faculty_strength_four">More than 300</label>
				  </div>

				</fieldset>
				
				<div class="list__item" >
					<label class="label" required="required" for="url_input">College Website</label>
					<input class="input" id="url_input" type="url" value="<?php echo $rows['url_input'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_city">College City</label>
					<input class="input" type="text" id="college_city" value="<?php echo $rows['college_city'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_dist">College District</label>
					<input class="input" type="text" id="college_dist" value="<?php echo $rows['college_dist'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_state">College State</label>
					<input class="input" type="text" id="college_dist" value="<?php echo $rows['college_state'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_address">College Address</label>
					<textarea id="college_address" readonly class="textarea" style="resize: none" rows="6"><?php echo $rows['college_address'] ?></textarea>
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_principal_name">College Principal's Name</label>
					<input class="input" type="text" id="college_principal_name" value="<?php echo $rows['college_principal_name'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_principal_email">College Principal's Email</label>
					<input class="input" type="email" id="college_principal_email" value="<?php echo $rows['college_principal_email'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="college_principal_number">College Principal's Number</label>
					<input class="input" id="college_principal_number" value="<?php echo $rows['college_principal_number'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="distance_city">Distance of College from the City</label>
					<input class="input" type="number" id="distance_city" value="<?php echo $rows['distance_city'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="distance_bus">Distance of College from the Nearest Bus-stand</label>
					<input class="input" type="number" id="distance_bus" value="<?php echo $rows['distance_bus'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required" for="distance_rail">Distance of College from the Nearest Railway Station</label>
					<input class="input" type="number" id="distance_rail" value="<?php echo $rows['distance_rail'] ?>" readonly />
				</div>
				
				<div class="list__item" >
					<label class="label" required="required">Best Way to Reach your College</label>
					<textarea class="textarea" readonly style="resize: none" rows="6" ><?php echo $rows['college_reach'] ?></textarea>
				</div>
				
				
			</fieldset>
		</form>
   		
		</div>
    </div>
  </div>

</section>	

	
	
</div>

<!-- Footer
================================================== -->

 <footer class="footer footer--primary">

  <div class="content">

    <div class="section footer--primary__offices">

      <div class="footer--primary__address-container">
        <div class="footer--primary__accent"></div>
        <p class="footer--primary__address">
          	10th Floor, Tower B & C,<br/>
			DLF Building No.5, DLF Cyber City,<br/>
			DLF Phase 3, Gurugram, Haryana 122002
        </p>
		</div>
    </div>

    <div class="section footer--primary__information">

      <ul class="nav nav--footer footer--primary__nav">
        <li class="nav__item nav--footer__item nav--footer__item--label">
          Links
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="../../about.php">About Us</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="../../careers.php">Careers</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="www.blog.careerstairs.in">Our Blog</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="../../service.php">Terms of Service</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="../../policy.php">Privacy Policy</a>
        </li
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" href="../../contact.html">Contact Us</a>
        </li>
        <!--li class="nav__item nav--footer__item">
        </li-->
      </ul>

      <ul class="nav nav--footer footer--primary__nav">
        <li class="nav__item nav--footer__item nav--footer__item--label">
          Connect
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" target="_blank" href="https://www.facebook.com/careerstairsin-259421891127990/">Facebook</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" target="_blank" href="https://twitter.com/CareerstairsI">Twitter</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" target="_blank" href="https://www.linkedin.com/company/18031484/">LinkedIn</a>
        </li>
        <li class="nav__item nav--footer__item">
          <a class="nav__link nav--footer__link" target="_blank" href="https://plus.google.com/u/0/109522836028901433584">Google</a>
        </li>
      </ul>

      <div class="footer--primary__contact">
        <a href="tel:+919050167626" class="link">+91 90501 67626</a> <span class="space--small">//</span> <a href="mailto:team@careerstairs.in" class="link">team@careerstairs.in</a>
      </div>

      <p class="footer--primary__copyright" align="justify">
        CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
      </p>
	  <p class="footer--primary__copyright">
        CareerStairs &copy; 2017<span class="space--small">/</span><span class="small mark">We ❤ the details.</span>
      </p>
    </div>
  </div>

</footer>


 <script src="https://cdn.littlelines.com/assets/application-ea8d15950d0ba797d2be9eedb35c9b738dc53c997a80e43aff0612d551a4b70b.js" data-turbolinks-track="true" async="async"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<script src="../../scripts/jquery-2.1.3.min.js"></script>
<!--typeahead-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.11.1/typeahead.bundle.min.js"></script>
<script src="https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>


<script>

	//couses
	var educations = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		prefetch: {
			url: '../recruiter/assets/education.js',
			filter: function(list) {
				return $.map(list, function(cityname) {
							return { name: cityname }; });
				}
		}
	});
	educations.initialize();
	$('#educations').tagsinput({
		typeaheadjs: {
			name: 'educations',
			displayKey: 'name',
			valueKey: 'name',
			source: educations.ttAdapter()
		}
	});
	
	
	function checkform(max_img_size)
	{
		var input = document.getElementById("upload");
		// check for browser support (may need to be modified)
		if(input.files && input.files.length == 1)
		{           
			if (input.files[0].size > max_img_size) 
			{
				swal(
					  'Warning',
					  'File Size Must be less than 500 Kb !',
					  'warning'
					)
				return false;
			}
		}
	}
	
</script>

</body>

</html>