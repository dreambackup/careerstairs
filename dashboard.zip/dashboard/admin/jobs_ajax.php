<?php
	session_start();
	//Include database configuration file
	include('../../db/config.php');

	error_reporting(0);

	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
	}
	else{
		header('Location: ../../login.php');
	}


	if(isset($_POST["value"]) && !empty($_POST["value"])){
		
		$id = test_input($_POST["value"]);
		
		$stm = $db->prepare("SELECT rec_username,rec_email,email_verified,admin_verified,job_title,company_name FROM jobs WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3,$col4,$col5,$col6);

		while ($stm->fetch()) {
        	$username = $col1;
			$email = $col2;
			$verify_email = $col3;
			$verify_admin = $col4;
			$title = $col5;
			$company = $col6;
    	}
		
		$data = array(
			'username' =>$username,
			'email' => $email,
			'verify_email' => $verify_email,
			'verify_admin' => $verify_admin,
			'title' => $title,
			'company' => $company,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}


//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>