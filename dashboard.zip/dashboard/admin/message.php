<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}

if(isset($_POST['delete'])){
	
	$message_id = test_input($_POST['user_id_delete']);
	$user_mail = test_input($_POST['user_email_delete']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM message WHERE email = ? AND id = ? ");
	$stm->bind_param("ss",$user_mail,$message_id);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		$flag = 0;
		
		if (($stmt = $db->prepare("DELETE FROM message WHERE id = ? AND email = ?"))) {
			if ($stmt->bind_param("ss",$message_id,$user_mail)) {
				if ($stmt->execute()){
					header('location: message.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
		}
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
if(isset($_POST['mail'])){
	
	$message_id = test_input($_POST['user_id_mail']);
	$user_mail = test_input($_POST['user_email_mail']);
	$user_name = test_input($_POST['user_name_mail']);
	
	$message_heading = test_input($_POST['user_head_mail']);
	$message_mail_desc = test_input($_POST['user_mail_desc']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM message WHERE email = ? AND id = ? ");
	$stm->bind_param("ss",$user_mail,$message_id);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		
		//now sent this to the mail
		$_SESSION['email'] = $user_mail;
		$_SESSION['name'] = $user_name;
		$_SESSION['message_email'] = true;
		$_SESSION['heading'] = $message_heading;
		$_SESSION['messages'] = $message_mail_desc;
		$_SESSION['page'] = '../dashboard/admin/message.php';
		header("location: ../../email/message_mail.php");
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Admin | Messages</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >
<style>
.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}	
</style>
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header" >
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="manage_jobs.php">Jobs</a></li>
				<li><a href="coupons.php">Coupons</a></li>
				<li><a href="message.php" id="current">Messages</a></li>
				<li><a href="#">Manage Accounts</a>
					<ul>
						<li><a href="mass.php" >Mass Recruiter</a></li>
						<li><a href="freelance.php" >Freelance</a></li>
						<li><a href="campus.php" >Campus Connect</a></li>
					</ul>
				</li>
				<li><a href="#">Queries</a></li>
				<li><a href="#">Emails</a>
					<ul>
						<li><a href="#" >Single Email</a></li>
						<li><a href="#" >Mass Email</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#">SMS</a>
					<ul>
						<li><a href="#" >Single SMS</a></li>
						<li><a href="#" >Mass SMS</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>';
								echo '<li><a href="profile.php"><i class="fa fa-adjust"></i> Edit Details</a></li>';
							}
						?>
						<li><a href="address.php"><i class="fa fa-map-marker"></i> Addresses</a></li>
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/mac_4-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-sticky-note-o"></i> Messages </h2>
		</div>
	</div>
</div>



<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25">Your Messages are shown below.</p>

		<table class="manage-table resumes responsive-table">

			<tr>
				<th><i class="fa fa-file-text"></i> Sender Name</th>
				<th><i class="fa fa-angle-double-right"></i> Email</th>
				<th><i class="fa fa-file-text-o"></i> Message</th>
				<th><i class="fa fa-check-square-o"></i> Callback ?</th>
				<th><i class="fa fa-phone"></i> Phone</th>
				<th><i class="fa fa-calendar-times-o"></i>Callback In</th>
				<th><i class="fa fa-check-square-o"></i> Action</th>
				<th></th>
			</tr>

			<!-- Item #1 -->
			<?php  
			$stm = $db->prepare("SELECT * FROM message WHERE type='contactus' ORDER BY send DESC");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				$status = "";
				if($rim['request_callback'] == '1')
					$status = 'Yes';
				else if($rim['request_callback'] == '0')
					$status = 'No';
				echo '
			<tr>
				<td class="alert-name">'.$rim['name'].'</td>
				<td>'.$rim['email'].'</td>
				<td>'.$rim['message'].'</td>
				<td>'.$status.'</td>
				<td>'.$rim['phone'].'</td>
				<td>'.$rim['callback_time'].' Hours</td>
				<td>'.date("g:i a F j, Y ", strtotime($rim["send"])).'</td>
				<td class="action">
					<a href="#" data-toggle="modal" data-target="#mail-dialog" onClick="mail('.$rim['id'].')"><i class="fa fa-envelope"></i> Email</a>
					<a href="#" data-toggle="modal" data-target="#delete-dialog" onClick="delbox('.$rim['id'].')"><i class="fa fa-remove"></i> Delete</a>
				</td>
			</tr>';
			}
		?>

		</table>

		<br>

		<!-- delete box-->
		<div class="modal fade" id="delete-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Delete Message</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="User Name" readonly required maxlength="100" name="user_name_delete" id="user_name_delete" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="email" placeholder="User Email" readonly required maxlength="255" name="user_email_delete" id="user_email_delete" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" placeholder="User Id" readonly required maxlength="255" name="user_id_delete" id="user_id_delete" />
				    </div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-danger" name="delete">Delete Message</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		  
		  
		  <!--mail box-->
		  <div class="modal fade" id="mail-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Mail to Enquiry User</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="User Name" readonly required maxlength="100" name="user_name_mail" id="user_name_mail" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="email" placeholder="User Mail" readonly required maxlength="255" name="user_email_mail" id="user_email_mail" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none" >
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="user_id_mail" id="user_id_mail" />
				    </div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group" >
						<input type="text" placeholder="Enter Mail Heading" required maxlength="255" name="user_head_mail" />
				    </div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<textarea maxlength="10000" required rows="10" style="resize:none" name="user_mail_desc" spellcheck="true" placeholder="Enter Message"></textarea>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="mail">Send Mail</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		
	</div>

</div>

<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<script>
	
	function mail(mia){
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{mail: mia },
        success: function(data){
			var result = $.parseJSON(data);
			$('#user_name_mail').val(result.name);
    		$('#user_email_mail').val(result.email);
			$('#user_id_mail').val(mia);
        }
     }); 
		
	}
	
	function delbox(del){	
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{mail: del },
        success: function(data){
			var result = $.parseJSON(data);
			$('#user_name_delete').val(result.name);
    		$('#user_email_delete').val(result.email);
			$('#user_id_delete').val(del);
        }
     }); 
		
	}
	
</script>

</body>

</html>