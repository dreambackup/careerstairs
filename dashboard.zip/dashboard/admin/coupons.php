<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}
if(isset($_POST['save'])){
	
	$err = "";
	
	$coupon_name = test_input($_POST['coupon_name_add']);
	$company_name = test_input($_POST['company_name_add']);
	$expiry = test_input($_POST['expiry_date_add']);
	$coupon_limit = test_input($_POST['coupon_limt_add']);
	$coupon_url = test_input($_POST['coupon_add_url']);
	$coupon_visible = test_input($_POST['coupon_select_visible']);
	$coupon_usertype = test_input($_POST['coupon_select_type']);
	$coupon_description = test_input($_POST['coupon_name_desc']);
	$temp_terms = $_POST['coupon_add'];
	$terms = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($temp_terms))));
	
	if(isset($coupon_name) && !empty($coupon_name) && strlen($coupon_name)<101){	
	}
	else
		$err = $err . "There is a problem with Coupon Name <br/>";
	
	if(isset($company_name) && !empty($company_name) && strlen($company_name)<256){
	}
	else
		$err = $err . "There is a problem with Company Name <br/>";
	
	if(isset($expiry) && !empty($expiry)){	
	}
	else
		$err = $err . "Problem with Coupon Expiration date </br>";
	
	if(isset($coupon_description) && !empty($coupon_description) && strlen($coupon_description)<1001){
	}
	else
		$err = $err . "There is a problem with Coupon Description <br/>";
	
	if(isset($coupon_visible) && !empty($coupon_visible) && ($coupon_visible == 'Yes' || $coupon_visible == 'No')){
	}
	else
		$err = $err . "There is a problem with Visibilty Option <br/>";
	
	if(isset($coupon_usertype) && !empty($coupon_usertype) && ($coupon_usertype == 'Jobseekers' || $coupon_usertype == 'Recruiters' || $coupon_usertype == 'Both' )){
	}
	else
		$err = $err . "There is a problem with target Coupon Audience <br/>";
	
	
	if($err == ""){
		
		$flag = 0;
		if (($stm = $db->prepare("INSERT INTO coupons(code,visible,user_type,company_name,expiry,coupon_limit,description,terms,coupon_url) VALUES(?,?,?,?,?,?,?,?,?)"))) {
			if ($stm->bind_param("sssssssss",$coupon_name,$coupon_visible,$coupon_usertype,$company_name,$expiry,$coupon_limit,$coupon_description,$terms,$coupon_url)) {
				if ($stm->execute()){
					header('location: coupons.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
		}
		
	}
	else if($err !=""){
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"'.$err.'", "error");}, 100);</script>';
	}
	
}
if(isset($_POST['edit'])){
	
	$err = "";
	
	$coupon_id = test_input($_POST['coupon_id_edit']);
	$coupon_name = test_input($_POST['coupon_name_edit']);
	$company_name = test_input($_POST['company_name_edit']);
	$expiry = test_input($_POST['expiry_date_edit']);
	$coupon_limit = test_input($_POST['coupon_limt_edit']);
	$coupon_url = test_input($_POST['coupon_edit_url']);
	$coupon_visible = test_input($_POST['coupon_edit_visible']);
	$coupon_usertype = test_input($_POST['coupon_edit_type']);
	$coupon_description = test_input($_POST['coupon_desc_edit']);
	$temp_terms = $_POST['coupon_edit'];
	$terms = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($temp_terms))));
	
	if(isset($coupon_name) && !empty($coupon_name) && strlen($coupon_name)<101){	
	}
	else
		$err = $err . "There is a problem with Coupon Name <br/>";
	
	if(isset($company_name) && !empty($company_name) && strlen($company_name)<256){
	}
	else
		$err = $err . "There is a problem with Company Name <br/>";
	
	if(isset($expiry) && !empty($expiry)){	
	}
	else
		$err = $err . "Problem with Coupon Expiration date </br>";
	
	if(isset($coupon_description) && !empty($coupon_description) && strlen($coupon_description)<1001){
	}
	else
		$err = $err . "There is a problem with Coupon Description <br/>";
	
	if(isset($coupon_visible) && !empty($coupon_visible) && ($coupon_visible == 'Yes' || $coupon_visible == 'No')){
	}
	else
		$err = $err . "There is a problem with Visibilty Option <br/>";
	
	if(isset($coupon_usertype) && !empty($coupon_usertype) && ($coupon_usertype == 'Jobseekers' || $coupon_usertype == 'Recruiters' || $coupon_usertype == 'Both' )){
	}
	else
		$err = $err . "There is a problem with target Coupon Audience <br/>";
	
	if($err == ""){
		
		$flag = 0;
		
		if (($stmt = $db->prepare("UPDATE coupons SET code = ?, visible = ?, user_type = ?, company_name=?, expiry=?, coupon_limit=?, description=?, terms = ?, coupon_url =? WHERE id = ? "))) {
			if ($stmt->bind_param("ssssssssss",$coupon_name,$coupon_visible,$coupon_usertype,$company_name,$expiry,$coupon_limit,$coupon_description,$terms,$coupon_url,$coupon_id)) {
				if ($stmt->execute()){
					header('location: coupons.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
		}
		
	}
	else if($err !="")
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"'.$err.'", "error");}, 100);</script>';
	
}
if(isset($_POST['enable'])){
	
	$code_id = test_input($_POST['coupon_id_enable']);
	$coupon_name = test_input($_POST['coupon_name_enable']);
	$coupon_status = test_input($_POST['coupon_select_enable']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM coupons WHERE code = ? AND id = ? ");
	$stm->bind_param("ss",$coupon_name,$code_id);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1 && ($coupon_status == '0' || $coupon_status == '1')){
		$flag = 0;
		
		if (($stmt = $db->prepare("UPDATE coupons SET status = ? WHERE id = ? AND code = ?"))) {
			if ($stmt->bind_param("sss",$coupon_status,$code_id,$coupon_name)) {
				if ($stmt->execute()){
					header('location: coupons.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
		}
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
if(isset($_POST['delete'])){
	
	$code_id = test_input($_POST['coupon_id_delete']);
	$coupon_name = test_input($_POST['coupon_name_delete']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM coupons WHERE code = ? AND id = ? ");
	$stm->bind_param("ss",$coupon_name,$code_id);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		$flag = 0;
		
		if (($stmt = $db->prepare("DELETE FROM coupons WHERE id = ? AND code = ?"))) {
			if ($stmt->bind_param("ss",$code_id,$coupon_name)) {
				if ($stmt->execute()){
					header('location: coupons.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
		}
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
if(isset($_POST['mail'])){
	
	$code_id = test_input($_POST['coupon_id_mail']);
	$coupon_name = test_input($_POST['coupon_name_mail']);
	
	$coupon_heading = test_input($_POST['coupon_head_mail']);
	$coupon_mail_desc = test_input($_POST['coupon_mail_desc']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM coupons WHERE code = ? AND id = ? ");
	$stm->bind_param("ss",$coupon_name,$code_id);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		
		//get users email
		$stm = $db->prepare("SELECT applied_users FROM coupons WHERE code = ? AND id = ?");
		$stm->bind_param("ss",$coupon_name,$code_id);
		$stm->execute();
		$applied_users = $stm->get_result()->fetch_object()->applied_users;
		$stm->free_result();
		
		//get id's of them
		$user = json_decode($applied_users);
		$user_count = count($user);
		for($i=0;$i<$user_count;$i++)
			$users[$i] = $user[$i][0];
		if(!empty($user))
		{
			$stm = $db->prepare("SELECT id,email FROM users_login WHERE id IN (".implode(",", $users).") ORDER BY name ASC ");
			$stm->execute();
			$ress = $stm->get_result();
			
			$mail = "";
			while($rim = $ress->fetch_assoc())
			{
				//echo $rim['email'];
				//we get the name and email now lets make a string to send
				$mail = $mail . $rim['email'];
				$mail = $mail . ",";
			}
			$mail = substr($mail,0,-1);
			//now sent this to the mail
			$_SESSION['list'] = $mail;
			$_SESSION['coupon_email'] = true;
			$_SESSION['heading'] = $coupon_heading;
			$_SESSION['messages'] = $coupon_mail_desc;
			$_SESSION['page'] = '../dashboard/admin/coupons.php';
			header("location: ../../email/coupon_mail.php");
		}
		else
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry No user has applied for this coupon !", "error");}, 100);</script>';
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Admin | Coupons</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >
<style>
.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}	
</style>
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header" >
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="manage_jobs.php">Jobs</a></li>
				<li><a href="coupons.php" id="current">Coupons</a></li>
				<li><a href="message.php">Messages</a></li>
				<li><a href="#">Manage Accounts</a>
					<ul>
						<li><a href="mass.php" >Mass Recruiter</a></li>
						<li><a href="freelance.php" >Freelance</a></li>
						<li><a href="campus.php" >Campus Connect</a></li>
					</ul>
				</li>
				<li><a href="#">Queries</a></li>
				<li><a href="#">Emails</a>
					<ul>
						<li><a href="#" >Single Email</a></li>
						<li><a href="#" >Mass Email</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#">SMS</a>
					<ul>
						<li><a href="#" >Single SMS</a></li>
						<li><a href="#" >Mass SMS</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>';
								echo '<li><a href="profile.php"><i class="fa fa-adjust"></i> Edit Details</a></li>';
							}
						?>
						<li><a href="address.php"><i class="fa fa-map-marker"></i> Addresses</a></li>
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/mac_4-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-sun-o"></i> Coupons </h2>
		</div>
	</div>
</div>



<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25">Your Coupons are shown below.</p>

		<table class="manage-table resumes responsive-table">

			<tr>
				<th><i class="fa fa-file-text"></i> Coupon Name</th>
				<th><i class="fa fa-angle-double-right"></i> Company</th>
				<th><i class="fa fa-dot-circle-o"></i> Visble</th>
				<th><i class="fa fa-exclamation-circle"></i> Valid For</th>
				<th><i class="fa fa-calendar"></i> Expiry</th>
				<th><i class="fa fa-slideshare"></i> Users</th>
				<th><i class="fa fa-check-square-o"></i> Status</th>
				<th></th>
			</tr>

			<!-- Item #1 -->
			<?php  
			$stm = $db->prepare("SELECT * FROM coupons ORDER BY expiry DESC");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				$status = "";
				if($rim['status'] == '1')
					$status = 'Enabled';
				else if($rim['status'] == '0')
					$status = 'Disabled'; 
				echo '
			<tr>
				<td class="alert-name">'.$rim['code'].'</td>
				<td>'.$rim['company_name'].'</td>
				<td>'.$rim['visible'].'</td>
				<td>'.$rim['user_type'].'</td>
				<td>'.dateformat($rim['expiry']).'</td>
				<td>'.count(json_decode($rim['applied_users'])).'</td>
				<td>'.$status.'</td>
				<td class="action">
					<a target="_blank" href="showdata.php?id='.$rim['id'].'"><i class="fa fa-check-circle-o"></i> Show Data</a>
					<a href="#" data-toggle="modal" data-target="#mail-dialog" onClick="mail('.$rim['id'].')"><i class="fa fa-envelope"></i> Email</a>
					<a href="#" data-toggle="modal" data-target="#edit-dialog" onClick="edit('.$rim['id'].')"><i class="fa fa-pencil"></i> Edit</a>
					<a href="#" data-toggle="modal" data-target="#enable-dialog" onClick="enable('.$rim['id'].')"><i class="fa fa-eye-slash"></i> Disable</a>
					<a href="#" data-toggle="modal" data-target="#delete-dialog" onClick="delbox('.$rim['id'].')"><i class="fa fa-remove"></i> Delete</a>
				</td>
			</tr>';
			}
		?>

		</table>

		<br>

		<button type="button" data-toggle="modal" data-target="#add-dialog" class="btn btn-primary" >Add Coupon</button>
		
		<!--add modal-->
		 <!-- Modal -->
		 
		  <div class="modal fade" id="add-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Add Coupon</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Coupon Name" required maxlength="100" name="coupon_name_add" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Company Name" required maxlength="255" name="company_name_add"/>
				    </div>
	
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="date" placeholder="Enter Expity Date" required name="expiry_date_add" min="<?php echo $today ?>" class="form-control" style="padding: 23px" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="number" placeholder="Enter Coupon Limit" name="coupon_limt_add" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Enter Coupon Url" maxlength="255" name="coupon_add_url" >
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_select_visible">
							<option>Select Visibility Option</option>
							<option value="Yes">Visible</option>
							<option value="No">Hidden</option>
						</select>
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_select_type">
							<option>Select Audience for Coupon</option>
							<option value="Jobseekers">Jobseekers</option>
							<option value="Recruiters">Recruiters</option>
							<option value="Both">Both</option>
						</select>
					</div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<textarea maxlength="1000" required rows="10" style="resize:none" name="coupon_name_desc" spellcheck="true" placeholder="Enter about coupon Description"></textarea>
					</div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<p class="font-gray-dark">Add terms and Conditions !</p>
						<div id="coupon_add_terms">
							<div class="form boxed">
								<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
								<textarea required class="search-field" rows="2" style="resize: none" name="coupon_add[]" maxlength="255" title="Maxlength of 255"></textarea>
							</div>
						</div>
						<div class="clearfix"></div>
						<div class="margin-top-15"></div>
						<a href="javascript:void(0)" onClick="addInput1('coupon_add_terms');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
					</div>
					  <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="save">Save Coupon</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		
		
		<!--enable box-->
		
		<div class="modal fade" id="enable-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Enable/Disable Coupon</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Coupon Name" readonly required maxlength="100" name="coupon_name_enable" id="coupon_name_enable" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="company_name_enable" id="company_name_enable" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="coupon_id_enable" id="coupon_id_enable" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_select_enable" id="coupon_select_enable">
							<option>Select an Option</option>
							<option value="1">Enable</option>
							<option value="0">Disable</option>
						</select>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="enable">Save Coupon</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		
		<!-- delete box-->
		<div class="modal fade" id="delete-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Delete Coupon</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Coupon Name" readonly required maxlength="100" name="coupon_name_delete" id="coupon_name_delete" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="company_name_delete" id="company_name_delete" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="coupon_id_delete" id="coupon_id_delete" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_select_delete" id="coupon_select_delete" disabled>
							<option>Select an Option</option>
							<option value="1">Enable</option>
							<option value="0">Disable</option>
						</select>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-danger" name="delete">Delete Coupon</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		  
		  
		  <!--edit dialog-->
		  <div class="modal fade" id="edit-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Edit Coupon</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Coupon Name" required maxlength="100" name="coupon_name_edit" id="coupon_name_edit" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Company Name" required maxlength="255" name="company_name_edit" id="company_name_edit"/>
				    </div>
	
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="date" placeholder="Enter Expity Date" required name="expiry_date_edit" min="<?php echo $today ?>" class="form-control" style="padding: 23px" id="expiry_date_edit" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="number" placeholder="Enter Coupon Limit" name="coupon_limt_edit" id="coupon_limt_edit" />
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Enter Coupon Url" maxlength="255" name="coupon_edit_url" id="coupon_edit_url" >
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_edit_visible" id="coupon_edit_visible">
							<option>Select Visibility Option</option>
							<option value="Yes">Visible</option>
							<option value="No">Hidden</option>
						</select>
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_edit_type" id="coupon_edit_type">
							<option>Select Audience for Coupon</option>
							<option value="Jobseekers">Jobseekers</option>
							<option value="Recruiters">Recruiters</option>
							<option value="Both">Both</option>
						</select>
					</div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<textarea maxlength="1000" required rows="10" style="resize:none" name="coupon_desc_edit" spellcheck="true" placeholder="Enter about coupon Description" id="coupon_desc_edit" ></textarea>
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" readonly required maxlength="255" name="coupon_id_edit" id="coupon_id_edit" />
				    </div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<p class="font-gray-dark">Add terms and Conditions !</p>
						<div id="coupon_edit_terms">
							
						</div>
						<div class="clearfix"></div>
						<div class="margin-top-15"></div>
						<a href="javascript:void(0)" onClick="editInput('coupon_edit_terms');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
					</div>
					  <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="edit">Edit Coupon</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		  
		  <!--mail box-->
		  <div class="modal fade" id="mail-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Mail to Coupon Users</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Coupon Name" readonly required maxlength="100" name="coupon_name_mail" id="coupon_name_mail" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="company_name_mail" id="company_name_mail" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none" >
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="coupon_id_mail" id="coupon_id_mail" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<select required class="form-control" name="coupon_select_mail" id="coupon_select_mail" disabled>
							<option>Select an Option</option>
							<option value="1">Enable</option>
							<option value="0">Disable</option>
						</select>
					</div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group" >
						<input type="text" placeholder="Enter Mail Heading" required maxlength="255" name="coupon_head_mail" />
				    </div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<textarea maxlength="10000" required rows="10" style="resize:none" name="coupon_mail_desc" spellcheck="true" placeholder="Enter Message"></textarea>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="mail">Send Mail</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		
	</div>

</div>

<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<script>

	function addInput1(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed'><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><textarea required class='search-field' rows='2' style='resize: none' name='coupon_add[]' maxlength='255' title='Maxlength of 255'></textarea></div>";
        document.getElementById(divName).appendChild(newdiv);
	}
	
	function editInput(divvname){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed'><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><textarea required class='search-field' rows='2' style='resize: none' name='coupon_edit[]' maxlength='255' title='Maxlength of 255'></textarea></div>";
        document.getElementById(divvname).appendChild(newdiv);
	}
	
	function addInput2(divnamee,divvalue){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed'><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><textarea required class='search-field' rows='2' style='resize: none' name='coupon_edit[]' maxlength='255' title='Maxlength of 255'>"+divvalue+"</textarea></div>";
        document.getElementById(divnamee).appendChild(newdiv);
	}
	
	
	
	function enable(ena){
		$("#coupon_select_enable option:selected").attr('selected', false);
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{value: ena },
        success: function(data){
			var result = $.parseJSON(data);
			$('#coupon_name_enable').val(result.code);
    		$('#company_name_enable').val(result.company_name);
			$("#coupon_select_enable option[value="+result.status+"]").attr('selected', 'selected');
			$('#coupon_id_enable').val(ena);
        }
     }); 
		
	}
	
	function mail(mia){
		$("#coupon_select_mail option:selected").attr('selected', false);
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{value: mia },
        success: function(data){
			var result = $.parseJSON(data);
			$('#coupon_name_mail').val(result.code);
    		$('#company_name_mail').val(result.company_name);
			$("#coupon_select_mail option[value="+result.status+"]").attr('selected', 'selected');
			$('#coupon_id_mail').val(mia);
        }
     }); 
		
	}
	
	function delbox(del){	
		$("#coupon_select_delete option:selected").attr('selected', false);
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{value: del },
        success: function(data){
			var result = $.parseJSON(data);
			$('#coupon_name_delete').val(result.code);
    		$('#company_name_delete').val(result.company_name);
			$("#coupon_select_delete option[value="+result.status+"]").attr('selected', 'selected');
			$('#coupon_id_delete').val(del);
        }
     }); 
		
	}
	
	function edit(edi){	
		
		var myNode = document.getElementById("coupon_edit_terms");
		while (myNode.firstChild) {
			myNode.removeChild(myNode.firstChild);
		}
		
	$.ajax({
    	type:'POST',
        url:'coupons_ajax.php',
        data:{edol: edi },
        success: function(data){
			console.log(data);
			var result = $.parseJSON(data);
			$('#coupon_name_edit').val(result.code);
    		$('#company_name_edit').val(result.company_name);
			$('#expiry_date_edit').val(result.expiry);
			$('#coupon_limt_edit').val(result.limit);
			$('#coupon_desc_edit').val(result.desc);
			$('#coupon_edit_url').val(result.coupon_url);
			$('#coupon_edit_visible').val(result.visible);
			$('#coupon_edit_type').val(result.user_type);
			var div = 'coupon_edit_terms';
			var terms = result.terms;
			for(i = 0; i < terms.length; i++)
				addInput2(div,terms[i]);
			
			$('#coupon_id_edit').val(edi);
        }
     }); 
		
	}
	
</script>

</body>

</html>