<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true && isset($_POST['preview'])) {
	
	$today = date("Y-m-d");
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	
	$err = "";
	$email = test_input(mb_strtolower($_POST["email"]));
	$title = test_input(ucname($_POST["title"]));
	$location = test_input($_POST["location"]);
	$jobtype = test_input($_POST["jobtype"]);
	
	$category = test_input($_POST['category']);
	$skills = test_input($_POST["skills"]);
	$about_job = test_input($_POST["about_job"]);
	$exper = test_input($_POST["exper"]);
	$min_sal = test_input($_POST["min_sal"]);
	$max_sal = test_input($_POST["max_sal"]);
	$educations = test_input($_POST["educations"]);
	$batch = $_POST["batch"];
	$description = $_POST["description"];
	$close_date = test_input($_POST["close_date"]);
	$company_name = test_input($_POST["company_name"]);
	$company_website = test_input($_POST["company_website"]);
	$about_company = test_input($_POST["about_company"]);
	
	$tmp = explode('@', $email);
	$udomain = end($tmp);
	
 	$domains = array("aol.com", "gmail.com", "hotmail.com", "yahoo.com", "yahoo.co.uk", "email.com", "ymail.com","live.com", "msn.com");
	
	$allowed_type = array("Accounting / Finance","Software Developer","Marketing & Sales","Information Technology","Healthcare","Content & digital","UI / UX Developer","BPO & Telecomm","Management","Quality & Testing","Mobile App development","Hr & Company");
	
	//start validation
	if(isset($email) && !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)){
		//lets check domain
		if(!(in_array($udomain, $domains))) {
		}
		else
			$err = $err . "Public Email address are not allowed </br>";
	}
	else
		$err = $err . "Invalid Email address </br>";
	
	if(isset($title) && !empty($title)  && preg_match("/^[a-zA-Z ]*$/",$title)){
	}
	else
		$err = $err . "Only Alphabets and white space allowed in Job Title</br>";
	
	if(isset($location) && !empty($location))
	{
		$temp_location = explode(",",$location);
		$location_count = count($temp_location);
		
		if($location_count > 5)
		{
			for($i=$location_count;$i>5;$i--)
			{
				array_pop($temp_location);
			}
		}
		
		$locations = json_encode(array_map('trim',$temp_location));
	}
	else
		$err = $err . "Problem with location Input </br>";
	
	
	if(isset($jobtype) && !empty($jobtype) && ($jobtype >= '1' && $jobtype <= '4')){	
	}
	else
		$err = $err . "Only given category of jobs are there </br>";
	
	if(isset($category) && !empty($category) && in_array($category,$allowed_type)){
	}
	else
		$err = $err . "Only these Categories are available to select </br>";
	
	if(isset($skills) && !empty($skills))
	{
		$temp_skills = explode(",",$skills);
		$skills_count = count($temp_skills);
		if($skills_count > 10)
		{
			for($i=$skills_count;$i>10;$i--)
			{
				array_pop($temp_skills);
			}
		}
		$skill = json_encode(array_map('trim',$temp_skills));
	}
	else
		$err = $err . "Problem with skills Input </br>";
	
	if(isset($about_job) && !empty($about_job) && (strlen($about_job)<1000)){
	}
	else
		$err = $err . "Only 1000 characters are allowed to fill the about job </br>";
	
	if(isset($exper) && $exper >= '0' && $exper <= '6'){
	}
	else
		$err = $err . "Experience of Max 7 years are allowed </br>";
	
	if(isset($min_sal) && !empty($min_sal) && $min_sal > '0.5' && $min_sal < $max_sal){
	}
	else
		$err = $err . "There is a problem with minimum salary";
	
	if(isset($max_sal) && !empty($max_sal) && $min_sal < '10' && $min_sal < $max_sal){
	}
	else
		$err = $err . "There is a problem with Maximum salary";
	
	if(isset($educations) && !empty($educations))
	{
		$temp_educations = explode(",",$educations);
		$educations_count = count($educations);
		if($educations_count > 5)
		{
			for($i=$educations_count;$i>5;$i--)
			{
				array_pop($educations);
			}
		}
		$education = json_encode(array_map('trim',$temp_educations));
	}
	else
		$err = $err . "Problem with Education Input </br>";
	
	if(isset($batch) && !empty($batch)){
		$batch_count = count($batch);
		
		for($i=0;$i<$batch_count;$i++)
		{
			if(($batch[$i] >= 2010) && ($batch[$i] <= (2017 - $exper)))
			{
			}
			else
				$err = $err . "Problem with batch year Input </br>";
		}
	}
	
	if(isset($description) && !empty($description)){
	}
	else
		$err = $err . "Problem with Description </br>";
	
	if(isset($close_date) && !empty($close_date)){	
	}
	else
		$err = $err . "Problem with Job Expiration date </br>";
	
	if(isset($company_name) && !empty($company_name) && (strlen($company_name) < 255)){
	}
	else
		$err = $err . "Problem with Company Name </br>";
	
	if(isset($company_website) && !empty($company_website) && (strlen($company_website) < 100)){
	}
	else
		$err = $err . "Problem with Company Website </br>";
	
	if(isset($about_company) && !empty($about_company) && (strlen($about_company)<1000)){
	}
	else
		$err = $err . "Only 1000 characters are allowed to fill the about company </br>";
	
	if($err != ""){
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"'.$err.'", "error");}, 100);</script>';
	}
	
}
else{
	header('Location: ../../login.php');
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
//function to change the lowercase data to capitalize the first letter of every word
function ucname($string) {
    $string =ucwords(strtolower($string));

    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $title ?> | Job Preview</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.html"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="manage_jobs.php" id="current">Jobs</a></li>
				<li><a href="coupons.php">Coupons</a></li>
				<li><a href="message.php">Messages</a></li>
				<li><a href="#">Manage Accounts</a>
					<ul>
						<li><a href="mass.php" >Mass Recruiter</a></li>
						<li><a href="freelance.php" >Freelance</a></li>
						<li><a href="campus.php" >Campus Connect</a></li>
					</ul>
				</li>
				<li><a href="#">Queries</a></li>
				<li><a href="#">Emails</a>
					<ul>
						<li><a href="#" >Single Email</a></li>
						<li><a href="#" >Mass Email</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#">SMS</a>
					<ul>
						<li><a href="#" >Single SMS</a></li>
						<li><a href="#" >Mass SMS</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>';
								echo '<li><a href="profile.php"><i class="fa fa-adjust"></i> Edit Details</a></li>';
							}
						?>
						<li><a href="address.php"><i class="fa fa-map-marker"></i> Addresses</a></li>
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/all-categories-photo.jpg)">
	<div class="container">
		<div class="ten columns">
			<span><a href="#"><?php echo $category ?></a></span>
			<h2><?php echo $title ?>
			<?php 
				if($jobtype == 1)
					echo '<span class="full-time" >Full Time</span>';
				else if($jobtype == 2)
					echo '<span class="part-time" >Part Time</span>';
				else if($jobtype == 3)
					echo '<span class="internship" >Internship</span>';
				else if($jobtype == 4)
					echo '<span class="temporary" >Freelance</span>';
			?>
			
			</h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	<!-- Recent Jobs -->
	<div class="eleven columns">
	<div class="padding-right">
		<!-- Company Info -->
		<div class="company-info">
			<?php echo '<img src="../company_pictures/'.$_FILES['file']['name'].'" alt="'.$company_name.'" id="image" >'; ?>
			<div class="content">
				<h4><?php echo $company_name ?></h4>
				<span><a href="#"><i class="fa fa-link"></i> <?php echo $company_website ?></a></span>
			</div>
			<div class="clearfix"></div>
		</div>
		
		<h2>About Company</h2>
		<p class="margin-reset" style="text-align: justify">
			<?php echo $about_company; ?>
		</p>
		<br/>
		
		<h2>Job Details</h2>
		<p class="margin-reset" style="text-align: justify">
			<?php echo $about_job; ?>
		</p>
		<br/>
		<h4 class="margin-bottom-0">Skills Required</h4>
		<div class="skills margin-top-10">
			<?php 
				//getting skills as json then decode it in array
				$skills = json_decode($skill);
				for($i=0;$i<count($skills);$i++)
				{
					echo '<span>'.$skills[$i].'</span>';
				}
			?>		
		</div>
		<div class="clearfix"></div>
		<br/>
		
		
		<h4 class="margin-bottom-0">Education</h4>
		<span><?php echo implode(" , ",json_decode($education)) ?></span>
		<div class="clearfix"></div>
		<br/>
		
		<h4 class="margin-bottom-0">Batch</h4>
		<span><?php echo implode(" , ",$batch) ?></span>
		<div class="clearfix"></div>
		<br/>
		
		<h4 class="margin-bottom-10">Job Description</h4>

		
		<ul class="list-1" style="text-align: justify">
			<?php $job_description = $description;
			
				for($i=0;$i<count($job_description);$i++)
				{
					echo '<li>'.$job_description[$i].'</li>';
				}
			?>
		</ul>

	</div>
	</div>


	<!-- Widgets -->
	<div class="five columns">

		<!-- Sort by -->
		<div class="widget">
			<h4>Overview</h4>

			<div class="job-overview">
				
				<ul>
					<li>
						<i class="fa fa-calendar-times-o"></i>
						<div>
							<strong>Last Date :</strong>
							<span><?php echo dateformat($close_date) ?></span>
						</div>
					</li>
					<li>
						<i class="fa fa-map-marker"></i>
						<div>
							<strong>Location:</strong>
							<span><?php echo implode(" , ",json_decode($locations)) ?></span>
						</div>
					</li>
					<li>
						<i class="fa fa-user"></i>
						<div>
							<strong>Job Title:</strong>
							<span><?php echo $title ?></span>
						</div>
					</li>
					<li>
						<i class="fa fa-calendar"></i>
						<div>
							<strong>Experience </strong>
							<span><?php echo $exper ?>+ Years</span>
						</div>
					</li>
					<li>
						<i class="fa fa-inr"></i>
						<div>
							<strong>Salary:</strong>
							<span><?php echo $min_sal; echo" - "; echo $max_sal ?> LPA</span>
						</div>
					</li>
				</ul>

				<a class="button" style="background-color: #FA8072;pointer-events: none;cursor: default;">Not Visible</a>

			</div>
		</div>

	</div>
	<!-- Widgets / End -->


</div>


<!-- Footer
================================================== -->
<div class="margin-top-50"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

 <script>
        var a = localStorage.getItem('url');
	 $("#image").attr("src",a);
 </script>

</body>

</html>