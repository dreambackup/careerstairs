<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}


if(isset($_POST['enable'])){
	
	$job_id = test_input($_POST['job_id']);
	$job_name = test_input($_POST['job_title_enable']);
	$recruiter = test_input($_POST['job_name_username']);
	$admin_status = test_input($_POST['job_select_admin']);
	$email_status = test_input($_POST['job_select_email']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM jobs WHERE id = ? AND rec_username = ? AND job_title = ? ");
	$stm->bind_param("sss",$job_id,$recruiter,$job_name);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1 && ($email_status == '0' || $email_status == '1') && ($admin_status == '0' || $admin_status == '1') ){
		$flag = 0;
		
		if (($stmt = $db->prepare("UPDATE jobs SET email_verified = ?, admin_verified = ? WHERE id = ? AND rec_username = ? AND job_title = ?"))) {
			if ($stmt->bind_param("sssss",$email_status,$admin_status,$job_id,$recruiter,$job_name)) {
				if ($stmt->execute()){
					header('location: manage_jobs.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
		}
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}
if(isset($_POST['delete'])){
	
	$job_id = test_input($_POST['job_id_del']);
	$job_name = test_input($_POST['job_title_enable_del']);
	$recruiter = test_input($_POST['job_name_username_del']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM jobs WHERE id = ? AND rec_username = ? AND job_title = ? ");
	$stm->bind_param("sss",$job_id,$recruiter,$job_name);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		$flag = 0;
		//delete the image too
		$stm = $db->prepare("SELECT company_pic FROM jobs WHERE id = ? AND rec_username = ?");
		$stm->bind_param("ss",$job_id,$recruiter);
		$stm->execute();
		$picture = $stm->get_result()->fetch_object()->company_pic;
		$stm->free_result();
			
			$upload_dir = '../company_pictures/';
			unlink($upload_dir.$picture);
		
		if (($stmt = $db->prepare("DELETE FROM jobs WHERE id = ? AND rec_username = ? AND job_title = ?"))) {
			if ($stmt->bind_param("sss",$job_id,$recruiter,$job_name)) {
				if ($stmt->execute()){
					header('location: manage_jobs.php');
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
		
		if($flag == 1){
				echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
		}
		
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry there is something wrong with the inputs provided. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Admin | Manage Jobs</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >

<!-- Datatables -->
	<link href="datatable/custom.min.css" rel="stylesheet">
    <link href="datatable/bootstrap.min.css" rel="stylesheet">
    <link href="datatable/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="datatable/responsive.bootstrap.min.css" rel="stylesheet">

<style>
.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}	
</style>
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header" >
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="manage_jobs.php" id="current">Jobs</a></li>
				<li><a href="coupons.php">Coupons</a></li>
				<li><a href="message.php">Messages</a></li>
				<li><a href="#">Manage Accounts</a>
					<ul>
						<li><a href="mass.php" >Mass Recruiter</a></li>
						<li><a href="freelance.php" >Freelance</a></li>
						<li><a href="campus.php" >Campus Connect</a></li>
					</ul>
				</li>
				<li><a href="#">Queries</a></li>
				<li><a href="#">Emails</a>
					<ul>
						<li><a href="#" >Single Email</a></li>
						<li><a href="#" >Mass Email</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#">SMS</a>
					<ul>
						<li><a href="#" >Single SMS</a></li>
						<li><a href="#" >Mass SMS</a></li>
						<li><a href="#" >Select & Send</a></li>
						<li><a href="#" >Query</a></li>
					</ul>
				</li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>';
								echo '<li><a href="profile.php"><i class="fa fa-adjust"></i> Edit Details</a></li>';
							}
						?>
						<li><a href="address.php"><i class="fa fa-map-marker"></i> Addresses</a></li>
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/mac_4-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-sun-o"></i> Manage Jobs </h2>
		</div>
	</div>
</div>



<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25">Recent Jobs which need attention are shown below.</p>

		<table class="manage-table resumes responsive-table">

			<tr>
				<th><i class="fa fa-file-text"></i> Job Name</th>
				<th><i class="fa fa-angle-double-right"></i> Company</th>
				<th><i class="fa fa-calendar"></i> Expiry</th>
				<th><i class="fa fa-slideshare"></i>Posted User</th>
				<th><i class="fa fa-envelope"></i>Email</th>
				<th><i class="fa fa-drupal"></i>Type</th>
				<th><i class="fa fa-check-square-o"></i> Status</th>
				<th></th>
			</tr>

			<!-- Item #1 -->
			<?php  
			$stm = $db->prepare("SELECT * FROM jobs WHERE admin_verified= '0' ORDER BY created DESC");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				//get recruiter name
				$stm = $db->prepare("SELECT name FROM users_login WHERE oauth_uid = ?");
				$stm->bind_param("s",$rim['rec_username']);
				$stm->execute();
				$name = $stm->get_result()->fetch_object()->name;
				
				//getting type
				$stm = $db->prepare("SELECT type FROM recruiter_profile WHERE username = ?");
				$stm->bind_param("s",$rim['rec_username']);
				$stm->execute();
				$type = $stm->get_result()->fetch_object()->type;
				
				$status = "";
				if($rim['email_verified'] == '1')
					$status = 'Verified';
				else if($rim['email_verified'] == '0')
					$status = 'Not Verified';
				echo '
			<tr>
				<td class="alert-name"><a target="_blank" href="job-overview.php?id='.$rim['id'].'">'.$rim['job_title'].'</a></td>
				<td>'.$rim['company_name'].'</td>
				<td>'.dateformat($rim['expiration']).'</td>
				<td><a target="_blank" href="profile.php?id='.$rim['rec_username'].'">'.$name.'</a></td>
				<td>'.$rim['rec_email'].'</td>
				<td>'.$type.'</td>
				<td>'.$status.'</td>
				<td class="action">
					<a target="_blank" href="edit_job.php?id='.$rim['id'].'"><i class="fa fa-pencil"></i> Edit</a>
					<a href="#" data-toggle="modal" data-target="#enable-dialog" onClick="enable('.$rim['id'].')"><i class="fa fa-eye"></i> Enable</a>
					<a href="#" data-toggle="modal" data-target="#delete-dialog" onClick="delbox('.$rim['id'].')"><i class="fa fa-remove"></i> Delete</a>
				</td>
			</tr>';
			}
		?>

		</table>

		<br>

		<p class="margin-bottom-25">Other Jobs are shown below.</p>
		
		
		<table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" width="100%" cellspacing="0" >
        	<thead>
            	<tr>
                	<th>#</th>
                    <th>ID </th>
                    <th>Job Title</th>
                    <th>Company</th>
                    <th>Expiry</th>
                    <th>Recuiter</th>
                    <th>E-mail</th>
                    <th>Phone</th>
                    <th>Users</th>  
                    <th>Status</th>
                    <th>Action</th>      
                </tr>
            </thead>

			<?php 
				$count = 1;
					
				$stm = $db->prepare("SELECT id,rec_username,rec_email,email_verified,admin_verified,job_title,company_name,company_website,applied_id,expiration FROM jobs WHERE admin_verified = '1' ORDER BY expiration DESC ");
				$stm->execute();
				$ress = $stm->get_result();
				
				while($rim = $ress->fetch_assoc())
					{
						//get the gender,state and city
						if($today <= $rim['expiration'])
							$status = 'Active';
						else
							$status = 'Expired';
						//get recruiter name
						$stm = $db->prepare("SELECT name FROM users_login WHERE oauth_uid = ?");
						$stm->bind_param("s",$rim['rec_username']);
						$stm->execute();
						$name = $stm->get_result()->fetch_object()->name;

						//getting type
						$stm = $db->prepare("SELECT phone FROM users_login WHERE oauth_uid = ?");
						$stm->bind_param("s",$rim['rec_username']);
						$stm->execute();
						$phone = $stm->get_result()->fetch_object()->phone;
						
						echo '
							<tr>
								<td>'.$count.'</td>
								<td>'.$rim['id'].'</td>
								<td><a target="_blank" href="job-overview.php?id='.$rim['id'].'" class="btn btn-info">'.$rim['job_title'].'</a></td>
								<td>'.$rim['company_name'].'</td>
								<td>'.dateformat($rim['expiration']).'</td>
								<td><a target="_blank" href="profile.php?id='.$rim['rec_username'].'" class="btn btn-success">'.$name.'</a></td>
								<td>'.$rim['rec_email'].'</td>
								<td>'.$phone.'</td>
								<td class="centered"><a target="_blank" href="user-applications.php?id='.$rim['id'].'" class="btn btn-danger">'.count(json_decode($rim['applied_id'])).'</a></td>
								<td>'.$status.'</td>
								<td class="action">
									<a target="_blank" href="edit_job.php?id='.$rim['id'].'"><i class="fa fa-pencil"></i> Edit</a>
									<br/>
									<a href="#" data-toggle="modal" data-target="#enable-dialog" onClick="enable('.$rim['id'].')"><i class="fa fa-eye"></i> Enable</a>
									<br/>
									<a href="#" data-toggle="modal" data-target="#delete-dialog" onClick="delbox('.$rim['id'].')"><i class="fa fa-remove"></i> Delete</a>
								</td>

							</tr>
						';
						
						$count++;
					}
				
			
			?>
				
            
         </table>
		
		
		<!--enable box-->
		
		<div class="modal fade" id="enable-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Enable Job</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
				  		<label>Job Title</label>
						<input type="text" placeholder="Job Title" readonly required maxlength="100" name="job_title_enable" id="job_title_enable" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Company Name</label>
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="job_name_company" id="job_name_company" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Recruiter Username</label>
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="job_name_username" id="job_name_username" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Job Mail</label>
						<input type="text" placeholder="Recruiter Mail" readonly required maxlength="255" name="job_name_email" id="job_name_email" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" placeholder="Job ID" readonly required maxlength="10" name="job_id" id="job_id" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Job Status</label>
						<select required class="form-control" name="job_select_admin" id="job_select_admin">
							<option>Select an Option</option>
							<option value="1">Enable</option>
							<option value="0">Disable</option>
						</select>
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Does Recruiter Verifies Email ?</label>
						<select required class="form-control" name="job_select_email" id="job_select_email">
							<option>Select an Option</option>
							<option value="1">Verified</option>
							<option value="0">Not Verified</option>
						</select>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-primary" name="enable">Save Job</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		
		<!-- delete box-->
		<div class="modal fade" id="delete-dialog" role="dialog">
			<div class="modal-dialog modal-lg">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Delete Job</h4>
				</div>
				<div class="modal-body">
				  
				  <form method="post" autocomplete="off" >
				  
				  	<div class="col-md-4 col-sm-12 col-xs-12 form-group">
				  		<label>Job Title</label>
						<input type="text" placeholder="Job Title" readonly required maxlength="100" name="job_title_enable_del" id="job_title_enable_del" />
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Company Name</label>
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="job_name_company_del" id="job_name_company_del" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Recruiter Username</label>
						<input type="text" placeholder="Company Name" readonly required maxlength="255" name="job_name_username_del" id="job_name_username_del" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Job Mail</label>
						<input type="text" placeholder="Recruiter Mail" readonly required maxlength="255" name="job_name_email_del" id="job_name_email_del" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group" style="display: none">
						<input type="text" placeholder="Job ID" readonly required maxlength="10" name="job_id_del" id="job_id_del" />
				    </div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Job Status</label>
						<select required class="form-control" name="job_select_admin_del" id="job_select_admin_del" disabled>
							<option>Select an Option</option>
							<option value="1">Enable</option>
							<option value="0">Disable</option>
						</select>
					</div>
					
					<div class="col-md-4 col-sm-12 col-xs-12 form-group">
						<label>Does Recruiter Verifies Email ?</label>
						<select required class="form-control" name="job_select_email_del" id="job_select_email_del" disabled>
							<option>Select an Option</option>
							<option value="1">Verified</option>
							<option value="0">Not Verified</option>
						</select>
					</div>
					
					 <div class="clearfix"></div>
				</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					   <button type="submit" class="btn btn-danger" name="delete">Delete Job</button>
					</div>
				
				</form>
				
			  </div>
			</div>
		  </div>
		  
		
	</div>

</div>

<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    

<!-- Datatables -->
    <script src="datatable/jquery.dataTables.min.js"></script>
    <script src="datatable/dataTables.bootstrap.min.js"></script>
    <script src="datatable/dataTables.buttons.min.js"></script>
    <script src="datatable/buttons.bootstrap.min.js"></script>
    <script src="datatable/buttons.flash.min.js"></script>
    <script src="datatable/buttons.html5.min.js"></script>
    <script src="datatable/buttons.print.min.js"></script>
    <script src="datatable/dataTables.keyTable.min.js"></script>
    <script src="datatable/dataTables.responsive.min.js"></script>
    <script src="datatable/responsive.bootstrap.js"></script>
    <script src="datatable/datatables.scroller.min.js"></script>
    <script src="datatable/jszip.min.js"></script>
    <script src="datatable/pdfmake.min.js"></script>
    <script src="datatable/vfs_fonts.js"></script>
<!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
			  retrieve: true,
    		paging: true,
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();
		
        TableManageButtons.init();
      });
    </script>



<script>
	
	function enable(ena){
		$("#job_select_admin option:selected").attr('selected', false);
		$("#job_select_email option:selected").attr('selected', false);
	$.ajax({
    	type:'POST',
        url:'jobs_ajax.php',
        data:{value: ena },
        success: function(data){
			var result = $.parseJSON(data);
			$('#job_title_enable').val(result.title);
    		$('#job_name_company').val(result.company);
			$('#job_name_username').val(result.username);
			$('#job_name_email').val(result.email);
			$("#job_select_admin option[value="+result.verify_admin+"]").attr('selected', 'selected');
			$("#job_select_email option[value="+result.verify_email+"]").attr('selected', 'selected');
			$('#job_id').val(ena);
        }
     }); 
		
	}
	
	function delbox(del){	
		$("#job_select_admin_del option:selected").attr('selected', false);
		$("#job_select_email_del option:selected").attr('selected', false);
	$.ajax({
    	type:'POST',
        url:'jobs_ajax.php',
        data:{value: del },
        success: function(data){
			var result = $.parseJSON(data);
			$('#job_title_enable_del').val(result.title);
    		$('#job_name_company_del').val(result.company);
			$('#job_name_username_del').val(result.username);
			$('#job_name_email_del').val(result.email);
			$("#job_select_admin_del option[value="+result.verify_admin+"]").attr('selected', 'selected');
			$("#job_select_email_del option[value="+result.verify_email+"]").attr('selected', 'selected');
			$('#job_id_del').val(del);
        }
     }); 
		
	}
	
	
</script>

</body>

</html>