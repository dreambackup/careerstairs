<?php
	session_start();
	//Include database configuration file
	include('../../db/config.php');

	error_reporting(0);

	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
	}
	else{
		header('Location: ../../login.php');
	}


	if(isset($_POST["value"]) && !empty($_POST["value"])){
		
		$id = test_input($_POST["value"]);
		
		$stm = $db->prepare("SELECT status,code,company_name FROM coupons WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1, $col2,$col3);

		while ($stm->fetch()) {
        	$status = $col1;
			$code = $col2;
			$company_name = $col3;
    	}
		
		$data = array(
			'status' =>$status,
			'code' => $code,
			'company_name' => $company_name,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

	if(isset($_POST["mail"]) && !empty($_POST["mail"])){
		
		$id = test_input($_POST["mail"]);
		
		$stm = $db->prepare("SELECT name,email FROM message WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2);

		while ($stm->fetch()) {
        	$name = $col1;
			$email = $col2;
    	}
		
		$data = array(
			'name' =>$name,
			'email' => $email,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

	if(isset($_POST["del_lastmail"]) && !empty($_POST["del_lastmail"])){
		
		$id = test_input($_POST["del_lastmail"]);
		
		$stm = $db->prepare("SELECT name,email FROM campus_user WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2);

		while ($stm->fetch()) {
        	$name = $col1;
			$email = $col2;
    	}
		
		$data = array(
			'name' =>$name,
			'email' => $email,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

	if(isset($_POST["edol"]) && !empty($_POST["edol"])){
		
		$id = test_input($_POST["edol"]);
		$stm = $db->prepare("SELECT status,code,company_name,expiry,coupon_limit,description,coupon_url,terms,visible,user_type FROM coupons WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3,$col4,$col5,$col6,$col7,$col8,$col9,$col10);

		while ($stm->fetch()) {
        	$status = $col1;
			$code = $col2;
			$company_name = $col3;
			$expiry = $col4;
			$limit = $col5;
			$desc = $col6;
			$coupon_url = $col7;
			$terms = json_decode($col8);
			$visible = $col9;
			$user_type = $col10;
    	}
		
		$data = array(
			'status' =>$status,
			'code' => $code,
			'company_name' => $company_name,
			'expiry' => $expiry,
			'limit' => $limit,
			'desc' => $desc,
			'coupon_url' => $coupon_url,
			'terms' => $terms,
			'visible' => $visible,
			'user_type' => $user_type,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

	if(isset($_POST["campus_mail"]) && !empty($_POST["campus_mail"])){
		
		$id = test_input($_POST["campus_mail"]);
		
		$stm = $db->prepare("SELECT tpo_name, tpo_email, college_name FROM campus WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3);

		while ($stm->fetch()) {
        	$name = $col1;
			$email = $col2;
			$college = $col3;
    	}
		
		$data = array(
			'name' =>$name,
			'email' => $email,
			'campus_name' => $college,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>