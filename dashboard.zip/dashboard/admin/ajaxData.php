<?php
//Include database configuration file
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['admin'] == true) {
}
else{
	header('Location: ../../login.php');
}

// code to check email duplication

if(isset($_POST["email"]) && !empty($_POST["email"])){
    $email = test_input($_POST["email"]);
	$stm = $db->prepare("SELECT email FROM users_login WHERE email = ? ");
	$stm->bind_param("s",$email);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

// code to check phone duplicasy
if(isset($_POST["phone"]) && !empty($_POST["phone"])){
    $phone = test_input($_POST["phone"]);
	$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
	$stm->bind_param("s",$phone);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

// code to check phone duplicasy
if(isset($_POST["username"]) && !empty($_POST["username"])){
    $username = test_input($_POST["username"]);
	$count = 0;
	$stm = $db->prepare("SELECT oauth_uid FROM users_login WHERE oauth_uid = ? ");
	$stm->bind_param("s",$username);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

	if(isset($_POST["mass_job_details"]) && !empty($_POST["mass_job_details"])){
		
		$id = test_input($_POST["mass_job_details"]);
		
		$stm = $db->prepare("SELECT location,happen_date,job_title,mass_username FROM mass_jobs WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3,$col4);

		while ($stm->fetch()) {
        	$location = $col1;
			$date = $col2;
			$title = $col3;
			$user = $col4;
    	}
		
		$data = array(
			'location' =>$location,
			'date' => $date,
			'title' => $title,
			'user' => $user,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

if(isset($_POST["mass_job_delete"]) && !empty($_POST["mass_job_delete"])){
		
		$id = test_input($_POST["mass_job_delete"]);
		
		$stm = $db->prepare("SELECT mass_username,job_title FROM mass_jobs WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1,$col2);

		while ($stm->fetch()) {
        	$user = $col1;
			$title = $col2;
    	}
		
		$data = array(
			'user' =>$user,
			'title' => $title,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

if(isset($_POST["addressvalue"]) && !empty($_POST["addressvalue"])){
		
		$id = test_input($_POST["addressvalue"]);
		
		$stm = $db->prepare("SELECT address FROM mass_address WHERE id = ? ");
		$stm->bind_param("s",$id);
		$stm->execute();
		$stm->bind_result($col1);

		while ($stm->fetch()) {
        	$address = $col1;
    	}
		
		$data = array(
			'address' =>$address,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>