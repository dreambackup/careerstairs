<?php
include('../../db/config.php');
session_start();
error_reporting(0);
$jobid = test_input($_GET['id']);
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//now fetch the job details
	$count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ?");
	$stm->bind_param("s",$jobid);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1)
	{
		$stm = $db->prepare("SELECT company_name FROM mass_profile WHERE username = ?");
		$stm->bind_param("s",$_SESSION['userData']);
		$stm->execute();
		$ress = $stm->get_result();
		$roww = $ress->fetch_assoc();
		$stm->free_result();
		
		$stm = $db->prepare("SELECT * FROM mass_jobs WHERE mass_username = ? AND id = ?");
		$stm->bind_param("ss",$_SESSION['userData'],$jobid);
		$stm->execute();
		$ress = $stm->get_result();
		$rowwed = $ress->fetch_assoc();
		$stm->free_result();
		
		
		//get data
		//will create temp table here
		$stm = $db->prepare("CREATE TEMPORARY TABLE applicants(
		id INT UNSIGNED NOT NULL,
		username VARCHAR(255) NOT NULL,
		full_name VARCHAR(255) NOT NULL, 
		email VARCHAR(255) NOT NULL , 
		phone VARCHAR(12), 
		gender VARCHAR(6),
		state VARCHAR(50),
		city VARCHAR(100),
		status VARCHAR(8) ,
		score1 VARCHAR(2) ,
		score2 VARCHAR(2) ,
		score3 VARCHAR(2) ,
		score4 VARCHAR(2) ,
		score5 VARCHAR(2) ,
		remark VARCHAR(255),
		PRIMARY KEY(id)
		)");
		$stm->execute();
		$stm->free_result();
		
		//now insert data
		$user = json_decode($rowwed['users']);
		$user_count = count($user);
		for($i=0;$i<$user_count;$i++)
			$users[$i] = $user[$i][0];
		
		if(!empty($user))
		{
			$count = 1;	
			$stm = $db->prepare("SELECT id,oauth_provider,oauth_uid,name,gender,link,email,phone,picture FROM users_login WHERE id IN (".implode(",", $users).") ORDER BY name ASC ");
			$stm->execute();
			$ress = $stm->get_result();
			
			while($rim = $ress->fetch_assoc())
			{
				//get the gender,state and city
						
				$stm = $db->prepare("SELECT state FROM users_profile WHERE id = ?");
				$stm->bind_param("s",$rim['id']);
				$stm->execute();
				$state = $stm->get_result()->fetch_object()->state;
				$stm->free_result();
				//city
				$stm = $db->prepare("SELECT city FROM users_profile WHERE id = ?");
				$stm->bind_param("s",$rim['id']);
				$stm->execute();
				$city = $stm->get_result()->fetch_object()->city;
				$stm->free_result();
						
				//get status
				for($i=0;$i<$user_count;$i++)
				{
					if($user[$i][0] == $rim['id'])
					{
						$status = $user[$i][1];
						$score1 = $user[$i][2];
						$score2 = $user[$i][3];
						$score3 = $user[$i][4];
						$score4 = $user[$i][5];
						$score5 = $user[$i][6];
						$remark = $user[$i][7];
						break;
					}
				}
						
				$stm = $db->prepare("INSERT INTO applicants(id,username,full_name,email,phone,gender,state,city,status,score1,score2,score3,score4,score5,remark) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				$stm->bind_param("sssssssssssssss",$count,$rim['oauth_uid'],$rim['name'],$rim['email'] ,$rim['phone'],$rim['gender'],$state,$city,$status,$score1 ,$score2,$score3,$score4,$score5,$remark);
				$stm->execute();
				$stm->free_result();
				
				$count++;
			}
		}
		
		$query_one = "SELECT * FROM applicants";
		
	}
	else{
		header("Location: index.php");
	}

}
else{
	header('Location: ../../login.php');
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$communication = $knowledge = $skills = $personality = $confidence = $status = $less11 = $gret12 = $less21 = $gret22 = $less31 = $gret32 = $less41 = $gret42 = $less51 = $gret52 = '';
if(isset($_POST['reset'])){
	$communication = $knowledge = $skills = $personality = $confidence = $status = $less11 = $gret12 = $less21 = $gret22 = $less31 = $gret32 = $less41 = $gret42 = $less51 = $gret52 = '';
}
if(isset($_POST['filter'])){

	$communication = test_input($_POST['communication']);
	$knowledge = test_input($_POST['knowledge']);
	$skills = test_input($_POST['skills']);
	$personality = test_input($_POST['personality']);
	$confidence = test_input($_POST['confidence']);
	$status = test_input($_POST['status']);
	
	$less11 = test_input($_POST['score1less']);
	$gret12 = test_input($_POST['score1gret']);
	$less21 = test_input($_POST['score2less']);
	$gret22 = test_input($_POST['score2gret']);
	$less31 = test_input($_POST['score3less']);
	$gret32 = test_input($_POST['score3gret']);
	$less41 = test_input($_POST['score4less']);
	$gret42 = test_input($_POST['score4gret']);
	$less51 = test_input($_POST['score5less']);
	$gret52 = test_input($_POST['score5gret']);
	
	$err = '';
	$quer = '';
	
	if(isset($communication) && !empty($communication)){
		//if great or not
		if(isset($less11) && !empty($less11))
			$quer = $quer . " AND score1 < ".$communication."";
		else if(isset($gret12) && !empty($gret12))
			$quer = $quer . " AND score1 > ".$communication."";
		else
			$quer = $quer . " AND score1 = ".$communication."";
		
	}
	
	if(isset($knowledge) && !empty($knowledge)){
		//if great or not
		if(isset($less21) && !empty($less21))
			$quer = $quer . " AND score2 < ".$knowledge."";
		else if(isset($gret22) && !empty($gret22))
			$quer = $quer . " AND score2 > ".$knowledge."";
		else
			$quer = $quer . "AND score2 = ".$knowledge."";
	}
		
	if(isset($skills) && !empty($skills)){
		//if great or not
		if(isset($less31) && !empty($less31))
			$quer = $quer . " AND score3 < ".$skills."";
		else if(isset($gret32) && !empty($gret32))
			$quer = $quer . " AND score3 > ".$skills."";
		else
			$quer = $quer . " AND score3 = ".$skills."";
	}
		
	
	if(isset($personality) && !empty($personality)){
		//if great or not
		if(isset($less41) && !empty($less41))
			$quer = $quer . " AND score4 < ".$personality."";
		else if(isset($gret42) && !empty($gret42))
			$quer = $quer . " AND score4 > ".$personality."";
		else
			$quer = $quer . " AND score4 = ".$personality."";
	}
		
	
	if(isset($confidence) && !empty($confidence)){
		//if great or not
		if(isset($less51) && !empty($less51))
			$quer = $quer . " AND score5 < ".$confidence."";
		else if(isset($gret52) && !empty($gret52))
			$quer = $quer . " AND score5 > ".$confidence."";
		else
			$quer = $quer . " AND score5 = ".$confidence."";
	}
	
	if(isset($status) && !empty($status))
		$quer = $quer . " AND status = '".$status."'";
	
	$query_one = "SELECT * FROM applicants WHERE id IS NOT NULL ".$quer." ";
	
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo " ".$rowwed['job_title'] ." [ ". $roww['company_name'] ." ]"?> </title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >

 
    <!-- <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet"> -->
    
    
    <!-- Datatables -->
	<link href="datatable/custom.min.css" rel="stylesheet">
    <link href="datatable/bootstrap.min.css" rel="stylesheet">
    <link href="datatable/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="datatable/responsive.bootstrap.min.css" rel="stylesheet">

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header" >
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Company Profile</a></li>
				<li><a href="post_job.php">Add Job Profiles</a></li>
				<li><a href="manage-jobs.php" id="current">Manage Job Profiles</a></li>
				<li><a href="email.php">Email</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/mac_4-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-sun-o"> </i><?php echo " ".$rowwed['job_title'] ." [ ". $roww['company_name'] ." ]"?> </h2>
		</div>
	</div>
</div>



<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">
		<div align="center"><h2>Filter Users</h2></div>
		<hr>
	<!--create form-->
	<form autocomplete="off" method="post">
	
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="communication">Communication</label>
			<select class="form-control" id="communication" name="communication">
				<option value="">Select a Score</option>
				<option value="1" <?php echo ($communication == '1')?"selected":"" ?>>1</option>
				<option value="2" <?php echo ($communication == '2')?"selected":"" ?>>2</option>
				<option value="3" <?php echo ($communication == '3')?"selected":"" ?>>3</option>
				<option value="4" <?php echo ($communication == '4')?"selected":"" ?>>4</option>
				<option value="5" <?php echo ($communication == '5')?"selected":"" ?>>5</option>
				<option value="6" <?php echo ($communication == '6')?"selected":"" ?>>6</option>
				<option value="7" <?php echo ($communication == '7')?"selected":"" ?>>7</option>
				<option value="8" <?php echo ($communication == '8')?"selected":"" ?>>8</option>
				<option value="9" <?php echo ($communication == '9')?"selected":"" ?>>9</option>
				<option value="10" <?php echo ($communication == '10')?"selected":"" ?>>10</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="knowledge">Knowledge</label>
			<select class="form-control" id="knowledge" name="knowledge">
				<option value="">Select a Score</option>
				<option value="1" <?php echo ($knowledge == '1')?"selected":"" ?>>1</option>
				<option value="2" <?php echo ($knowledge == '2')?"selected":"" ?>>2</option>
				<option value="3" <?php echo ($knowledge == '3')?"selected":"" ?>>3</option>
				<option value="4" <?php echo ($knowledge == '4')?"selected":"" ?>>4</option>
				<option value="5" <?php echo ($knowledge == '5')?"selected":"" ?>>5</option>
				<option value="6" <?php echo ($knowledge == '6')?"selected":"" ?>>6</option>
				<option value="7" <?php echo ($knowledge == '7')?"selected":"" ?>>7</option>
				<option value="8" <?php echo ($knowledge == '8')?"selected":"" ?>>8</option>
				<option value="9" <?php echo ($knowledge == '9')?"selected":"" ?>>9</option>
				<option value="10"<?php echo ($knowledge == '10')?"selected":"" ?>>10</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="skills">Skills</label>
			<select class="form-control" id="skills" name="skills">
				<option value="">Select a Score</option>
				<option value="1" <?php echo ($skills == '1')?"selected":"" ?>>1</option>
				<option value="2" <?php echo ($skills == '2')?"selected":"" ?>>2</option>
				<option value="3" <?php echo ($skills == '3')?"selected":"" ?>>3</option>
				<option value="4" <?php echo ($skills == '4')?"selected":"" ?>>4</option>
				<option value="5" <?php echo ($skills == '5')?"selected":"" ?>>5</option>
				<option value="6" <?php echo ($skills == '6')?"selected":"" ?>>6</option>
				<option value="7" <?php echo ($skills == '7')?"selected":"" ?>>7</option>
				<option value="8" <?php echo ($skills == '8')?"selected":"" ?>>8</option>
				<option value="9" <?php echo ($skills == '9')?"selected":"" ?>>9</option>
				<option value="10" <?php echo ($skills == '10')?"selected":"" ?>>10</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="personality">personality</label>
			<select class="form-control" id="personality" name="personality">
				<option value="">Select a Score</option>
				<option value="1" <?php echo ($personality == '1')?"selected":"" ?>>1</option>
				<option value="2" <?php echo ($personality == '2')?"selected":"" ?>>2</option>
				<option value="3" <?php echo ($personality == '3')?"selected":"" ?>>3</option>
				<option value="4" <?php echo ($personality == '4')?"selected":"" ?>>4</option>
				<option value="5" <?php echo ($personality == '5')?"selected":"" ?>>5</option>
				<option value="6" <?php echo ($personality == '6')?"selected":"" ?>>6</option>
				<option value="7" <?php echo ($personality == '7')?"selected":"" ?>>7</option>
				<option value="8" <?php echo ($personality == '8')?"selected":"" ?>>8</option>
				<option value="9" <?php echo ($personality == '9')?"selected":"" ?>>9</option>
				<option value="10"<?php echo ($personality == '10')?"selected":"" ?>>10</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="confidence">Confidence</label>
			<select class="form-control" id="confidence" name="confidence">
				<option value="">Select a Score</option>
				<option value="1" <?php echo ($confidence == '1')?"selected":"" ?>>1</option>
				<option value="2" <?php echo ($confidence == '2')?"selected":"" ?>>2</option>
				<option value="3" <?php echo ($confidence == '3')?"selected":"" ?>>3</option>
				<option value="4" <?php echo ($confidence == '4')?"selected":"" ?>>4</option>
				<option value="5" <?php echo ($confidence == '5')?"selected":"" ?>>5</option>
				<option value="6" <?php echo ($confidence == '6')?"selected":"" ?>>6</option>
				<option value="7" <?php echo ($confidence == '7')?"selected":"" ?>>7</option>
				<option value="8" <?php echo ($confidence == '8')?"selected":"" ?>>8</option>
				<option value="9" <?php echo ($confidence == '9')?"selected":"" ?>>9</option>
				<option value="10" <?php echo ($confidence == '10')?"selected":"" ?>>10</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<label for="status">Status</label>
			<select class="form-control" name="status" id="status">
				<option value="">Select a Score</option>
				<option value="Pending" <?php echo ($status == 'Pending')?"selected":"" ?>>Pending</option>
				<option value="Select" <?php echo ($status == 'Select')?"selected":"" ?>>Select</option>
				<option value="Reject" <?php echo ($status == 'Reject')?"selected":"" ?>>Reject</option>
			</select>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox" <?php echo ($less11 == 'score11')?"checked":"" ?> name="score1less" value="score11"> Less Than
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($gret12 == 'score12')?"checked":"" ?> name="score1gret" value="score12"> Greater Than
			  </label>
			</div>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($less21 == 'score21')?"checked":"" ?> name="score2less" value="score21"> Less Than
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($gret22 == 'score22')?"checked":"" ?> name="score2gret" value="score22"> Greater Than
			  </label>
			</div>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($less31 == 'score31')?"checked":"" ?> name="score3less" value="score31"> Less Than
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox" <?php echo ($gret32== 'score32')?"checked":"" ?> name="score3gret" value="score32"> Greater Than
			  </label>
			</div>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($less41 == 'score41')?"checked":"" ?> name="score4less" value="score41">Less Than
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($gret42 == 'score42')?"checked":"" ?> name="score4gret" value="score42"> Greater Than
			  </label>
			</div>
		</div>
		
		<div class="col-md-2 col-sm-12 col-xs-12 form-group">
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($less51 == 'score51')?"checked":"" ?> name="score5less" value="score51"> Less Than
			  </label>
			</div>
			<div class="form-check form-check-inline">
			  <label class="form-check-label" style="font-weight: 200;font-size: 15px">
				<input class="form-check-input" type="checkbox"  <?php echo ($gret52 == 'score52')?"checked":"" ?> name="score5gret" value="score52"> Greater Than
			  </label>
			</div>
		</div>
		
		<div class="btn-group">
			<button type="submit" name="filter" class="btn btn-primary">Search</button>
			<button type="submit" name="reset" class="btn btn-success">Reset</button>
		</div>
	</form>
	<hr>
	<div class="clearfix margin-bottom-45"></div>
		<p class="margin-bottom-25">Job data are shown below.</p>

		<table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" width="100%" cellspacing="0" >
        	<thead>
            	<tr>
                	<th>#</th>
                    <th>Name </th>
                    <th>E-mail</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    <th>State</th>
                    <th>City</th>
                    <th>Status</th>
                    <th>Account Link</th>   
                    <th>Score 1</th>
                    <th>Score 2</th>  
                    <th>Score 3</th>
                    <th>Score 4</th> 
                    <th>Score 5</th>
                    <th>Remarks</th>     
                </tr>
            </thead>

			<?php 
			
				$str = $db->prepare($query_one);
				$str->execute();
				$ress = $str->get_result();
				while($rimm = $ress->fetch_assoc())
				{
					$count++;
					$tag = 'grey';
					if($rimm['status'] == 'Select')
						$tag = 'Green';
					else if($rimm['status'] == 'Reject')
						$tag = 'Red';
					
					echo '
						<tr>
							<td>'.$rimm['id'].'</td>
							<td><a target="_blank" href="view_profile.php?id='.$rimm['username'].'" >'.$rimm['full_name'].'</a></td>
							<td>'.$rimm['email'].'</td>
							<td>'.$rimm['phone'].'</td>
							<td>'.$rimm['gender'].'</td>
							<td>'.$rimm['state'].'</td>
							<td>'.$rimm['city'].'</td>
							<td><span style="color: '.$tag.'">'.$rimm['status'].'<span></td>
							<td>http://careerstairs.in/profile.php?id='.$rimm['username'].'</td>
							<td>'.$rimm['score1'].'</td>
							<td>'.$rimm['score2'].'</td>
							<td>'.$rimm['score3'].'</td>
							<td>'.$rimm['score4'].'</td>
							<td>'.$rimm['score5'].'</td>
							<td>'.$rimm['remark'].'</td>
						</tr>
					';
				}
				
				$str->free_result();
	
			?>
				
         </table>		

		
	</div>

</div>

<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<script src="../../scripts/errors/sweetalert2.min.js"></script>
<link rel="stylesheet" href="../../scripts/errors/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="../../scripts/errors/core.js"></script>
   
   
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    

<!-- Datatables -->
    <script src="datatable/jquery.dataTables.min.js"></script>
    <script src="datatable/dataTables.bootstrap.min.js"></script>
    <script src="datatable/dataTables.buttons.min.js"></script>
    <script src="datatable/buttons.bootstrap.min.js"></script>
    <script src="datatable/buttons.flash.min.js"></script>
    <script src="datatable/buttons.html5.min.js"></script>
    <script src="datatable/buttons.print.min.js"></script>
    <script src="datatable/dataTables.keyTable.min.js"></script>
    <script src="datatable/dataTables.responsive.min.js"></script>
    <script src="datatable/responsive.bootstrap.js"></script>
    <script src="datatable/datatables.scroller.min.js"></script>
    <script src="datatable/jszip.min.js"></script>
    <script src="datatable/pdfmake.min.js"></script>
    <script src="datatable/vfs_fonts.js"></script>
<!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
			  retrieve: true,
    		paging: true,
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();
		
        TableManageButtons.init();
      });
    </script>


</body>

</html>