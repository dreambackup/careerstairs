<?php
session_start();
//Include database configuration file
include('../../db/config.php');

error_reporting(0);

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
}
else{
	header('Location: ../../login.php');
}


// code to check phone duplicasy
if(isset($_POST["phone"]) && !empty($_POST["phone"])){
   
	$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
	$stm->bind_param("s", $_POST["phone"]);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>