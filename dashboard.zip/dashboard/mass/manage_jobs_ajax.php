<?php
	session_start();
	//Include database configuration file
	include('../../db/config.php');

	error_reporting(0);

	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	}
	else{
		header('Location: ../../login.php');
	}

	

//search user
if(isset($_POST["job_id"]) && !empty($_POST["job_id"]) && isset($_POST["job_title"]) && !empty($_POST["job_title"]) && isset($_POST["username"]) && !empty($_POST["username"]) && isset($_POST["user"]) && !empty($_POST["user"])){
		
		$job_id = test_input($_POST["job_id"]);
		$job_title = test_input($_POST["job_title"]);
		$mass_username = test_input($_POST['user']);
		$search_user = test_input($_POST['username']);
	
	//does the user and job exixt
	
	$job_count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?");
	$stm->bind_param("sss",$job_id,$job_title,$mass_username);
	$stm->execute();
	$stm->store_result();
	$job_count = $stm->num_rows;
	$stm->free_result();

	//lets check for the expiry and does it active
	if($job_count == 1){
		
		$active_count = 0;
		$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL");
		$stm->bind_param("sss",$job_id,$job_title,$mass_username);
		$stm->execute();
		$stm->store_result();
		$active_count = $stm->num_rows;
		$stm->free_result();
		
		if($active_count == 1){
			//let's check for it's expiry
			$expire_count = 0;
			$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL AND CURRENT_DATE <= happen_date");
			$stm->bind_param("sss",$job_id,$job_title,$mass_username);
			$stm->execute();
			$stm->store_result();
			$expire_count = $stm->num_rows;
			$stm->free_result();
			
			if($expire_count == 1){
				//now does the username exist
				$user_exist = 0;
				$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
				$stm->bind_param("s",$search_user);
				$stm->execute();
				$stm->store_result();
				$user_exist = $stm->num_rows;
				$stm->free_result();
				
				if($user_exist == 1){
					//he should be a jobseeker
					$stm = $db->prepare("SELECT type FROM users_login WHERE oauth_uid = ? ");
					$stm->bind_param("s",$search_user);
					$stm->execute();
					$usertype = $stm->get_result()->fetch_object()->type;
					$stm->free_result();
					
					if($usertype == 'user'){
						//does he apply for it or not
						//get user id
						$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
						$stm->bind_param("s",$search_user);
						$stm->execute();
						$userid = $stm->get_result()->fetch_object()->id;
						$stm->free_result();
						
						//get job_users_array
						$stm = $db->prepare("SELECT users FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? ");
						$stm->bind_param("sss",$job_id,$job_title,$mass_username);
						$stm->execute();
						$usersarray = $stm->get_result()->fetch_object()->users;
						$stm->free_result();
						
						//execute it
						$usersarrays = json_decode($usersarray);
						$usersarray_count = count($usersarrays);
						
						$flag = 0;
						for($i=0;$i<$usersarray_count;$i++){
							if($usersarrays[$i][0] == $userid){
								$flag = 1;
								break;
							}
						}
						
						if($flag == 0){
							//fetch the details
							$stm = $db->prepare("SELECT users_login.name, users_login.email, users_login.phone, users_login.picture, users_login.oauth_provider, users_profile.state, users_profile.city FROM users_login INNER JOIN users_profile ON users_login.oauth_uid = users_profile.username WHERE users_login.oauth_uid = ? ");
							$stm->bind_param("s",$search_user);
							$stm->execute();
							$stm->bind_result($col1,$col2,$col3,$col4,$col5,$col6,$col7);

							while ($stm->fetch()) {
								$full_name = $col1;
								$email = $col2;
								$phone = $col3;
								$picture = $col4;
								$provider = $col5;
								$city = $col6;
								$state = $col7;
							}
							$err = '';
							
							$data = array(
								'status' =>'No',
								'jobseekerid' => $search_user,
								'name' => $full_name,
								'email' => $email,
								'phone' => $phone,
								'picture' => $picture,
								'provider' => $provider,
								'city' => $city,
								'state' => $state,
								'err' => $err,
							);
							echo json_encode($data);

							$stm->free_result();
							
						}
						else{
							$data = array(
								'err' => 'The Username has already registered for this Job Profile !',
							);
							echo json_encode($data);
						}
						
					}
					else{
						$data = array(
							'err' => 'The Username is Not a Jobseeker !',
						);
						echo json_encode($data);
					}
					
				}
				else{
					$data = array(
						'err' => 'The Username is Invalid !',
					);
					echo json_encode($data);
				}
				
			}
			else{
				$data = array(
					'err' => 'The Job Profile has been Expired !',
				);
				echo json_encode($data);
			}
		}
		else{
			$data = array(
				'err' => 'The Job Has not been Active , The location and Date are not Fixed Yet !',
			);
			echo json_encode($data);
		}
		
	}
	else{
		$data = array(
			'err' => 'Invalid Job ID or Username',
		);
		echo json_encode($data);
	}
	
}

//add user
if(isset($_POST["job_ids"]) && !empty($_POST["job_ids"]) && isset($_POST["job_titles"]) && !empty($_POST["job_titles"]) && isset($_POST["usernames"]) && !empty($_POST["usernames"]) && isset($_POST["users"]) && !empty($_POST["users"])){
		
		$job_id = test_input($_POST["job_ids"]);
		$job_title = test_input($_POST["job_titles"]);
		$mass_username = test_input($_POST['users']);
		$search_user = test_input($_POST['usernames']);
	
	//does the user and job exixt
	
	$job_count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?");
	$stm->bind_param("sss",$job_id,$job_title,$mass_username);
	$stm->execute();
	$stm->store_result();
	$job_count = $stm->num_rows;
	$stm->free_result();

	//lets check for the expiry and does it active
	if($job_count == 1){
		
		$active_count = 0;
		$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL");
		$stm->bind_param("sss",$job_id,$job_title,$mass_username);
		$stm->execute();
		$stm->store_result();
		$active_count = $stm->num_rows;
		$stm->free_result();
		
		if($active_count == 1){
			//let's check for it's expiry
			$expire_count = 0;
			$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL AND CURRENT_DATE <= happen_date");
			$stm->bind_param("sss",$job_id,$job_title,$mass_username);
			$stm->execute();
			$stm->store_result();
			$expire_count = $stm->num_rows;
			$stm->free_result();
			
			if($expire_count == 1){
				//now does the username exist
				$user_exist = 0;
				$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
				$stm->bind_param("s",$search_user);
				$stm->execute();
				$stm->store_result();
				$user_exist = $stm->num_rows;
				$stm->free_result();
				
				if($user_exist == 1){
					//he should be a jobseeker
					$stm = $db->prepare("SELECT type FROM users_login WHERE oauth_uid = ? ");
					$stm->bind_param("s",$search_user);
					$stm->execute();
					$usertype = $stm->get_result()->fetch_object()->type;
					$stm->free_result();
					
					if($usertype == 'user'){
						//does he apply for it or not
						//get user id
						$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
						$stm->bind_param("s",$search_user);
						$stm->execute();
						$userid = $stm->get_result()->fetch_object()->id;
						$stm->free_result();
						
						//get job_users_array
						$stm = $db->prepare("SELECT users FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? ");
						$stm->bind_param("sss",$job_id,$job_title,$mass_username);
						$stm->execute();
						$usersarray = $stm->get_result()->fetch_object()->users;
						$stm->free_result();
						
						//execute it
						$usersarrays = json_decode($usersarray);
						$usersarray_count = count($usersarrays);
						
						$flag = 0;
						for($i=0;$i<$usersarray_count;$i++){
							if($usersarrays[$i][0] == $userid){
								$flag = 1;
								break;
							}
						}
						
						if($flag == 0){
							//insert into user array in job
							if(!empty($usersarrays)){
								$new_element = [$userid,"Pending","","","","","",""];
								array_push($usersarrays,$new_element);
							}
							else{
								$usersarrays[0] = [$userid,"Pending","","","","","",""];
							}
							
							//now update the table
							$err = '';
							$done = 'No';
							
							if(($stmy = $db->prepare("UPDATE mass_jobs SET users = ? WHERE id = ? AND job_title = ? AND mass_username = ?"))){
								if($stmy->bind_param("ssss",json_encode($usersarrays),$job_id,$job_title,$mass_username)){
									if($stmy->execute()){
											$done = 'Yes';
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
							
							if($flag == 1){
								$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
							}
							
							//send data
							$data = array(
								'done' =>$done,
								'err' => $err,
							);
							echo json_encode($data);

							$stm->free_result();
							
						}
						else{
							$data = array(
								'err' => 'The Username has already registered for this Job Profile !',
							);
							echo json_encode($data);
						}
						
					}
					else{
						$data = array(
							'err' => 'The Username is Not a Jobseeker !',
						);
						echo json_encode($data);
					}
					
				}
				else{
					$data = array(
						'err' => 'The Username is Invalid !',
					);
					echo json_encode($data);
				}
				
			}
			else{
				$data = array(
					'err' => 'The Job Profile has been Expired !',
				);
				echo json_encode($data);
			}
		}
		else{
			$data = array(
				'err' => 'The Job Has not been Active , The location and Date are not Fixed Yet !',
			);
			echo json_encode($data);
		}
		
	}
	else{
		$data = array(
			'err' => 'Invalid Job ID or Username',
		);
		echo json_encode($data);
	}
	
}

//email function
if(isset($_POST["job_t"]) && !empty($_POST["job_t"]) && isset($_POST["usern"]) && !empty($_POST["usern"]) && isset($_POST["options"]) && !empty($_POST["options"])){
		
	$job_title = test_input($_POST["job_t"]);
	$mass_username = test_input($_POST['usern']);
	$search_option = test_input($_POST['options']);
	
	//verify job first
	$job_count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE job_title = ? AND mass_username = ?");
	$stm->bind_param("ss",$job_title,$mass_username);
	$stm->execute();
	$stm->store_result();
	$job_count = $stm->num_rows;
	$stm->free_result();

	//lets check for the expiry and does it active
	if($job_count == 1){
		
		//let's get the users array
		//get job_users_array
		$stm = $db->prepare("SELECT users FROM mass_jobs WHERE job_title = ? AND mass_username = ? ");
		$stm->bind_param("ss",$job_title,$mass_username);
		$stm->execute();
		$usersarray = $stm->get_result()->fetch_object()->users;
		$stm->free_result();
						
		//execute it
		$usersarrays = json_decode($usersarray);
		$usersarray_count = count($usersarrays);
		
		$count = 0;
		
		if($search_option == 'All')
			$count = $usersarray_count;
		else{
			for($i=0;$i<$usersarray_count;$i++){
				if($search_option == $usersarrays[$i][1]){
					$count++;
				}
			}
		}
		
		//send data
		$data = array(
			'count' =>$count,
			'err' => $err,
		);
		echo json_encode($data);

		$stm->free_result();
		
	}
	else{
		$data = array(
			'err' => 'Invalid Job ID or Username',
		);
		echo json_encode($data);
	}
}


//search user data about evaluation
if(isset($_POST["job_idm"]) && !empty($_POST["job_idm"]) && isset($_POST["title"]) && !empty($_POST["title"]) && isset($_POST["user_id"]) && !empty($_POST["user_id"]) && isset($_POST["mass_username"]) && !empty($_POST["mass_username"])){
		
		$job_id = test_input($_POST["job_idm"]);
		$job_title = test_input($_POST["title"]);
		$mass_username = test_input($_POST['mass_username']);
		$search_user = test_input($_POST['user_id']);
	
	//does the user and job exixt
	
	$job_count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?");
	$stm->bind_param("sss",$job_id,$job_title,$mass_username);
	$stm->execute();
	$stm->store_result();
	$job_count = $stm->num_rows;
	$stm->free_result();

	//lets check for the expiry and does it active
	if($job_count == 1){
		
		$active_count = 0;
		$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL");
		$stm->bind_param("sss",$job_id,$job_title,$mass_username);
		$stm->execute();
		$stm->store_result();
		$active_count = $stm->num_rows;
		$stm->free_result();
		
		if($active_count == 1){
			//let's check for it's expiry
			$expire_count = 0;
			$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL AND CURRENT_DATE <= happen_date");
			$stm->bind_param("sss",$job_id,$job_title,$mass_username);
			$stm->execute();
			$stm->store_result();
			$expire_count = $stm->num_rows;
			$stm->free_result();
			
			if($expire_count == 1){
				//now does the username exist
				$user_exist = 0;
				$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
				$stm->bind_param("s",$search_user);
				$stm->execute();
				$stm->store_result();
				$user_exist = $stm->num_rows;
				$stm->free_result();
				
				if($user_exist == 1){
					//he should be a jobseeker
					$stm = $db->prepare("SELECT type FROM users_login WHERE oauth_uid = ? ");
					$stm->bind_param("s",$search_user);
					$stm->execute();
					$usertype = $stm->get_result()->fetch_object()->type;
					$stm->free_result();
					
					if($usertype == 'user'){
						//does he apply for it or not
						//get user id
						$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
						$stm->bind_param("s",$search_user);
						$stm->execute();
						$userid = $stm->get_result()->fetch_object()->id;
						$stm->free_result();
						
						//get job_users_array
						$stm = $db->prepare("SELECT users FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? ");
						$stm->bind_param("sss",$job_id,$job_title,$mass_username);
						$stm->execute();
						$usersarray = $stm->get_result()->fetch_object()->users;
						$stm->free_result();
						
						//execute it
						$usersarrays = json_decode($usersarray);
						$usersarray_count = count($usersarrays);
						
						$flag = 1;
						for($i=0;$i<$usersarray_count;$i++){
							if($usersarrays[$i][0] == $userid){
								$flag = 0;
								break;
							}
						}
						
						if($flag == 0){
							//fetch the details
							//send the options
							for($i=0;$i<$usersarray_count;$i++){
								if($usersarrays[$i][0] == $userid){
									$status = $usersarrays[$i][1];
									$score1 = $usersarrays[$i][2];
									$score2 = $usersarrays[$i][3];
									$score3 = $usersarrays[$i][4];
									$score4 = $usersarrays[$i][5];
									$score5 = $usersarrays[$i][6];
									$remark = $usersarrays[$i][7];
									break;
								}
							}
							
							$data = array(
								'status' => $status,
								'score1' => $score1,
								'score2' => $score2,
								'score3' => $score3,
								'score4' => $score4,
								'score5' => $score5,
								'remark' => $remark,
								'err' => '',
							);
							echo json_encode($data);

							$stm->free_result();
							
						}
						else{
							$data = array(
								'err' => 'The Username has not registered for this Job Profile !',
							);
							echo json_encode($data);
						}
						
					}
					else{
						$data = array(
							'err' => 'The Username is Not a Jobseeker !',
						);
						echo json_encode($data);
					}
					
				}
				else{
					$data = array(
						'err' => 'The Username is Invalid !',
					);
					echo json_encode($data);
				}
				
			}
			else{
				$data = array(
					'err' => 'The Job Profile has been Expired !',
				);
				echo json_encode($data);
			}
		}
		else{
			$data = array(
				'err' => 'The Job Has not been Active , The location and Date are not Fixed Yet !',
			);
			echo json_encode($data);
		}
		
	}
	else{
		$data = array(
			'err' => 'Invalid Job ID or Username',
		);
		echo json_encode($data);
	}
	
}


//search user data about evaluation and update data
if(isset($_POST["job_idm"]) && !empty($_POST["job_idm"]) && isset($_POST["title"]) && !empty($_POST["title"]) && isset($_POST["applicant_id"]) && !empty($_POST["applicant_id"]) && isset($_POST["mass_username"]) && !empty($_POST["mass_username"])){
		
		$job_id = test_input($_POST["job_idm"]);
		$job_title = test_input($_POST["title"]);
		$mass_username = test_input($_POST['mass_username']);
		$search_user = test_input($_POST['applicant_id']);
	$score1 = test_input($_POST['score1']);
	$score2 = test_input($_POST['score2']);
	$score3 = test_input($_POST['score3']);
	$score4 = test_input($_POST['score4']);
	$score5 = test_input($_POST['score5']);
	$status = test_input($_POST['status']);
	$remark = test_input($_POST['remark']);
	
	//lets evaluate
	$err = '';
	
	if(isset($score1) && !empty($score1)){
		if($score1 == '1' || $score1 == '2' || $score1 == '3' || $score1 == '4' || $score1 == '5' || $score1 == '6' || $score1 == '7' || $score1 == '8' || $score1 == '9' || $score1 == '10'){
		}
		else
			$err = $err . 'The Communication Field Option is Invalid ';
	}
	else
		$err = $err . 'The Communication Field is Empty ';
	
	if(isset($score2) && !empty($score2)){
		if($score2 == '1' || $score2 == '2' || $score2 == '3' || $score2 == '4' || $score2 == '5' || $score2 == '6' || $score2 == '7' || $score2 == '8' || $score2 == '9' || $score2 == '10'){
		}
		else
			$err = $err . 'The Knowledge Field Option is Invalid ';
	}
	else
		$err = $err . 'The Knowledge Field is Empty ';
	
	if(isset($score3) && !empty($score3)){
		if($score3 == '1' || $score3 == '2' || $score3 == '3' || $score3 == '4' || $score3 == '5' || $score3 == '6' || $score3 == '7' || $score3 == '8' || $score3 == '9' || $score3 == '10'){
		}
		else
			$err = $err . 'The Skills Field Option is Invalid ';
	}
	else
		$err = $err . 'The Skills Field is Empty ';
	
	if(isset($score4) && !empty($score4)){
		if($score4 == '1' || $score4 == '2' || $score4 == '3' || $score4 == '4' || $score4 == '5' || $score4 == '6' || $score4 == '7' || $score4 == '8' || $score4 == '9' || $score4 == '10'){
		}
		else
			$err = $err . 'The Personality Field Option is Invalid ';
	}
	else
		$err = $err . 'The Personality Field is Empty ';
	
	if(isset($score5) && !empty($score5)){
		if($score5 == '1' || $score5 == '2' || $score5 == '3' || $score5 == '4' || $score5 == '5' || $score5 == '6' || $score5 == '7' || $score5 == '8' || $score5 == '9' || $score5 == '10'){
		}
		else
			$err = $err . 'The Confidence Field Option is Invalid ';
	}
	else
		$err = $err . 'The Confidence Field is Empty ';
	
	if(isset($status) && !empty($status)){
		if($status == 'Pending' || $status == 'Select' || $status == 'Reject'){
		}
		else
			$err = $err . 'The Status Field Option is Invalid ';
	}
	else
		$err = $err . 'The Status Field is Empty ';
	
	
	if($err == '')
	{
		//does the user and job exixt
		$job_count = 0;
		$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?");
		$stm->bind_param("sss",$job_id,$job_title,$mass_username);
		$stm->execute();
		$stm->store_result();
		$job_count = $stm->num_rows;
		$stm->free_result();

		//lets check for the expiry and does it active
		if($job_count == 1){

			$active_count = 0;
			$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL");
			$stm->bind_param("sss",$job_id,$job_title,$mass_username);
			$stm->execute();
			$stm->store_result();
			$active_count = $stm->num_rows;
			$stm->free_result();

			if($active_count == 1){
				//let's check for it's expiry
				$expire_count = 0;
				$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? AND location IS NOT NULL AND happen_date IS NOT NULL AND CURRENT_DATE <= happen_date");
				$stm->bind_param("sss",$job_id,$job_title,$mass_username);
				$stm->execute();
				$stm->store_result();
				$expire_count = $stm->num_rows;
				$stm->free_result();

				if($expire_count == 1){
					//now does the username exist
					$user_exist = 0;
					$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
					$stm->bind_param("s",$search_user);
					$stm->execute();
					$stm->store_result();
					$user_exist = $stm->num_rows;
					$stm->free_result();

					if($user_exist == 1){
						//he should be a jobseeker
						$stm = $db->prepare("SELECT type FROM users_login WHERE oauth_uid = ? ");
						$stm->bind_param("s",$search_user);
						$stm->execute();
						$usertype = $stm->get_result()->fetch_object()->type;
						$stm->free_result();

						if($usertype == 'user'){
							//does he apply for it or not
							//get user id
							$stm = $db->prepare("SELECT id FROM users_login WHERE oauth_uid = ? ");
							$stm->bind_param("s",$search_user);
							$stm->execute();
							$userid = $stm->get_result()->fetch_object()->id;
							$stm->free_result();

							//get job_users_array
							$stm = $db->prepare("SELECT users FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ? ");
							$stm->bind_param("sss",$job_id,$job_title,$mass_username);
							$stm->execute();
							$usersarray = $stm->get_result()->fetch_object()->users;
							$stm->free_result();

							//execute it
							$usersarrays = json_decode($usersarray);
							$usersarray_count = count($usersarrays);

							$flag = 1;
							for($i=0;$i<$usersarray_count;$i++){
								if($usersarrays[$i][0] == $userid){
									$flag = 0;
									break;
								}
							}

							if($flag == 0){
								
								//lets update stuff
								
								for($i=0;$i<$usersarray_count;$i++){
									if($usersarrays[$i][0] == $userid){
										$usersarrays[$i][1] = $status;
										$usersarrays[$i][2] = $score1;
										$usersarrays[$i][3] = $score2;
										$usersarrays[$i][4] = $score3;
										$usersarrays[$i][5] = $score4;
										$usersarrays[$i][6] = $score5;
										$usersarrays[$i][7] = $remark;
										break;
									}
								}
							
								//now update the table
								$err = '';
								$done = 'No';
							
								if(($stmy = $db->prepare("UPDATE mass_jobs SET users = ? WHERE id = ? AND job_title = ? AND mass_username = ?"))){
									if($stmy->bind_param("ssss",json_encode($usersarrays),$job_id,$job_title,$mass_username)){
										if($stmy->execute()){
												$done = 'Yes';
										}
										else
											$flag = 1;
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;

								if($flag == 1){
									$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
								}

								//send data
								$data = array(
									'done' =>$done,
									'err' => $err,
									'status' => $status,
								);
								echo json_encode($data);
								$stm->free_result();

							}
							else{
								$data = array(
									'err' => 'The Username has not registered for this Job Profile !',
								);
								echo json_encode($data);
							}

						}
						else{
							$data = array(
								'err' => 'The Username is Not a Jobseeker !',
							);
							echo json_encode($data);
						}

					}
					else{
						$data = array(
							'err' => 'The Username is Invalid !',
						);
						echo json_encode($data);
					}

				}
				else{
					$data = array(
						'err' => 'The Job Profile has been Expired !',
					);
					echo json_encode($data);
				}
			}
			else{
				$data = array(
					'err' => 'The Job Has not been Active , The location and Date are not Fixed Yet !',
				);
				echo json_encode($data);
			}

		}
		else{
			$data = array(
				'err' => 'Invalid Job ID or Username',
			);
			echo json_encode($data);
		}
	}
	else{
		$data = array(
				'err' => $err,
			);
		echo json_encode($data);
	}
	
}


//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>