<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();

	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
if(isset($_POST['final_form']))
{
	$id = test_input($_POST['final_id']);
	$title = test_input($_POST['final_value']);
	
	$count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?");
	$stm->bind_param("sss",$id,$title,$_SESSION['userData']);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		//now get the count of the application
		$stm = $db->prepare("SELECT users FROM mass_jobs WHERE id = ? AND mass_username = ?");
		$stm->bind_param("ss",$id,$_SESSION['userData']);
		$stm->execute();
		$counts = $stm->get_result()->fetch_object()->applied_id;
		$stm->free_result();
		
		$id_counts = count(json_decode($counts));
		if($id_counts == 0)
		{
			
			//now delete the job row
			if(($stmtt = $db->prepare("DELETE FROM mass_jobs WHERE id = ? AND job_title = ? AND mass_username = ?"))){
				if($stmtt->bind_param("sss",$id,$title,$_SESSION['userData'])){
					if($stmtt->execute()){
						header("Location: manage-jobs.php");	
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry You cannot Delete this job since users have applied for this job !", "error");}, 100);</script>';
	}
	else{
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !", "error");}, 100);</script>';
	}
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!Doctype html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Manage Jobs</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css" >
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<style>
	#add-dialog{background:#fff;padding:30px 40px 35px 40px;text-align:left;max-width:610px;margin:40px auto;position:relative;box-sizing:border-box;}
</style>
</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Company Profile</a></li>
				<li><a href="post_job.php">Add Job Profiles</a></li>
				<li><a href="manage-jobs.php" id="current">Manage Job Profiles</a></li>
				<li><a href="email.php">Email</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-dashboard"></i> Manage Jobs </h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-top-50">Your Job Profile listings are shown in the table below. <strong>Please make sure to get filled the date and location for a job profile !</strong></p>

		<table class="manage-table resumes responsive-table">

			<tr>
				<th><i class="fa fa-file-text"></i>Job Profile</th>
					<th><i class="fa fa-check-square-o"></i>Action_?</th>
					<th><i class="fa fa-calendar"></i>Date</th>
					<th><i class="fa fa-calendar"></i>Location</th>
					<th><i class="fa fa-user"></i>Applications</th>
					<th><i class="fa fa-forumbee "></i> Status</th>
				<th></th>
			</tr>
			<?php  
			$stm = $db->prepare("SELECT * FROM mass_jobs WHERE mass_username = ? ORDER BY created DESC");
			$stm->bind_param("s",$_SESSION['userData']);
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				echo '
				<tr>
					<td class="title"><a href="job-overview.php?id='.$rim['id'].'" target="_blank" id="title'.$rim['id'].'">'.$rim['job_title'].' <span class="pending"></span></a></td>';
					if($rim['location'] == NULL && $rim['happen_date'] == NULL )
						echo '<td><i class="fa fa-close"></i></td>';
					else
						echo '<td><i class="fa fa-check"></i></td>';
				
					if($rim['happen_date'] == NULL)
						echo '<td>-</td>';
					else
						echo '<td>'.dateformat($rim['happen_date']).'</td>';
				
					if($rim['location'] == NULL)
						echo '<td>-</td>';
					else
						echo '<td>'.$rim['location'].'</td>';
					echo '<td><a target="_blank" class="button">'.count(json_decode($rim['users'])).'</a></td>';
					
					if($rim['location'] == NULL && $rim['happen_date'] == NULL)
						echo '<td>Not Visible</td>';
					else if($rim['location'] != NULL && $rim['happen_date'] != NULL && $today <= $rim['happen_date'])
						echo '<td>Visible</td>';
					else if($rim['location'] != NULL && $rim['happen_date'] != NULL && $today > $rim['happen_date'])
						echo '<td>Expired</td>';
					
					echo '<td class="action">
							<a href="#add-dialog" onClick="add('.$rim['id'].')" class="popup-with-zoom-anim"><i class="fa fa-plus-circle"></i> Add Applicant</a>';
							if($rim['location'] == NULL && $rim['happen_date'] == NULL)
								echo '<a href="#small-dialog" onClick="delbox('.$rim['id'].')" class="popup-with-zoom-anim"><i class="fa fa-remove"></i> Delete</a>';
							echo '<a target="_blank" href="data_job.php?id='.$rim['id'].'"><i class="fa fa-print"></i>Query & Data</a>';
							echo '<a target="_blank" href="evaluate_job.php?id='.$rim['id'].'"><i class="fa fa-circle-o-notch fa-spin"></i>Evaluate</a>';
					echo '</tr>';
			}
			
			?>
						
		</table>
		
				<div id="small-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
					<div class="small-dialog-content">
						<!-- doc start -->
						<div id="wrapper">
							<div class="overlay"></div>
							<!-- Sidebar -->
							<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
								<ul class="nav sidebar-nav">
									<div id="threedot">
										<form autocomplete="off" method="post">
											<h3>Are you sure you want to delete </h3>
											<input type="text" id="final_id" name="final_id" style="display: none" >
											<input type="text" id="final_value" name="final_value" readonly >
											<h5>You won't be able to revert this !</h5><br/>
											<button type="submit" name="final_form">Delete it</button>
										</form>
									</div>
								</ul>
							</nav>
							<!-- /#sidebar-wrapper -->
						</div>
						<!-- /#wrapper -->
					</div>
				</div>
				
				<div id="add-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
					<div class="small-dialog-headline">
						<h2>Add New Applicant</h2>
					</div>

					<div class="small-dialog-content">
						<form action="#" autocomplete="off" >
							<input type="text" id="addbox_title" maxlength="100" style="display: none">
							<input type="text" id="addbox_id" max="10" style="display: none">
							<strong>Enter Applicant Username: </strong>
							<input type="text" placeholder="User Name of Applicant" required id="username" maxlength="255" />
							
							<div class="clearfix"></div>
							
							<ul class="job-list" id="fetched" style="display: none">
								<li class="highlighted"><a target="_blank" id="userlink">
									<img src="" alt="" id="user_image">
									<div class="job-list-content">
										<h4 id="user_fullname"></h4>
										<div class="job-icons">
											<span id="user_email"><i class="fa fa-envelope-square"></i> </span>
											<span id="user_phone"><i class="fa fa-phone-square"></i> </span>
											<span id="user_city"><i class="fa fa-map-marker"></i> </span>
										</div>
									</div>
									</a>
									<div class="clearfix"></div>
								</li>
								<button type="button" id="status"></button>
							</ul>
							
							<div id="usernames-loading" style="display:none" align="center">
								<i id="usernames-i"></i>
							</div>
							
							<div class="divider"></div>
							
							<button id="final" type="button" name="active" class="send" onClick="search()">Search</button>
						</form>
					</div>
					
				</div>
			
		<br>
		<a href="post_job.php" class="button">Add New Job Profile</a>

	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<script>
	function delbox(id)
	{
		var title = $('#title'+id).text();
		$('#final_value').val(title);
		$('#final_id').val(id);
	}
	function add(idm){
		$('#username').val('');
		$('#final').text('Search');
		$('#final').removeAttr('style');
		$('#fetched').hide();
		$("#userlink").attr("href", "view_profile.php");
		$('#user_fullname').text('');
		$('#user_email').html('');
		$('#user_phone').html('');
		$('#user_city').html('');
		$("#user_image").attr("src",'');
		$('#status').text('');
		$("#status").css("float", "right");
		$('#status').attr("onclick","");
		
		var title = $('#title'+idm).text();
		$('#addbox_title').val(title);
		$('#addbox_id').val(idm);
	}
	function search()
	{
		//clear last inputs
		$('#final').text('Search');
		$('#final').removeAttr('style');
		$('#fetched').hide();
		$("#userlink").attr("href", "view_profile.php");
		$('#user_fullname').text('');
		$('#user_email').html('');
		$('#user_phone').html('');
		$('#user_city').html('');
		$("#user_image").attr("src",'');
		$('#status').text('');
		$("#status").css("float", "right");
		$('#status').attr("onclick","");
		
		
		//new values
		var username = $('#username').val();
		var job_id = $('#addbox_id').val();
		var job_title = $('#addbox_title').val();
		var user = '<?php echo $_SESSION['userData'] ?>';
		
		if( username == '' || job_id == '' || job_title == ''){
			swal(
			  'There seems to have a problem with the inputs provided !',
			  'Invalid Inputs !',
			  'error'
			)
		}
		else {
				$('#usernames-loading').show();
				$("#usernames-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
				//chnage button value
				$('#final').text('Searching');
				
				//start ajax
			$.ajax({
			type:'POST',
			url:'manage_jobs_ajax.php',
			data:{job_id: job_id, job_title: job_title, username: username, user: user },
				 success: function(data){
				 	//console.log(data);
					var result = $.parseJSON(data);
					 //stopt the rotaion
					 var error = result.err;
					 if(error){
						 $("#usernames-i").removeClass();
						 $('#usernames-loading').hide();
						 $('#final').text('Search');
						 $('#final').css({ "background-color": 'grey'});
						 swal(
							   error,
							  'Invalid Inputs !',
							  'error'
							)
					 }
					 else{
						 $("#usernames-i").removeClass();
						 $('#usernames-loading').hide();
						 $('#final').text('Search');
						 $('#fetched').show();
						 
						 $("#userlink").attr("href", "view_profile.php?id="+result.jobseekerid);
						 $('#user_fullname').text(result.name);
						 $('#user_email').html('<i class="fa fa-envelope-square"></i> '+result.email);
						 $('#user_phone').html('<i class="fa fa-phone-square"></i> '+result.phone);
						 $('#user_city').html('<i class="fa fa-map-marker"></i> '+result.city+','+result.state);
						 //get image
						 var picture = result.picture;
						 var provider = result.provider;
						 if(provider != 'normal')
							 $("#user_image").attr("src",picture);
						 else
							 $("#user_image").attr("src",'../user_pictures/'+picture);
						 var status = result.status;
						 
						 if(status == 'No'){
							 $('#status').attr("onclick", "adduser('"+result.jobseekerid+"')");
							 $('#status').text('Add this User');
						 }
					 }
				 }
			});
		}
	}
	function adduser(userm){
	
		$('#usernames-loading').show();
		$("#usernames-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
		//chnage button value
		$('#status').text('Adding');
		
		//get values
		var job_ids = $('#addbox_id').val();
		var job_titles = $('#addbox_title').val();
		var users = '<?php echo $_SESSION['userData'] ?>';
		
		if( userm == '' || job_ids == '' || job_titles == ''){
			swal(
			  'There seems to have a problem with the inputs provided !',
			  'Invalid Inputs !',
			  'error'
			)
		}
		else {
			$.ajax({
			type:'POST',
			url:'manage_jobs_ajax.php',
			data:{job_ids: job_ids, job_titles: job_titles, usernames: userm, users: users },
				 success: function(data){
				 	//console.log(data);
					$("#usernames-i").removeClass();
					$('#usernames-loading').hide();
					 var result = $.parseJSON(data);
					 //stopt the rotaion
					 var error = result.err;
					 if(error){
						 $("#usernames-i").removeClass();
						 $('#usernames-loading').hide();
						 swal(
							   error,
							  'Invalid Inputs !',
							  'error'
							)
					 }
					 else{
						 var done = result.done;
						 
						 if(done == 'Yes'){
							 $('#status').text('Added');
							 $('#status').css({"pointer-events": 'none'});
							 $('#status').attr("onclick","");
						 }
						 else{
							 $('#status').text('Error');
							 $('#status').css({ "background-color": 'grey', "pointer-events": 'none'});
							 $('#status').attr("onclick","");
						 }
					 }
				 }
			});
			
		}
	}
</script>
</body>

</html>