<?php
include('../../db/config.php');
session_start();
$appid = test_input($_GET['id']);
//error_reporting(0);

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$stmt = $db->prepare("SELECT * FROM mass_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	//now fetch the job details
	$count = 0;
	$stm = $db->prepare("SELECT id FROM mass_jobs WHERE id = ? AND mass_username = ?");
	$stm->bind_param("ss",$appid,$_SESSION['userData']);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1)
	{
		$stm = $db->prepare("SELECT * FROM mass_jobs WHERE id = ? AND mass_username = ?");
		$stm->bind_param("ss",$appid,$_SESSION['userData']);
		$stm->execute();
		$ress = $stm->get_result();
		$rowwed = $ress->fetch_assoc();
		$stm->free_result();
	}
	else{
		header("Location: index.php");
	}
	
}
else{
	header('Location: ../../login.php');
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $rowwed['job_title'] ?> | Applications</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css">

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Company Profile</a></li>
				<li><a href="post_job.php">Add Job Profiles</a></li>
				<li><a href="manage-jobs.php" id="current">Manage Job Profiles</a></li>
				<li><a href="email.php">Email</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-retweet"></i> <?php echo $rowwed['job_title'] ?> Applications </h2>
		</div>
	</div>
</div>

<!-- Content
================================================== -->
<div class="container">

<!-- Table -->
	<div class="sixteen columns">

		<p class="margin-bottom-25" style="float: left;">The job applications for <strong><a <?php echo 'href="job-overview.php?id='.$appid.'"';?> target="_blank" > <?php echo $rowwed['job_title'] ?></a></strong> are listed below.</p>
		
		<div class="skills" style="float: right">
				<p>Selected<span id="selected" style="background-color: lightseagreen">0</span></p>
				<p>Rejected<span id="rejected" style="background-color: crimson">0</span></p>
				<p>Pending <span id="pending" >0</span></p>
		</div>
		
		<div id="small-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
			<div class="small-dialog-headline">
				<h2 id="applicant_name"></h2>
			</div>

			<div class="small-dialog-content">
				<form autocomplete="off" id="finalform" >
				<input id="username_applicant" style="display: none" maxlength="255" required>
					<label>Enter Score for  Communication: </label>
					<select style="padding: 13px" id="communication" name="communication" required>
						<option value="">Select a Score</option>
						<option value="1" >1</option>
						<option value="2" >2</option>
						<option value="3" >3</option>
						<option value="4" >4</option>
						<option value="5" >5</option>
						<option value="6" >6</option>
						<option value="7" >7</option>
						<option value="8" >8</option>
						<option value="9" >9</option>
						<option value="10" >10</option>
					</select>
							
					<label>Enter Score for  Knowledge: </label>
					<select style="padding: 13px" id="knowledge" name="knowledge" required>
						<option value="">Select a Score</option>
						<option value="1" >1</option>
						<option value="2" >2</option>
						<option value="3" >3</option>
						<option value="4" >4</option>
						<option value="5" >5</option>
						<option value="6" >6</option>
						<option value="7" >7</option>
						<option value="8" >8</option>
						<option value="9" >9</option>
						<option value="10" >10</option>
					</select>
							
					<label>Enter Score for  Skills: </label>
					<select style="padding: 13px" id="skills" name="skills" required>
						<option value="">Select a Score</option>
						<option value="1" >1</option>
						<option value="2" >2</option>
						<option value="3" >3</option>
						<option value="4" >4</option>
						<option value="5" >5</option>
						<option value="6" >6</option>
						<option value="7" >7</option>
						<option value="8" >8</option>
						<option value="9" >9</option>
						<option value="10" >10</option>
					</select>

					<label>Enter Score for  Personality: </label>
					<select style="padding: 13px" id="personality" name="personality" required>
						<option value="">Select a Score</option>
						<option value="1" >1</option>
						<option value="2" >2</option>
						<option value="3" >3</option>
						<option value="4" >4</option>
						<option value="5" >5</option>
						<option value="6" >6</option>
						<option value="7" >7</option>
						<option value="8" >8</option>
						<option value="9" >9</option>
						<option value="10" >10</option>
					</select>
					
					<label>Enter Score for  Confidence: </label>
					<select style="padding: 13px" id="confidence" name="confidence" required>
						<option value="">Select a Score</option>
						<option value="1" >1</option>
						<option value="2" >2</option>
						<option value="3" >3</option>
						<option value="4" >4</option>
						<option value="5" >5</option>
						<option value="6" >6</option>
						<option value="7" >7</option>
						<option value="8" >8</option>
						<option value="9" >9</option>
						<option value="10" >10</option>
					</select>		
					
					<label for="status">Status</label>
					<select style="padding: 13px" name="status" id="status" required>
						<option value="">Select a Score</option>
						<option value="Pending" >Pending</option>
						<option value="Select" >Select</option>
						<option value="Reject" >Reject</option>
					</select>

					<label>Any Remark ?</label>
					<textarea placeholder="Enter any remark/note about this candidate" maxlength="255" id="remark" style="resize: none" rows="4"></textarea>
					
					<div class="clearfix"></div>
								
					<button id="final" type="button" name="active" class="send" onClick="strauss()">Evaluate</button>
				</form>
				
				<div id="usernames-loading" style="display:none" align="center">
					<i id="usernames-i"></i>
				</div>
				
			</div>
					
		</div>
		
	</div>

	
	<form action="#" class="list-search">
		<button><i class="fa fa-search"></i></button>
		<input type="text" placeholder="Search by Name" id="search" value=""/>
		<div class="clearfix"></div>
	</form>

	<!--start query -->
	<?php 
		$user = json_decode($rowwed['users']);
		$user_count = count($user);
		for($i=0;$i<$user_count;$i++)
			$users[$i] = $user[$i][0];
			
			$pending = 0;
			$selected = 0;
			$rejected = 0;
			
			
		if(!empty($user))
		{
			
			$stm = $db->prepare("SELECT id,oauth_provider,oauth_uid,name,email,phone,picture FROM users_login WHERE id IN (".implode(",", $users).") ");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				
				
				if($rim['oauth_provider'] != 'normal')
					$picture = $rim['picture'];
				else
					$picture = "../user_pictures/".$rim['picture'];
				//will use counter to show details
				
				//get status
				
				for($i=0;$i<$user_count;$i++)
				{
					if($user[$i][0] == $rim['id'])
					{
						$status = $user[$i][1];
						
						if($status == 'Pending')
						{
							$flag = 'Pending';
							$color = 'gray';
							$pending++;
						}
						else if($status == 'Select')
						{
							$flag = 'Selected';
							$color = 'green';
							$selected++;
						}
						else if($status == 'Reject')
						{
							$flag = 'Rejected';
							$color = 'red';
							$rejected++;
							
						}
					}
				}
				
				echo '
				<div class="application">
					<div class="app-content">
						<!-- Name / Avatar -->
						<div class="info">
							<img src="'.$picture.'" alt="'.$rim['name'].'">
							<span class="app" id="name'.$rim['oauth_uid'].'">'.$rim['name'].'</span><span id="span'.$rim['oauth_uid'].'" style="font-size: 15px;color: '.$color.';padding-left: 10px">('.$flag.')</span>
							<ul>
								<li><a href="just_print.php?userid='.$rim['oauth_uid'].'" target="_blank"><i class="fa fa-file-text"></i> Download CV</a></li>
								<li><a href="mailto:'.$rim['email'].'"><i class="fa fa-envelope"></i> Mail</a></li>
								<li><a href="tel:'.$rim['phone'].'"><i class="fa fa-phone"></i>'.$rim['phone'].'</a></li>
							</ul>
						</div>

						<!-- Buttons -->
						<div class="buttons">
							<a href="view_profile.php?id='.$rim['oauth_uid'].'" class="button " target="_blank"><i class="fa fa-yelp" aria-hidden="true"></i> View Profile</a>
							<a href="#small-dialog" onClick="eva(\''.$rim['oauth_uid'].'\')" class="button gray popup-with-zoom-anim"><i class="fa fa-plus-circle"></i> Evaluate</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				';
			}
		}
		else
			echo '<h3>No one has applied for this job yet !</h3>';
			
	?>
		<!-- Application -->
		
		
</div>
			

<!-- Footer
================================================== -->
<div class="margin-top-25"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>


<script>
	var pending = '<?php echo $pending ?>';
	var selected = '<?php echo $selected ?>';
	var rejected = '<?php echo $rejected ?>';
	
	$(document).ready(function(){
	   $('#selected').text(selected);
	   $('#rejected').text(rejected);
	   $('#pending').text(pending);
	});
</script>
<script>
	
	var job_id = '<?php echo $appid ?>';
	var job_title = '<?php echo $rowwed['job_title'] ?>';
	var user = '<?php echo $_SESSION['userData'] ?>';
		
	
	function eva(username){
		var name = $('#name'+username).text();
		$('#applicant_name').text('Evaluate '+name);
		$('#username_applicant').val(username);
		$('#final').text('Evaluate');
		
		//lets fill these again
		$('#finalform').hide();
		$('#usernames-loading').show();
		$("#usernames-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
		
		$.ajax({
			type:'POST',
			url:'manage_jobs_ajax.php',
			data:{job_idm: job_id, title: job_title, mass_username: user, user_id: username},
				 success: function(data){
					 $("#usernames-i").removeClass();
					 $('#usernames-loading').hide();
					 $('#finalform').show();
				 	//console.log(data);
					var result = $.parseJSON(data);
					 
					var error = result.err;
					 if(error){
						 $("#usernames-i").removeClass();
						 $('#usernames-loading').hide();
						 $('#finalform').hide();
						 swal(
							   error,
							  'Invalid Inputs !',
							  'error'
							)
					 }
					 else{
						 //place data
						 $('#remark').val(result.remark);
						 $("#communication").val(result.score1);
						 $("#knowledge").val(result.score2);
						 $("#skills").val(result.score3);
						 $("#personality").val(result.score4);
						 $("#confidence").val(result.score5);
						 $("#status").val(result.status);
					 }
				 }
		});
	}
	
	function strauss(){
		//get data
		var score1 = $('#communication').val();
		var score2 = $('#knowledge').val();
		var score3 = $('#skills').val();
		var score4 = $('#personality').val();
		var score5 = $('#confidence').val();
		var remark = $('#remark').val();
		var status = $('#status').val();
		var applicant = $('#username_applicant').val();
		
		var nine = $('#span'+applicant).text();
		
		console.log(nine);
		
		//let's validate all these
		if(score1 == '' && score2 == '' && score3 == '' && score4 == '' && score5 == '' && status == '')
		{
			swal(
			  'Please Fill the form before Submit !',
			  'Empty Inputs !',
			  'error'
			)	
		}
		else{
			$('#final').text('Saving');
			//lets call ajax
			$.ajax({
			type:'POST',
			url:'manage_jobs_ajax.php',
			data:{job_idm: job_id, title: job_title, mass_username: user, applicant_id: applicant, score1: score1, score2: score2, score3: score3 ,score4: score4, score5: score5, status: status, remark: remark},
				 success: function(data){
					 //console.log(data);
					 $("#usernames-i").removeClass();
					 $('#usernames-loading').hide();
				 	 
					 var result = $.parseJSON(data);
					 
					 var error = result.err;
					 if(error){
						 $("#usernames-i").removeClass();
						 $('#usernames-loading').hide();
						 $('#finalform').hide();
						 swal(
							   error,
							  'There is some error !',
							  'error'
							)
					 }
					 else{
						 
						 //update the text
						 $('#span'+applicant).text('');
						 $('#span'+applicant).removeAttr('style');
						 $('#final').text('Saved');
						 
						 if(result.status == 'Pending'){
						 	$('#span'+applicant).text('('+result.status +')');
							$('#span'+applicant).attr('style','color: gray;font-size:15px;padding-left:10px');
							
							if(nine == '(Select)')
								selected--;
							else if(nine == '(Reject)')
								rejected--;
							pending++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
							
					 	 }
						 else if(result.status == 'Select'){
						 	$('#span'+applicant).text('('+result.status +')');
							$('#span'+applicant).attr('style','color: green;font-size:15px;padding-left:10px');
							 
							if(nine == '(Pending)')
								pending--;
							else if(nine == '(Reject)')
								rejected--;
							selected++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
					 	 }
						 else if(result.status == 'Reject'){
						 	$('#span'+applicant).text('('+result.status +')');
							$('#span'+applicant).attr('style','color: red;font-size:15px;padding-left:10px');
							 
							if(nine == '(Pending)')
								pending--;
							else if(nine == '(Select)')
								selected--;
							rejected++;
							$('#pending').text(pending);
							$('#selected').text(selected);
							$('#rejected').text(rejected);
					 	 }
						 
					 }
					 
				 }
			});
		}
	}
	
	 $("#search").keyup(function(){
        var searchText = $(this).val().toLowerCase();
        // Show only matching TR, hide rest of them
        $.each($(".app"), function() {
            if($(this).text().toLowerCase().indexOf(searchText) === -1)
               $(this).parents().eq(2).hide();
            else
               $(this).parents().eq(2).show();                
        });
    }); 

</script>
</body>

</html>