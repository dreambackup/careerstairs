<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	$stmt = $db->prepare("SELECT * FROM mass_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();

	$today = date("Y-m-d");
}
else{
	header('Location: ../../login.php');
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Home</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css" >

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>
		
		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php" id="current">Home</a></li>
				<li><a href="profile.php" >Company Profile</a></li>
				<li><a href="post_job.php">Add Job Profiles</a></li>
				<li><a href="manage-jobs.php">Manage Job Profiles</a></li>
				<li><a href="email.php">Email</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/1920-720-876.jpg)">
	<div class="container">
		<div class="twelve columns">
			<div class="resume-titlebar">
				<?php 
				if($row['oauth_provider'] != 'normal'){
					echo '<img src="'.$row['picture'].'" alt="'.$row['name'].'" /> ';
				} 
				else{
					echo '<img src="../company_pictures/'.$row['picture'].'" alt="'.$row['name'].'" /> ';
				}
				?>
				<div class="resumes-list-content">
					<h4><?php echo $row['name'] ?><span><?php echo $roww['company_name'] ?></span></h4>
					<?php if($roww['company_location'] != NULL){ 
						echo '<span class="icons"><i class="fa fa-map-marker"></i> '.$roww['company_location']. '</span>';} 
					?>
					<?php if($row['phone'] != NULL) echo '<span class="icons"><i class="fa fa-phone"></i> '.$row['phone'].' </span>'; ?>
					
					<span class="icons"><a href="#"><i class="fa fa-envelope"></i> <?php echo $row['email'] ?></a></span>
					<div class="clearfix"></div>

				</div>
			</div>
			
			<br/>
			
			<label>CareerStair Public Profile link</label>
				<input type="text" readonly style="background-image: url(../../images/imageedit_6_2629129789.png);background-repeat: no-repeat;background-position: 7px 7px 2px;text-indent:50px" class="search-field eight columns"  value="https://careerstairs.in/mass_profile.php?id=<?php echo $_SESSION['userData'] ?>">
			
		</div>
		
		
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Recent Jobs -->
	<div class="sixteen columns">
	
		<?php if($roww['company_name'] == NULL){
		echo '
		<h1>Congrats for new account !</h1>
		<h2>We are happy to have you with us</h2>
		<p>It\'s looks preety empty here , why don\'t you fill the company details so that it help users to find jobs and see details.</p>
		<div class="divider margin-top-0 padding-reset"></div>
		<a href="edit_resume.php"><button class="button big margin-top-5">Let\'s Get Started <i class="fa fa-arrow-circle-right"></i></button></a>
		';}
		else{
			echo '
				<div id="chartContainers" style="height: 370px; width: 100%;"></div>
				<br/><hr>';
			echo '<div id="chartContainer" style="height: 370px; width: 100%;"></div>';
			echo '<hr><br/>';
		}
		//let's count for jobs and then only show details of job
		$stm = $db->prepare("SELECT id FROM mass_jobs WHERE mass_username = ?");
		$stm->bind_param("s",$_SESSION['userData']);
		$stm->execute();
		$stm->store_result();
		$job_count = $stm->num_rows;
		$stm->free_result();
		if($job_count == 0){
			echo '<p class="margin-top-50">You have not posted any Job Profiles Yet !</p>';
		}
		else{
			echo '<p class="margin-top-50">Your Job Profile listings are shown in the table below. <strong>Please make sure to get filled the date and location for a job profile !</strong></p>
			
			<table class="manage-table resumes responsive-table">

				<tr>
					<th><i class="fa fa-file-text"></i>Job Profile</th>
					<th><i class="fa fa-check-square-o"></i>Action_?</th>
					<th><i class="fa fa-calendar"></i>Date</th>
					<th><i class="fa fa-calendar"></i>Location</th>
					<th><i class="fa fa-user"></i>Applications</th>
					<th><i class="fa fa-forumbee "></i> Status</th>
				</tr>';
				
			$stm = $db->prepare("SELECT * FROM mass_jobs WHERE mass_username = ? ORDER BY created DESC");
			$stm->bind_param("s",$_SESSION['userData']);
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				echo '
				<tr>
				
					<td class="title"><a href="job-overview.php?id='.$rim['id'].'" target="_blank">'.$rim['job_title'].' <span class="pending"></span></a></td>';
					if($rim['location'] == NULL && $rim['happen_date'] == NULL )
						echo '<td><i class="fa fa-close"></i></td>';
					else
						echo '<td><i class="fa fa-check"></i></td>';
				
					if($rim['happen_date'] == NULL)
						echo '<td>-</td>';
					else
						echo '<td>'.dateformat($rim['happen_date']).'</td>';
				
					if($rim['location'] == NULL)
						echo '<td>-</td>';
					else
						echo '<td>'.$rim['location'].'</td>';
					echo '<td><a target="_blank" class="button">'.count(json_decode($rim['users'])).'</a></td>';
					
					if($rim['location'] == NULL && $rim['happen_date'] == NULL)
						echo '<td>Not Visible</td>';
					else if($rim['location'] != NULL && $rim['happen_date'] != NULL && $today <= $rim['happen_date'])
						echo '<td>Visible</td>';
					else if($rim['location'] != NULL && $rim['happen_date'] != NULL && $today > $rim['happen_date'])
						echo '<td>Expired</td>';
					
					
				echo '</tr>';
			}
				
			echo '</table>
			
			';
		}
	?>
	
	</div>
	<!-- Widgets -->
	
</div>


<!-- Footer
================================================== -->
<div class="margin-top-45"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function () {
var chart = new CanvasJS.Chart("chartContainer", {
	theme: "light2",
	exportFileName: "Doughnut Chart",
	exportEnabled: true,
	animationEnabled: true,
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "doughnut",
		innerRadius: 90,
		showInLegend: true,
		toolTipContent: "<b>{name}</b>: {y} (#percent%)",
		indexLabel: "{name} - #percent% ({total} Candidates)",
		dataPoints: [
			<?php
				$stm = $db->prepare("SELECT job_title,users FROM mass_jobs WHERE mass_username = ? ORDER BY created ASC");
				$stm->bind_param("s",$_SESSION['userData']);
				$stm->execute();
				$ress = $stm->get_result();
				while($rim = $ress->fetch_assoc())
				{
					echo '{ y: '.count(json_decode($rim['users'])).', name: "'.$rim['job_title'].'", total: '.count(json_decode($rim['users'])).' },';
				}
			?>
		]
	}]
});
chart.render();

//big graph
var chartt = new CanvasJS.Chart("chartContainers", {
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	title:{
		text: "Job Profile Overview"
	},
	data: [{        
		type: "column",  
		showInLegend: true, 
		legendMarkerColor: "grey",
		legendText: "Overview",
		dataPoints: [      
			<?php
				$stm = $db->prepare("SELECT job_title,users FROM mass_jobs WHERE mass_username = ? ORDER BY created ASC");
				$stm->bind_param("s",$_SESSION['userData']);
				$stm->execute();
				$ress = $stm->get_result();
				while($rimm = $ress->fetch_assoc())
				{
					echo '{ y: '.count(json_decode($rimm['users'])).', label: "'.$rimm['job_title'].'" },';
				}
			?>
		]
	}]
});
chartt.render();

	
function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}

}
</script>
</body>

</html>