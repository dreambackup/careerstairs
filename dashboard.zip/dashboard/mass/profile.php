<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['mass'] == true) {
	
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, gender, picture, oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//fetchin users_profile info
	$stmt = $db->prepare("SELECT * FROM mass_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	$_SESSION['userpic'] = $row['picture'];
	//getting hashed password
	$options = [
	'cost' => 11,
	];
	$link = password(10);
	$link_hash = password_hash($link, PASSWORD_BCRYPT, $options);
	
}
else{
	header('Location: ../../login.php');
}
//function to produce a random number password by using md5 algo
function password($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
{
    $str = '';
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $str .= $keyspace[random_int(0, $max)];
    }
  return $str;
}
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$err = "";

	$phone = test_input($_POST["phone"]);
	$company_name = test_input($_POST["company_name"]);
	$company_type = test_input($_POST["company_type"]);
	$company_website = test_input($_POST["company_website"]);
	$company_location = test_input(ucfirst($_POST["location"]));
	$company_address =  mysqli_real_escape_string($db, test_input($_POST["company_address"]));
	$company_about =  mysqli_real_escape_string($db, test_input($_POST["company_about"]));
	
	
	//phone
	if(isset($phone) && !empty($phone) && preg_match("/^[0-9]*$/",$phone)){
	}
	else
		$err = $err . "Only Numbers are allowed in Phone Number </br>";
	
	//company name
	if(isset($company_name) && !empty($company_name) && (strlen($company_name) < 255)){
	}
	else
		$err = $err . "Problem with Company Name </br>";
	
	//company type
	if(isset($company_type) && !empty($company_type) && ($company_type == 'MNC' || $company_type == 'StartUp' || $company_type == 'Private Ltd Company' || $company_type == 'Public Ltd Company' ) ){
	}
	else
		$err = $err . "There is a Problem With Company Type </br>";
	
	//company website
	if(isset($company_website) && !empty($company_website) && (strlen($company_website) < 100)){
	}
	else
		$err = $err . "Problem with Company Website </br>";
	
	//company location
	if(isset($company_location) && !empty($company_location) && (strlen($company_location)<150)){
	}
	else
		$err = $err . "There is a Problem with Company Location </br>";
	
	//company address
	if(isset($company_address) && !empty($company_address) && (strlen($company_address)<255)){
	}
	else
		$err = $err . "Only 255 characters are allowed to fill the company address </br>";
	
	//company about
	if(isset($company_about) && !empty($company_about) && (strlen($company_about)<1000)){
	}
	else
		$err = $err . "Only 1000 characters are allowed to fill the about company </br>";
	
	//if email is not changed then just update the stuff
	//get image
	//starting profile pic coding
	$imgFile = $_FILES['file']['name'];
	$tmp_dir = $_FILES['file']['tmp_name'];
	$imgSize = $_FILES['file']['size'];
	
	if(isset($_SESSION['userpic']) && !empty($_SESSION['userpic'])){
	}
	if($imgFile)
  	{
   		$upload_dir = '../company_pictures/'; // upload directory 
		unlink($upload_dir.$_SESSION['userpic']);
   		$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
   		$valid_extensions = array('jpeg', 'jpg', 'png'); // valid extensions
   		$userpic = $_SESSION['userData'].$link.".".$imgExt;
   		if(in_array($imgExt, $valid_extensions)){   
   			if($imgSize < 1048576){	// don't want to delete the default pic
				move_uploaded_file($tmp_dir,$upload_dir.$userpic);
				$_SESSION['userpic'] = $userpic;
    		}
    		else{
     			$err = "Sorry, Your Company Logo is too large it should be less then 1 Mb </br>";
    		}
   		}
   		else{
    		$err = "Sorry, only JPG, JPEG, PNG files are allowed.";  
   		} 
  	}
	else if(!isset($_SESSION['userpic']) && empty($_SESSION['userpic']))
		$err = $err . 'There is a Problem with Image </br>';
	
	//now we have validate all inputs then just go inside 
	if($err == "")
	{
		//first we will try to figure out about the edit status
		if($roww['filled'] == '1')
		{
			$err = $err . 'Sorry You cannot edit the Info <br/>';	
		}
		else if($roww['filled'] == '0')
		{
			$count = 0;

			$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
			$stm->bind_param("s",$phone);
			$stm->execute();
			$stm->store_result();
			$count = $stm->num_rows;
			$stm->free_result();
			
			if($count == 0)
			{
				$flag = 0;
				if (($stmt = $db->prepare("UPDATE users_login SET phone = ?, picture = ? WHERE oauth_uid = ? "))) {
					if($stmt->bind_param("sss", $phone,$_SESSION['userpic'],$_SESSION['userData'])) {
						if ($stmt->execute()) {
							if(($stmtt = $db->prepare("UPDATE mass_profile SET filled = '1',company_name = ?, company_website = ?, company_about = ?, company_location = ?, company_address = ?, company_type = ?  WHERE username = ? "))){
								if($stmtt->bind_param("sssssss", $company_name, $company_website, $company_about,$company_location,$company_address,$company_type,$_SESSION['userData'])){
									if($stmtt->execute()){
										header("Location: index.php");	
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;

				if($flag == 1)
				{
					$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>";
				}
			}
			else{
				$err = $err . "Phone is already registered !";
			}
		}
		
	}
	if($err != ""){
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"'.$err.'", "error");}, 100);</script>';
	}
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
//function to change the lowercase data to capitalize the first letter of every word
function ucname($string) {
    $string =ucwords(strtolower($string));

    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Profile</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css" id="colors">

<script src="../../scripts/errors/sweetalert2.min.js"></script>
<link rel="stylesheet" href="../../scripts/errors/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="../../scripts/errors/core.js"></script>

<style>
	.image {
  		display: block;
  		width: 150px;
  		height: 150px;
  		margin: 1em auto;
  		background-size: cover;
  		background-repeat: no-repeat;
  		background-position: center center;
  		-webkit-border-radius: 99em;
  		-moz-border-radius: 99em;
  		border-radius: 99em;
 		border: 5px solid #eee;
  		box-shadow: 0 3px 2px rgba(0, 0, 0, 0.3);  
	}
.errspan {
    float: right;
    margin-right: 6px;
    margin-top: -40px;
    position: relative;
    z-index: 3;
}
	
.input-file-container {
  position: relative;
  width: 225px;
} 
.js .input-file-trigger {
  display: block;
  padding: 14px 45px;
  background: #39D2B4;
  color: #fff;
  font-size: 1em;
  transition: all .4s;
  cursor: pointer;
}
.js .input-file {
  position: absolute;
  top: 0; left: 0;
  width: 225px;
  opacity: 0;
  padding: 14px 0;
  cursor: pointer;
}
.js .input-file:hover + .input-file-trigger,
.js .input-file:focus + .input-file-trigger,
.js .input-file-trigger:hover,
.js .input-file-trigger:focus {
  background: #34495E;
  color: #39D2B4;
}

.file-return {
  margin: 0;
}
.file-return:not(:empty) {
  margin: 1em 0;
}
.js .file-return {
  font-style: italic;
  font-size: .9em;
  font-weight: bold;
}
.js .file-return:not(:empty):before {
  content: "Selected file: ";
  font-style: normal;
  font-weight: normal;
}

</style>
			

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">
		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" id="current" >Company Profile</a></li>
				<li><a href="post_job.php">Add Job Profiles</a></li>
				<li><a href="manage-jobs.php">Manage Job Profiles</a></li>
				<li><a href="email.php">Email</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-adjust"></i> Edit Company Profile </h2>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	
	<!-- Submit Page -->
	<div class="sixteen columns">
		<div class="submit-page">

		<div class="notification notice closeable margin-bottom-40">
				<p><span>Note: </span> You can only Change these details only once. So please fill Carefully, and if something went wrong then please contact our team about this issue !</p>
		</div>

		<form autocomplete="off" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" onsubmit="return checkSize(1048576)" autocomplete="off" enctype="multipart/form-data">
			<!-- Email -->
			<div class="form">
				<h5>Your Name</h5>
				<input class="search-field" type="text"value="<?php echo $row['name'] ?>" readonly />
			</div>

			<!-- Email -->
			<div class="form">
				<h5>Your Email</h5>
				<input class="search-field" type="email" value="<?php echo $row['email'] ?>" readonly />
			</div>

			<!-- gender -->
			<div class="form">
				<h5>Gender</h5>
				<select class="chosen-select" required name="gender" disabled >
					<option value="male" <?php echo ($row['gender'] == 'male')?"selected":"" ?> >Male</option>
					<option value="female" <?php echo ($row['gender'] == 'female')?"selected":"" ?> >Female</option>
				</select>
			</div>
			
			<!-- Title -->
			<div class="form">
				<h5>Mobile No</h5>
				<input class="search-field" type="text" placeholder="+91" value="<?php echo $row['phone'] ?>" pattern="^\d{10}$" onChange="checkphone()" title="Enter 10 digit Phone number" required  id="phone" name="phone" />
				
                <div id="phone-loading" class="errspan" style="display:none">
                	<i id="phone-i"></i>
                </div>
			</div>
			<hr>
			<div class="form">
				<h5>Company Name</h5>
				<input class="search-field" type="text" placeholder="Enter Your Company Name" maxlength="255" required name="company_name" value="<?php echo $roww['company_name'] ?>">
			</div>
			
			<!-- company type -->
			<div class="form">
				<h5>Company Type</h5>
				<select class="chosen-select" required name="company_type">
					<option value="" >Please select your Company Type</option>
					<option value="MNC" <?php echo ($roww['company_type'] == 'MNC')?"selected":"" ?> >MNC</option>
					<option value="StartUp" <?php echo ($roww['company_type'] == 'StartUp')?"selected":"" ?> >StartUp</option>
					<option value="Private Ltd Company" <?php echo ($roww['company_type'] == 'Private Ltd Company')?"selected":"" ?> >Private Ltd Company</option>
					<option value="Public Ltd Company" <?php echo ($roww['company_type'] == 'Public Ltd Company')?"selected":"" ?> >Public Ltd Company</option>
				</select>
			</div>
			
			<!-- Website -->
			<div class="form">
				<h5>Company Website <span>(Required)</span></h5>
				<input class="search-field" type="text" required placeholder="http://" name="company_website" maxlength="100" value="<?php echo $roww['company_website'] ?>" >
			</div>
			
			<div class="form">
				<h5>Company Location</h5>
				<input class="search-field" pattern="[A-Za-z]{2,150}" type="text" placeholder="Enter your Company City" value="<?php echo $roww['company_location'] ?>" name="location" required style="text-transform: capitalize" />
			</div>
			
			<!-- Description -->
			<div class="form">
				<h5>Company Address</h5>
				<textarea name="company_address" rows="5" style="resize:none" maxlength="255" required spellcheck="true" placeholder="Enter Company Address"><?php echo $roww['company_address'] ?></textarea>
			</div>
			
			<div class="form">
				<h5>About Company</h5>
				<textarea required maxlength="1000" placeholder="Write about your company" rows="10" style="resize: none" name="company_about"><?php echo $roww['company_about'] ?></textarea>
			</div>
			
			<!-- Logo -->
			<label class="fileContainer" for="file-input">Company Logo <span>(Required)</span></label>
				
				<div class="input-file-container"> 
   				
   				<?php
	
					if(isset($_SESSION['userpic']))
						echo '<input class="input-file" type="file" accept="image/*" onchange="loadFile(event)" id="upload" name="file">';
					else
						echo '<input class="input-file" type="file" accept="image/*" onchange="loadFile(event)" id="upload" name="file"  required>';

				?>
   				
    				<label tabindex="0" for="my-file" class="input-file-trigger" style="text-align: center">Select a file...</label>
  				</div>
  				<p class="file-return"></p>

			<?php
					
				if(isset($_SESSION['userpic']))
					echo '<img class="image" id="output" src="../company_pictures/'.$_SESSION['userpic'].'"';
				else
					echo '<img class="image" id="output" ';
			?>
			
			<div class="divider margin-top-0 padding-reset"></div>
			<?php if($roww['filled'] == '0'){
					echo '<button class="button big margin-top-5" type="submit">Save <i class="fa fa-arrow-circle-right"></i></button>';
				}
			
			?>
			
			</form>
		</div>
	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<!--image-->
<script>
	
	//try new
	localStorage.setItem('url', output.src);
	
	var loadFile = function(event) {
    	var output = document.getElementById('output');
    	output.src = URL.createObjectURL(event.target.files[0]);
		localStorage.setItem('url', output.src);
  	};
	
	document.querySelector("html").classList.add('js');
	var fileInput  = document.querySelector( ".input-file" ),  
    button     = document.querySelector( ".input-file-trigger" ),
    the_return = document.querySelector(".file-return");
      
	button.addEventListener( "keydown", function( event ) {  
		if ( event.keyCode == 13 || event.keyCode == 32 ) {  
			fileInput.focus();  
		}  
	});
	button.addEventListener( "click", function( event ) {
	   fileInput.focus();
	   return false;
	});  
	fileInput.addEventListener( "change", function( event ) {  
		the_return.innerHTML = this.value;  
	});  
	
</script>

<!-- script to check email duplicasy via ajax -->
<script>


//<!-- function to check phone duplicasy -->
	
	function checkphone() {
		var name = $("#phone").val();
		if(name.length > 7 && name != '<?php echo $row['phone'] ?>' )
		{
		$('#phone-loading').show();
		$("#phone-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
		
		jQuery.ajax({
			url: "ajaxData.php",
			data:'phone='+$("#phone").val(),
			type: "POST",
			success:function(data){
				if(data == 1) {
					$("#phone-i").removeClass();
					$("#phone-i").addClass("fa fa-close fa-2x");
					$("#phone-i").css("color", "red");
				
				}else{
					$("#phone-i").removeClass();
					$("#phone-i").addClass("fa fa-check fa-2x");
					$("#phone-i").css("color", "green");
				}
				
			},
			error:function (){}
		});
	}
	else{
		$("#phone-loading").hide();
		$("#phone-i").removeClass();
		$("#phone-i").css("color", "");
	}
}
	
	function checkSize(max_img_size)
	{
		var input = document.getElementById("upload");
		// check for browser support (may need to be modified)
		if(input.files && input.files.length == 1)
		{           
			if (input.files[0].size > max_img_size) 
			{
				swal(
					  'Warning',
					  'File Size Must be less than 1 Mb !',
					  'warning'
					)
				return false;
			}
		}
	
		return true;
	}
	
</script>

</body>

</html>