<?php
include('../../db/config.php');
session_start();
error_reporting(0);
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//fetchin users_profile info
	$stmt = $db->prepare("SELECT * FROM users_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
}
else{
	header('Location: ../../login.php');
}
function dateformat($new) {
	if($new == 'Present')
		return $new;
	else{
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $convert_month . " " . $year;
	return $final;
	}
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Resume</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css" id="colors">
<link href="../../css/resume.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic|Open+Sans+Condensed:300,300italic,700" rel="stylesheet" type="text/css"/>

<link rel="stylesheet"  href="print_stuff/bootstrap.min.css" />
 <script src="print_stuff/bootstrap.min.js"></script>
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="#" id="current">Resume</a>
					<ul>
						<li><a href="resume.php">View Resume</a></li>
						<li><a href="edit_resume.php">Edit Resume</a></li>
					</ul>
				</li>
				<li><a href="skills_match_jobs.php">Browse Jobs</a></li>
				<li><a href="applied_jobs.php">Applied Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>

<!-- Content
================================================== -->
<div id="wrapper">
	<div class="container-fluid" id="content">
		<div class="max-width-container" id="resume_max_width_container">
			<div id="content-inner">
				<div id="layout_table" style="width:100% !important;">
					<div style="text-align: right;">
						<div class="button-container">
							<a href="just_print.php" target="_blank"><button class="btn btn-primary">DOWNLOAD RESUME</button></a>
						</div>  
					</div>
									<div id="printableArea">
					<div id="resume-container">
					<hr class="resume-progress">
						<div class="resume-body" id="hello">
							<!-- resume heading -->
							 <div class="details-table row  personal-details">
								<div class="details-left-cell">
								</div>
								<div class="details-right-cell">
									<div class="detail-row row">
										<div class="detail-left-element col-sm-11">
											<ul>
												<li><h2><?php echo $row['name'] ?></h2></li>
												<li><?php echo $row['email'] ?></li>
												<li><?php echo $row['phone'] ?></li>
												<li><?php echo $roww['city'] ." , ". $roww['state'] ?></li>
											</ul>
										</div>
									</div>
								</div>
							</div>

			<?php
			if($roww['education'] != NULL)
			{
				echo '<!-- education start -->
				 <div class="details-table row resume-education ">
					<div class="details-left-cell col-sm-3"><h4>EDUCATION</h4></div>
					<div class="details-right-cell col-sm-9">
						<div class="education-container">';
						
							$education = json_decode($roww['education']);
							for($i=0;$i<count($education);$i++)
							{
								echo '<div class="prefilled-education-details-row detail-row">
									<div class="prefilled-education-details-left-cell detail-left-element">
										<h5>'.$education[$i][1].','.$education[$i][2].' ('.$education[$i][4].' - '.$education[$i][5].')</h5>
										<div>'.$education[$i][0].'</div>
										<div>CGPA : '.$education[$i][3].'</div>
									</div>
								</div>';
							}

					echo '</div>                        
					</div>
				</div>
				<!-- education end -->';
				}
			?>

			<?php
			if($roww['work'] != NULL)
			{
				echo '<!--experience start -->
				 <div class="details-table row resume-internship">
					<div class="details-left-cell col-sm-3"><h4>WORK EXPERIENCES</h4></div>
					<div class="details-right-cell col-sm-9">
						<div class="internship-container">';
							
							$work = json_decode($roww['work']);
							for($i=0;$i<count($work);$i++)
							{

							echo '<div class = "prefilled-experiences-details-row detail-row">
									<div class = "prefilled-experiences-details-left-cell detail-left-element">
										<h5>'.$work[$i][0].'</h5>
										<div>'.$work[$i][1].'('.$work[$i][2].')</div>
										<div>'.dateformat($work[$i][3]).' - '.dateformat($work[$i][4]).'</div>
										<div class="description">'.$work[$i][5].'</div>
									</div>
								</div>';
							}
							
					echo '</div>                        
					</div>
				</div>
				<!-- experience end -->';
				}
			 ?>


			<?php
			if($roww['projects'] != NULL)
			{
			   echo '<!-- projects start -->
				<div class="details-table row resume-project">
					<div class="details-left-cell col-sm-3"><h4>PROJECTS</h4></div>
					<div class="details-right-cell col-sm-9 prefilled-projects-details">
						<div class="project-container">';
						
							$projects = json_decode($roww['projects']);
								for($i=0;$i<count($projects);$i++)
								{
								echo '<div class = "prefilled-other-experiences-details-row detail-row">
									<div class = "prefilled-other-experiences-details-left-cell detail-left-element">
										<h5>'.$projects[$i][0].'</h5>
										<div>'.dateformat($projects[$i][2]).' - '.dateformat($projects[$i][3]).'</div>
										<div><a href = "'.$projects[$i][1].'" target = "_blank">'.$projects[$i][1].'</a></div>
										<div class="description">'.$projects[$i][4].'</div>
									</div>
								</div>';
								}
							
					echo '</div>                       
					</div>
				</div>
				<!-- projects end -->';
				}
			?>
				
				
			<?php 
				if($roww['skills'] != NULL)
				{
				 echo '<!-- skills start -->
				<div class="details-table row resume-skill ">
					<div class="details-left-cell col-sm-3"><h4>SKILLS</h4></div>
					<div class="details-right-cell col-sm-9">
						<div class="skills-container prefilled-skills-details">';
						 
						//getting skills as json then decode it in array
						$skills = json_decode($roww['skills']);
							for($i=0;$i<count($skills);$i++)
							{
								echo '<div class="prefilled-skills-details-row detail-row">
								<div class="prefilled-skills-details-left-cell detail-left-element">
									<div class="title"><h5>'.$skills[$i].'</h5></div>
								</div>
							</div>';
							}
						
				  echo	'</div>
					</div>
				</div>
			   <!-- skills end -->';
				}
			  ?>

		   <?php 
			if($roww['links'] != NULL)
			{
			   echo '<!-- work samples start -->
				<div class="details-table row resume-work-sample">
					<div class="details-left-cell col-sm-3"><h4>WORK SAMPLES</h4></div>
					<div class="details-right-cell col-sm-9">';
					
					$links = json_decode($roww['links']);
					for($i=0;$i<count($links);$i++)
					{
					echo '<div class="work-sample-container">
							<div class="detail-row">
								<div class="detail-left-element">';
								if(!empty($links[$i][1])){
									echo '<div class="title">'.$links[$i][0].' :</div>
									 <div class="work_sample_url_break"><a href="'.$links[$i][1].'" target="_blank">'.$links[$i][1].'</a></div>';
								}
								echo '</div>
							</div>
						</div>';
					}
					echo '</div>
				</div>
				<!-- work samples end -->';
			}
			?>

			<?php
				if($roww['acheivements'] != NULL)
				{
				echo '<!-- acheivements start-->
				<div class="details-table row resume-additional-detail">
					<div class="details-left-cell col-sm-3"><h4>ADDITIONAL DETAILS</h4></div>
					<div class="details-right-cell col-sm-9">
						<div class="additional-details-container prefilled-additional-details">';
							//getting acheivements as json then decode it in array
							$acheivements = json_decode($roww['acheivements']);

							for($i=0;$i<count($acheivements);$i++)
							{
								echo '<div class="prefilled-additional-details-row detail-row user-additional-detail">
									<div class="prefilled-additional-details-left-cell detail-left-element">
										<div>
											<ul style="list-style-type: circle;">
												<li><span>'.$acheivements[$i].'</span></li>
											</ul>
										</div>
									</div>
								</div>';
							}
							
				echo	'</div>                            
					</div>
				</div>
				<!-- acheivements ends-->';
				}
			?>
						
							</div>
						</div>
								<!-- printable div -->	</div>
					</div>  
				</div>
			</div>
		</div>
	</div>

<!-- Footer
================================================== -->
<div class="margin-top-50" style="padding-top: 100px"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

	</body>
</html>