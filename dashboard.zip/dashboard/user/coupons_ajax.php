<?php
	session_start();
	//Include database configuration file
	include('../../db/config.php');

	error_reporting(0);

	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
	}
	else{
		header('Location: ../../login.php');
	}

	

	if(isset($_POST["value"]) && !empty($_POST["value"]) && isset($_POST["user"]) && !empty($_POST["user"]) && isset($_POST["coup"]) && !empty($_POST["coup"]) ){
		
		$id = test_input($_POST["value"]);
		$user_id = test_input($_POST["user"]);
		$coup_name = test_input($_POST["coup"]);
		
		$stm = $db->prepare("SELECT status,code,company_name,expiry,coupon_limit,description,coupon_url,terms,applied_users,visible,user_type FROM coupons WHERE id = ? AND code = ? ");
		$stm->bind_param("ss",$id,$coup_name);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3,$col4,$col5,$col6,$col7,$col8,$col9,$col10,$col11);

		while ($stm->fetch()) {
        	$status = $col1;
			$code = $col2;
			$company_name = $col3;
			$expiry = $col4;
			$limit = $col5;
			$desc = $col6;
			$coupon_url = $col7;
			$terms = json_decode($col8);
			$users = json_decode($col9);
			$visible = $col10;
			$user_type = $col11;
    	}
		$err = '';
		
		//check valid status
		if($visible == 'Yes'){
		}
		else
			$err = $err. "Problem with Coupon ";
		//let's check it should be valid for only jobseeker or both
		if(($user_type == 'Jobseeker') || ($user_type == 'Both')){
		}
		else
			$err = $err. "The Coupon is not for Jobseeker ";
		
		//lets check if it's valid or not a.c to date
		$today =  date("Y-m-d");
		if($today > $expiry)
			$err = $err. "The coupon is Expired ";
		//it's status should be enable
		if($status == 0)
			$err = $err . "The coupon is not Valid ";
		//it's limit must not be extended
		$count_users = count($users);
			if($limit > 0)
				if(intval($limit -$count_users) <= 0)
					$err = $err . "Coupon Limit exceeds ";
			
		//if he has already activated or not
		for($i=0;$i<$count_users;$i++){
			if($users[$i][0] == $user_id){
				$err = $err . 'Activated On '.dateformat($users[$i][1]).'';
				break;
			}
		}
		
		$data = array(
			'status' =>$status,
			'code' => $code,
			'company_name' => $company_name,
			'expiry' => $expiry,
			'limit' => $limit,
			'desc' => $desc,
			'coupon_url' => $coupon_url,
			'terms' => $terms,
			'err' => $err,
		);
		echo json_encode($data);
		
		$stm->free_result();
		
	}

//new code

if(isset($_POST["coupm"]) && !empty($_POST["coupm"]) && isset($_POST["userm"]) && !empty($_POST["userm"])){
		
		$user_id = test_input($_POST["userm"]);
		$coup_name = test_input($_POST["coupm"]);
	
	//lets check if it's valid or not
	$count = 0;
	$stm = $db->prepare("SELECT id FROM coupons WHERE code = ?");
	$stm->bind_param("s",$coup_name);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
	if($count == 1){
		
		$stm = $db->prepare("SELECT status,code,company_name,expiry,coupon_limit,description,coupon_url,terms,applied_users,visible,user_type,id FROM coupons WHERE code = ? ");
		$stm->bind_param("s",$coup_name);
		$stm->execute();
		$stm->bind_result($col1,$col2,$col3,$col4,$col5,$col6,$col7,$col8,$col9,$col10,$col11,$col12);

		while ($stm->fetch()) {
        	$status = $col1;
			$code = $col2;
			$company_name = $col3;
			$expiry = $col4;
			$limit = $col5;
			$desc = $col6;
			$coupon_url = $col7;
			$terms = json_decode($col8);
			$users = json_decode($col9);
			$visible = $col10;
			$user_type = $col11;
			$cou_id = $col12;
    	}
		$err = '';
		
		//check valid status
		if($visible == 'No'){
		}
		else
			$err = $err. "Problem with Coupon ";
		//let's check it should be valid for only jobseeker or both
		if(($user_type == 'Jobseeker') || ($user_type == 'Both')){
		}
		else
			$err = $err. "The Coupon is not for Jobseeker ";
		
		//lets check if it's valid or not a.c to date
		$today =  date("Y-m-d");
		if($today > $expiry)
			$err = $err. "The coupon is Expired ";
		//it's status should be enable
		if($status == 0)
			$err = $err . "The coupon is not Valid ";
		//it's limit must not be extended
		$count_users = count($users);
			if($limit > 0)
				if(intval($limit -$count_users) <= 0)
					$err = $err . "Coupon Limit exceeds ";
			
		//if he has already activated or not
		for($i=0;$i<$count_users;$i++){
			if($users[$i][0] == $user_id){
				$err = $err . 'Activated On '.dateformat($users[$i][1]).'';
				break;
			}
		}
		
		$data = array(
			'status' =>$status,
			'code' => $code,
			'company_name' => $company_name,
			'expiry' => $expiry,
			'limit' => $limit,
			'desc' => $desc,
			'coupon_url' => $coupon_url,
			'terms' => $terms,
			'id' => $cou_id,
			'err' => $err,
		);
		echo json_encode($data);
		
		$stm->free_result();
	}
	else{
		$data = array(
			'err' => 'Invalid Coupon Code',
		);
		echo json_encode($data);
	}
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function dateformat($new) {
	
	$date = substr($new,-2);
	$new = substr($new,0,-3);
	
	$month_array = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $month = substr($new, -2);
	$year = substr($new,0,4);
	if($month[0] == '0')
		$month = substr($month,-1);
		$convert_month = $month_array[$month];
	$final = $date. " ". $convert_month . " " . $year;
	return $final;
}
?>