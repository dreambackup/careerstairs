<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//fetchin users_profile info
	$stmt = $db->prepare("SELECT * FROM users_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
}
else{
	header('Location: ../../login.php');
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">
<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Applied Jobs</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css">

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php" >Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="#">Resume</a>
					<ul>
						<li><a href="resume.php">View Resume</a></li>
						<li><a href="edit_resume.php">Edit Resume</a></li>
					</ul>
				</li>
				<li><a href="skills_match_jobs.php">Browse Jobs</a></li>
				<li><a href="applied_jobs.php" id="current">Applied Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<span style="font-size: 24px;color: white">You have applied for &nbsp;  <strong style="color: gold"><?php echo count(json_decode($roww['jobs'])) ?></strong> &nbsp; jobs:</span>
		</div>
	</div>
</div>


<!-- Content
================================================== -->
<div class="container">
	<!-- Recent Jobs -->
	<div class="thirteen column">
	<div class="padding-right">
	<ul class="job-list full" id="myList" >
	
	<?php
	
		$job = json_decode($roww['jobs']);
		$job_count = count($job);
		
		for($i=0;$i<$job_count;$i++)
			$jobs[$i] = $job[$i][0];
				
		if(!empty($jobs))
		{
			$stm = $db->prepare("SELECT * FROM jobs WHERE id IN (".implode(",", $jobs).") ");
			$stm->execute();
			$ress = $stm->get_result();
			while($rim = $ress->fetch_assoc())
			{
				for($i=0;$i<$job_count;$i++)
				{
					if($job[$i][0] == $rim['id'])
					{
						$status = $job[$i][1];
						
						if($status == 0)
						{
							$flag = 'Pending';
							$color = 'gray';
						}
						else if($status == 1)
						{
							$flag = 'Selected';
							$color = 'green';
						}
						else if($status == 2)
						{
							$flag = 'Rejected';
							$color = 'red';
							
						}
					}
				}
				echo '
					<li><a href="job-overview.php?id='.$rim['id'].'" target="_blank">
					<img src="../company_pictures/'.$rim['company_pic'].'" alt="'.$rim['company_name'].'">
					<div class="job-list-content">
						<h3>'.$rim['job_title'].'<span style="font-size: 25px;color: '.$color.';padding-left: 15px">('.$flag.')</span></h3>
						<h5 style="padding-bottom: 5px">'.$rim['company_name'].'</h5>
						<div class="job-icons">
							<span><i class="fa fa-calendar"></i>'.$rim['exp'].'+ Years</span>
							<span><i class="fa fa-inr"></i>'.$rim['package_min'].' - '.$rim['package_max'].' LPA</span>
							<span><i class="fa fa-map-marker"></i>'.implode(" , ",json_decode($rim['location'])).'</span>
						</div>
						<p>'.substr($rim['job_details'],0,250).'  ...<span style="color: green;font-weight: bold;">read more</span></p>
					</div>
					</a>
					<div class="clearfix"></div>
				</li>

				';
			}
			
			$stm->free_result();
			echo '</ul>
			<div class="clearfix"></div>
			<div class="pagination-container" align="center">
				<a href="javascript:void(0)" id="loadMore">Load More</a>
			</div>';
		}
		else 
			echo '<h1>You\'ve not applied for any job</h1></ul>';
	?>
		
		
	</div>
	</div>
</div>

<style>
#myList li{ display:none;
}

#loadMore, #loadMore:visited{
	color: #33739E;
    text-decoration: none;
    display: block;	
}
#loadMore {
    padding: 10px;
    text-align: center;
    background-color: #33739E;
    color: #fff;
    border-width: 0 1px 1px 0;
    border-style: solid;
    border-color: #fff;
    box-shadow: 0 1px 1px #ccc;
    transition: all 600ms ease-in-out;
    -webkit-transition: all 600ms ease-in-out;
    -moz-transition: all 600ms ease-in-out;
    -o-transition: all 600ms ease-in-out;
}
#loadMore:hover {
    background-color: #fff;
    color: #33739E;
}

</style>


<!-- Footer
================================================== -->
<div class="margin-top-25"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>
<script>
	$(document).ready(function () {
    size_li = $("#myList li").length;
    x=3;
    $('#myList li:lt('+x+')').show();
    $('#loadMore').click(function () {
        x= (x+5 <= size_li) ? x+5 : size_li;
		
        $('#myList li:lt('+x+')').show();
    });
});</script>
</body>


</html>