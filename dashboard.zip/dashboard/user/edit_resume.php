<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, picture,oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//fetchin users_profile info
	$stmt = $db->prepare("SELECT * FROM users_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	$current = date('Y-m');
	
	$current_year = date('Y');
	
}
else{
	header('Location: ../../login.php');
}
if(isset($_POST['first_form']))
{
	$title = ucname(test_input($_POST["title"]));
	$objective = test_input($_POST["objective"]);
	$skills = test_input($_POST["skills"]);
	$video = test_input($_POST["video"]);
	$skills_array = json_encode(array_map('trim',explode(",",$skills)));
	
	$flag = 0;
	if (($stmt = $db->prepare("UPDATE users_profile SET title = ?, objective = ?, skills = ?, video = ? WHERE username = ? "))) {
		if($stmt->bind_param("sssss", $title, $objective, $skills_array,$video,$_SESSION['userData'])) {
			if ($stmt->execute()) {
					header("Location: edit_resume.php");
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;
	}
	else
		$flag = 1;

	if($flag == 1)
	{
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>", "error");}, 100);</script>';
	}
}
if(isset($_POST['acheivements']))
{
	if(isset($_POST['acheivement']))
	$acheivements_array = json_encode(array_map('trim',array_map('htmlspecialchars',array_filter($_POST["acheivement"]))));
	
	$flag = 0;
	if(!empty($acheivements_array))
	{	
		if (($stmt = $db->prepare("UPDATE users_profile SET acheivements = ? WHERE username = ? "))) {
			if($stmt->bind_param("ss",$acheivements_array,$_SESSION['userData'])) {
				if ($stmt->execute()) {
						header("Location: edit_resume.php");
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;

		if($flag == 1)
		{
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>", "error");}, 100);</script>';
		}
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"No data is being given !", "error");}, 100);</script>';
}
if(isset($_POST['works']))
{
	$work_array = $_POST['work'];
	//check present or not
	for($i = 4;$i<count($work_array);$i++)
	{
		if($work_array[$i] == "Present")
		{
			array_splice($work_array,$i+1,1);
		}
		else if($work_array[$i] == "No")
		{
			$work_array[$i] = $work_array[$i+1];
			array_splice($work_array,$i+1,1);
		}
	}
	//change the htmlspecial
	$work_array = array_map('trim',array_map('htmlspecialchars',$work_array));
	//not convert it into 2d array
	$j=0;
	$works_array = array();
	for($i = 0;$i<count($work_array);$i++)
	{
		if($i%6 == 0)
		{
			$j++;
		}
		
		$works_array[$j][$i%6] = $work_array[$i];
		
	}
	
	$new = array_values((array)$works_array );
	$flag = 0;
	if(!empty($works_array))
	{	
		if (($stmt = $db->prepare("UPDATE users_profile SET work = ? WHERE username = ? "))) {
			if($stmt->bind_param("ss",json_encode($new),$_SESSION['userData'])) {
				if ($stmt->execute()) {
						header("Location: edit_resume.php");
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;

		if($flag == 1)
		{
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>", "error");}, 100);</script>';
		}
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"No data is being given !", "error");}, 100);</script>';
}
if(isset($_POST['profiles']))
{
	$linkedin = test_input($_POST["linkedin"]);
	$github = test_input($_POST["github"]);
	$blog = test_input($_POST["blog"]);
	$portfolio = test_input($_POST["portfolio"]);
	$profiles_array = [["LinkedIn",$linkedin],["Github",$github],["Blog",$blog],["Portfolio",$portfolio]];
	
	$flag = 0;
	if(!empty($profiles_array))
	{	
		if (($stmt = $db->prepare("UPDATE users_profile SET links = ? WHERE username = ? "))) {
			if($stmt->bind_param("ss",json_encode($profiles_array),$_SESSION['userData'])) {
				if ($stmt->execute()) {
						header("Location: edit_resume.php");
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;

		if($flag == 1)
		{
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>", "error");}, 100);</script>';
		}
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"No data is being given !", "error");}, 100);</script>';
	
}
if(isset($_POST['educations']))
{
	$education_array = $_POST['education'];
	
	//check present or not
	for($i = 5;$i<count($education_array);$i++)
	{
		if($education_array[$i] == "Present")
		{
			array_splice($education_array,$i+1,1);
		}
		else if($education_array[$i] == "No")
		{
			$education_array[$i] = $education_array[$i+1];
			array_splice($education_array,$i+1,1);
		}
	}
	//change the htmlspecial
	$education_array = array_map('trim',array_map('htmlspecialchars',$education_array));
	//not convert it into 2d array
	$j=0;
	print_r($education_array);
	$educations_array = array();
	for($i = 0;$i<count($education_array);$i++)
	{
		if($i%6 == 0)
		{
			$j++;
		}
		$educations_array[$j][$i%6] = $education_array[$i];
	}
	
	$new = array_values((array)$educations_array);
	
	$flag = 0;
	if(!empty($educations_array))
	{	
		if (($stmt = $db->prepare("UPDATE users_profile SET education = ? WHERE username = ? "))) {
			if($stmt->bind_param("ss",json_encode($new),$_SESSION['userData'])) {
				if ($stmt->execute()) {
						header("Location: edit_resume.php");
				}
				else
					$flag = 1;
			}
			else
				$flag = 1;
		}
		else
			$flag = 1;

		if($flag == 1)
		{
			echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>", "error");}, 100);</script>';
		}
	}
	else
		echo '<script type="text/javascript">setTimeout(function(){ swal("Error !" ,"No data is being given !", "error");}, 100);</script>';
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function ucname($string) {
    $string =ucwords(strtolower($string));
    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Edit Resume</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/custom.css">
<link rel="stylesheet" href="../../css/colors/green.css">

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">

		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php" >Profile</a></li>
				<li><a href="#" id="current">Resume</a>
					<ul>
						<li><a href="resume.php">View Resume</a></li>
						<li><a href="edit_resume.php">Edit Resume</a></li>
					</ul>
				</li>
				<li><a href="skills_match_jobs.php">Browse Jobs</a></li>
				<li><a href="applied_jobs.php">Applied Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-certificate"></i> Edit Resume </h2>
		</div>
	</div>
</div>

<!-- Content
================================================== -->
<div class="container">
	
	<!-- Submit Page -->
	<div class="sixteen columns">
		<div class="submit-page">
			<form autocomplete="off" method="post">
			
			<!-- Title -->
				<div class="form">
					<h5>Professional Title</h5>
					<input class="search-field" type="text" placeholder="e.g. Web Developer || Full Stack Developer" pattern="[A-Za-z\s]{3,255}" value="<?php echo $roww['title'] ?>" required name="title" />
				</div>

				<!-- Description -->
				<div class="form">
					<h5>Objective</h5>
					<textarea rows="3" style="resize:none" name="objective" spellcheck="true" maxlength="255" required ><?php echo $roww['objective'] ?></textarea>
				</div>

				<div class="form">
					<h5>Skills</h5>
					<input type="text" data-role="tagsinput" id="skills" required name="skills" value="<?php echo implode(",",json_decode($roww['skills'])) ?>" />
				</div>
				
				<div class="form">
					<h5>Video <span>(optional)</span></h5>
					<input class="search-field" type="text" placeholder="A Youtube link to a video about you" value="<?php echo $roww['video'] ?>" maxlength="255" pattern="https?://(www\.)?youtube\.com/watch\?.*v=([a-zA-Z0-9]+).*" name="video" />
					<span>Format : https://www.youtube.com/watch?v=F9dtepkeR0I</span>
				</div>
				
				<button type="submit" name="first_form">Save</button>
				<br/>
				<br/>
			</form>
			
			<!-- now let's work on acheivements -->
			<div class="form with-line">
			<h5>Achievements</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
							<h3 class="panel-title">Total <?php echo count(json_decode($roww['acheivements'])) ?> Acheivements</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
							<form method="post" autocomplete="off">
								<!-- Adding dynamic boxes -->
								<div id="acheivement">
								<?php
									$acheivement = json_decode($roww['acheivements']);
									for($i=0;$i<count($acheivement);$i++)
									{
									  echo '<div class="form boxed">
												<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
												<textarea required class="search-field" rows="2" style="resize: none" name="acheivement[]" maxlength="255" title="Maxlength of 255">'.$acheivement[$i].'</textarea>
											</div>';
									}
								?>
								</div>
								<a href="javascript:void(0)" onClick="addInput1('acheivement');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
								<p class="note">Acheivements help the recruiter to know about capabilities !</p>
						</div>
						<button type="submit" name="acheivements">Save</button>
							</form>
					</div>
				</div>
			</div>
			<!-- finish acheivements -->
			
			<!-- now let's work on experience -->
			<div class="form with-line">
			<h5>Experience</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
							<h3 class="panel-title">Total <?php echo count(json_decode($roww['work'])) ?> Experience</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
							<form method="post" autocomplete="off">
								<!-- Adding dynamic boxes -->
								<div id="work">
									<?php
									$work = json_decode($roww['work']);
									for($i=0;$i<count($work);$i++)
									{
									  echo '
									  	<div class="form boxed ">
				<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
				<input class="search-field" type="text" name="work[]" placeholder="Job Title" value="'.$work[$i][0].'" pattern="[A-Za-z\s]{3,100}" required/>
				<input class="search-field" type="text" placeholder="Company Name" required name="work[]" value="'.$work[$i][1].'" pattern="[A-Za-z\s]{3,255}" />
				<input class="search-field" type="text" name="work[]" required value="'.$work[$i][2].'" id="worktags'.$i.'" maxlength="50" data-onload="locations(this.id)" />
				<div style="display: inline-block;padding-right: 150px">
					<label>Enter Joining date </label>
					<input id="work'.$i.'startinput" type="month" class="search-field" style="padding: 10px" required name="work[]" max="'.$current.'" onchange="checkdate(this,'.$i.');" value="'.$work[$i][3].'" />
				</div>
				'; 
						if($work[$i][4] == 'Present')
						{
							echo '<div style="display: inline-block;padding-right: 150px">
									<label>Are you still working ?</label>
									<select class="chosen-select" required onchange="yesnoCheck(this);" id="work'.$i.'" name="work[]">
										<option value="">Select Option</option>
										<option selected value="Present">Yes</option>
										<option value="No">No</option>
									</select>
								</div>
								<div style="display: none" id="work'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="work'.$i.'endinput" type="month" class="search-field" style="padding: 10px" name="work[]" value="" />
								</div>
								
								';
						}
						else
							echo '
								<div style="display: inline-block;padding-right: 150px">
									<label>Are you still working ?</label>
									<select style="padding: 10px" required onchange="yesnoCheck(this);" id="work'.$i.'" name="work[]">
										<option value="">Select Option</option>
										<option value="Present">Yes</option>
										<option selected value="No">No</option>
									</select>
								</div>
								<div style="display: inline-block" id="work'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="work'.$i.'endinput" type="month" class="search-field" style="padding: 10px" min="'.$work[$i][3].'" max="'.$current.'" name="work[]" value="'.$work[$i][4].'" required />
								</div>
							
							';
					
					echo '
				
					<textarea required class="search-field" rows="2" style="resize: none" name="work[]" maxlength="255" title="Maxlength of 255" placeholder="About the Work/Role">'.$work[$i][5].'</textarea>			
								
			</div>
									  ';
									}
								?>
								</div>
								<a href="javascript:void(0)" onClick="addInput2('work');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
						</div>
						<button type="submit" name="works">Save</button>
							</form>	
					</div>
				</div>
			</div>
			<!-- finish Experience -->
			<!--projects start -->
			
			<div class="form with-line">
			<h5>Projects</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
							<h3 class="panel-title">Total <?php echo count(json_decode($roww['projects'])) ?> Projects</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
							<form method="post" autocomplete="off">
								<!-- Adding dynamic boxes -->
								<div id="projects">
									<?php
									$projects = json_decode($roww['projects']);
									for($i=0;$i<count($projects);$i++)
									{
									  echo '
									  	<div class="form boxed ">
				<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
				<input class="search-field" type="text" name="projects[]" placeholder="Project Title" value="'.$projects[$i][0].'" maxlength = "100" required/>
				<label>Project Url if any ?</label>
				<input class="search-field" type="text" pattern="https?://.+" placeholder="Projects URL" name="projects[]" value="'.$projects[$i][1].'" maxlength = "150" />
				<div style="display: inline-block;padding-right: 150px">
					<label>Enter Joining date </label>
					<input id="projects'.$i.'startinput" type="month" class="search-field" style="padding: 10px" required name="projects[]" onchange="checkdates(this,'.$i.');" value="'.$projects[$i][2].'" max="'.$current.'" />
				</div>
				'; 
						if($projects[$i][3] == 'Present')
						{
							echo '<div style="display: inline-block;padding-right: 150px">
									<label>Are you still working ?</label>
									<select class="chosen-select" required onchange="yesnoCheck(this);" id="projects'.$i.'" name="projects[]">
										<option value="">Select Option</option>
										<option selected value="Present">Yes</option>
										<option value="No">No</option>
									</select>
								</div>
								<div style="display: none" id="projects'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="projects'.$i.'endinput" type="month" class="search-field" style="padding: 10px" name="projects[]" value="" />
								</div>
								
								';
						}
						else
							echo '
								<div style="display: inline-block;padding-right: 150px">
									<label>Are you still working ?</label>
									<select style="padding: 10px" required onchange="yesnoCheck(this);" id="projects'.$i.'" name="projects[]">
										<option value="">Select Option</option>
										<option value="Present">Yes</option>
										<option selected value="No">No</option>
									</select>
								</div>
								<div style="display: inline-block" id="projects'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="projects'.$i.'endinput" type="month" class="search-field" style="padding: 10px" max="'.$current.'" name="projects[]" value="'.$projects[$i][3].'" min = "'.$projects[$i][2].'" required />
								</div>
							
							';
					
					echo '
				
					<textarea required class="search-field" rows="3" style="resize: none" name="projects[]" maxlength="255" title="Maxlength of 255" placeholder="About the Project">'.$projects[$i][4].'</textarea>			
								
			</div>
									  ';
									}
								?>
								</div>
								<a href="javascript:void(0)" onClick="addInput3('projects');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
						</div>
						<button type="submit" name="project">Save</button>
							</form>	
					</div>
				</div>
			</div>
			
			<!--projects end -->
			<!-- portfolio work -->
			<div class="form with-line">
			<h5>Work Samples</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
							<h3 class="panel-title">Work Samples</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
							<form method="post" autocomplete="off">
								<!-- Adding dynamic boxes -->
								<?php $links = json_decode($roww['links']); ?>
								<div id="profiles">
									<label>Blog Link:</label>
									<input type="text" class="search-field" name="blog" placeholder="http://myblog.com" maxlength="150" value="<?php echo $links[2][1] ?>" style="color: #f57d00" pattern="https?://.+" title="Include http://" >
									<label>GitHub Profile:</label>
									<input type="text" class="search-field" name="github" placeholder="http://github.com/my_profile" maxlength="150" pattern="https?://www.github.com/.+" value="<?php echo $links[1][1] ?>" style="color: #6cc644" title="Include https?://www.github.com/">
									<label>Other Portfolio Link:</label>
									<input type="text" class="search-field" name="portfolio" placeholder="https://myportfolio.com" maxlength="150" pattern="https?://.+" value="<?php echo $links[3][1] ?>" style="color: #ff5454" title="Include https?://." >
									<label>LinkedIn Profile:</label>
									<input type="text" class="search-field" name="linkedin" pattern="https?://www.linkedin.com/in/.+" placeholder="https://www.linkedin.com/in/my_profile" maxlength="150" value="<?php echo $links[0][1] ?>" style="color: #0077b5" title="Include https?://www.linkedin.com/in/" >
								</div>
								
						</div>
						<button type="submit" name="profiles">Save</button>
							</form>
					</div>
				</div>
			</div>
			<!--portfolio work ends -->
			
			<!--education starts-->
			<div class="form with-line">
			<h5>Education</h5>
				<div class="form-inside">
					<div class="panel panel-success">
						<div class="panel-heading">
							<h3 class="panel-title">Total <?php echo count(json_decode($roww['education'])) ?> Education</h3>
							<span class="pull-right clickable" ><i class="fa fa-minus-square"></i></span>
						</div>
						<div class="panel-body">
							<form method="post" autocomplete="off">
								<!-- Adding dynamic boxes -->
								
								<div id="education">
									<?php
									$education = json_decode($roww['education']);
									for($i=0;$i<count($education);$i++)
									{
									  echo '
									  	<div class="form boxed ">
				<a href="#" class="close-form remove-box button"><i class="fa fa-close"></i></a>
				<label>School/College</label>
				<input type="text" class="search-field" placeholder="School/College Name" name="education[]" maxlength = "255" required value="'.$education[$i][0].'" >
				<label>Degree</label>
				<input type="text" class="search-field" maxlength="255" id="degreetags'.$i.'" name="education[]" value="'.$education[$i][1].'" data-onload="tagger(this.id)" >
				<label>Field of Study</label>
				<input type="text" class="search-field" maxlength="255" id="branchtags'.$i.'" name="education[]" value="'.$education[$i][2].'" data-onload="badgers(this.id)" >
				<label>Grade</label>
				<input type="number" class="search-field" min="0.1" placeholder="On a Scale of 10" max="10" step="0.1" name="education[]" value="'.$education[$i][3].'" required >
				
				<div style="display: inline-block;padding-right: 137px">
					<label>Enter Joining date </label>
					<input id="education'.$i.'startinput" type="number" min="1970" class="search-field" style="padding: 10px" required name="education[]" onchange="checkdatez(this,'.$i.');" value="'.$education[$i][4].'" max="'.$current_year.'"  />
				</div>
				'; 
						if($education[$i][5] == 'Present')
						{
							echo '<div style="display: inline-block;padding-right: 137px">
									<label>Are you still in this Course ?</label>
									<select class="chosen-select" required onchange="yesnoCheck(this);" id="education'.$i.'" name="education[]">
										<option value="">Select Option</option>
										<option selected value="Present">Yes</option>
										<option value="No">No</option>
									</select>
								</div>
								<div style="display: none" id="education'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="education'.$i.'endinput" type="number" class="search-field" style="padding: 10px" name="education[]" value="" />
								</div>
								
								';
						}
						else
							echo '
								<div style="display: inline-block;padding-right: 137px">
									<label>Are you still in this Course ?</label>
									<select style="padding: 10px" required onchange="yesnoCheck(this);" id="education'.$i.'" name="education[]">
										<option value="">Select Option</option>
										<option value="Present">Yes</option>
										<option selected value="No">No</option>
									</select>
								</div>
								<div style="display: inline-block" id="education'.$i.'enddiv">
									<label>Enter Ending date </label>
									<input id="education'.$i.'endinput" type="number" class="search-field" style="padding: 10px" name="education[]" value="'.$education[$i][5].'" min="'.$education[$i][4].'" max="'.$current_year.'"  required />
								</div>
							
							';
					
					echo '</div>
									  ';
									}
								?>
								</div>
								
								<a href="javascript:void(0)" onClick="addInput4('education');" class="button gray "><i class="fa fa-plus-circle"></i> Add More</a>
						</div>
						<button type="submit" name="educations">Save</button>
							</form>
					</div>
				</div>
			</div>
			<!-- education ends-->
		</div>
	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<!--sweetalert-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">
<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

<!--taginputs-->
<link rel="stylesheet" href="assets/bootstrap-tagsinput.css">
<link rel="stylesheet" href="assets/bootstrap.min.css">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap-theme.min.css"> -->
<link rel="stylesheet" href="http://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/assets/app.css">

<!--typeahead-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.11.1/typeahead.bundle.min.js"></script>
<script src="http://bootstrap-tagsinput.github.io/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>

<!--location -->
<script src="assets/location.js"></script>
<script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

<script>
	var citynames = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		prefetch: {
			url: 'assets/skill.js',
			filter: function(list) {
				return $.map(list, function(cityname) {
							return { name: cityname }; });
				}
		}
	});
	citynames.initialize();
	$('#skills').tagsinput({
		typeaheadjs: {
			name: 'citynames',
			displayKey: 'name',
			valueKey: 'name',
			source: citynames.ttAdapter()
		}
	});
</script>

<!-- JS file -->
<script src="assets/jquery.easy-autocomplete.min.js"></script> 
<!-- CSS file -->
<link rel="stylesheet" href="assets/easy-autocomplete.min.css"> 

<script>
$(document).on('click', '.panel-heading span.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.closest('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-minus-square').addClass('fa fa-plus-square ');
	} else {
		$this.closest('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('fa fa-plus-square').addClass('fa fa-minus-square');
	}
})	
</script>

<script>
	var work = '<?php echo count(json_decode($roww['work'])) ?>';
	var projects = '<?php echo count(json_decode($roww['projects'])) ?>';
	var education = '<?php echo count(json_decode($roww['education'])) ?>';
	var all = new Date();
	var m = all.getMonth();
	if(m<10)
		m = '0'+(m+1);
	var y = all.getFullYear();
	
	function addInput1(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed'><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><textarea required class='search-field' rows='2' style='resize: none' name='acheivement[]' maxlength='255' title='Maxlength of 255'></textarea></div>";
        document.getElementById(divName).appendChild(newdiv);
	}
	function addInput2(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed '><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><input class='search-field' type='text' placeholder='Job Title' pattern='[A-Za-z\\s]{3,100}' required name='work[]' /><input class='search-field' type='text' placeholder='Company Name' pattern='[A-Za-z\\s]{3,255}' required name='work[]' /><input class='search-field' type='text' id='worktags"+work+"' value='' required name='work[]' id='tags' maxlength='50' /><div style='display: inline-block;padding-right: 150px'><label>Enter Joining date </label><input id='work"+work+"startinput' type='month' class='search-field' style='padding: 10px' value="+y+"-"+m+" max="+y+"-"+m+" onchange='checkdate(this,"+work+");' required name='work[]' /></div><div style='display: inline-block;padding-right: 150px'><label>Are you still working ?</label><select id='work"+work+"' style='padding: 10px' required onchange='yesnoCheck(this);' name='work[]'><option value=''>Select Option</option><option value='Present'>Yes</option><option value='No'>No</option></select></div><div style='display: none' id='work"+work+"enddiv'><label>Enter Ending date </label><input id='work"+work+"endinput' type='month' class='search-field' style='padding: 10px' max="+y+"-"+m+" name='work[]' /></div><textarea required class='search-field' rows='2' style='resize: none' name='work[]' maxlength='255' title='Maxlength of 255' placeholder='About the Work/Role'></textarea></div>";
        document.getElementById(divName).appendChild(newdiv);
		locations("worktags"+work);
		work++;
	}
	function addInput3(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed '><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><input class='search-field' type='text' placeholder='Project Title' maxlength='100' required name='projects[]'/><label>Project Url if any ?</label><input class='search-field' type='text' placeholder='Projects URL' pattern='https?://.+' required name='projects[]' maxlength = '150' /><div style='display: inline-block;padding-right: 150px'><label>Enter Joining date </label><input id='projects"+projects+"startinput' type='month' class='search-field' style='padding: 10px' value="+y+"-"+m+" max="+y+"-"+m+" onchange='checkdates(this,"+projects+");' required name='projects[]' /></div><div style='display: inline-block;padding-right: 150px'><label>Are you still working ?</label><select id='projects"+projects+"' style='padding: 10px' required onchange='yesnoCheck(this);' name='projects[]'><option value=''>Select Option</option><option value='Present'>Yes</option><option value='No'>No</option></select></div><div style='display: none' id='projects"+projects+"enddiv'><label>Enter Ending date </label><input id='projects"+projects+"endinput' type='month' class='search-field' style='padding: 10px' max="+y+"-"+m+" name='projects[]' /></div><textarea required class='search-field' rows='3' style='resize: none' name='projects[]' maxlength='255' title='Maxlength of 255' placeholder='About the Projects ?'></textarea></div>";
        document.getElementById(divName).appendChild(newdiv);
		projects++;
	}
	
	function addInput4(divName){
		var newdiv = document.createElement('div');
        newdiv.innerHTML = "<div class='form boxed '><a href='#' class='close-form remove-box button'><i class='fa fa-close'></i></a><label>School/College</label><input type='text' class='search-field' maxlength='255' placeholder='School/College Name' name='education[]' required ><label>Degree</label><input type='text' class='search-field' maxlength='255' id='degreetags"+education+"' name='education[]' ><label>Field of Study</label><input type='text' class='search-field' maxlength='255' id='branchtags"+education+"' name='education[]' ><label>Grade</label><input type='number' class='search-field' min='0.1' placeholder='On a Scale of 10' max='10' step='0.1' name='education[]' required ><div style='display: inline-block;padding-right: 137px'><label>Enter Joining Year </label><input id='education"+education+"startinput' type='number' class='search-field' style='padding: 10px' min='1970' max="+y+" onchange='checkdatez(this,"+education+");' required name='education[]' /></div><div style='display: inline-block;padding-right: 137px'><label>Are you still in this Course ?</label><select id='education"+education+"' style='padding: 10px' required onchange='yesnoCheck(this);' name='education[]'><option value=''>Select Option</option><option value='Present'>Yes</option><option value='No'>No</option></select></div><div style='display: none' id='education"+education+"enddiv'><label>Enter Ending Year </label><input id='education"+education+"endinput' type='number' class='search-field' style='padding: 10px' max="+(y+8)+" name='education[]' /></div></div>";
        document.getElementById(divName).appendChild(newdiv);
		tagger("degreetags"+education);
		badgers("branchtags"+education);
		education++;
	}
	
	function yesnoCheck(that) {
        if (that.value == "No") {
          document.getElementById(that.id + 'enddiv').style.display = 'inline-block';
          document.getElementById(that.id + 'endinput').required = true;
        } else {
          document.getElementById(that.id + 'enddiv').style.display = 'none';
          document.getElementById(that.id + 'endinput').required = false;
        }
    }
	function checkdate(them,val){
		document.getElementById('work'+val+'endinput').setAttribute("min",them.value);
		document.getElementById('work'+val+'endinput').setAttribute("max",y+'-'+m);
	}
	function checkdates(them,val){
		document.getElementById('projects'+val+'endinput').setAttribute("min",them.value);
	}
	function checkdatez(them,val){
		document.getElementById('education'+val+'endinput').setAttribute("min",them.value);
		document.getElementById('education'+val+'endinput').setAttribute("max",(y));
		document.getElementById('education'+val+'startinput').setAttribute("max",y);
	}
	
	var options = {
	url: "assets/location.js",
		placeholder: "Enter Location",
		list: {
			maxNumberOfElements: 6,
			match: {
				enabled: true
			}
		}
	};
	
	var degree = {
	url: "assets/degree.js",
		placeholder: "Degree (ex: Bachelor's)",
		list: {
			maxNumberOfElements: 6,
			match: {
				enabled: true
			}
		}
	};
	
	var branch = {
	url: "assets/branch.js",
		placeholder: "Branch (ex: Information Technology)",
		list: {
			maxNumberOfElements: 6,
			match: {
				enabled: true
			}
		}
	};
	
	
	function badgers(loge){
		$("#"+loge).easyAutocomplete(branch);
	}
	function tagger(logee){
		$("#"+logee).easyAutocomplete(degree);
	}
	function locations(loged){
		$("#"+loged).easyAutocomplete(options);
	}
	
	$('[data-onload]').each(function(){
    	eval($(this).data('onload'));
	});
	
	
	
</script>

</body>

</html>