<?php
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
	
	//echo $_SESSION['userData'];
	$stmt = $db->prepare("SELECT name, email, phone, gender, picture, oauth_provider FROM users_login WHERE oauth_uid = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res->fetch_assoc();
	$stmt->free_result();
	
	//fetchin users_profile info
	$stmt = $db->prepare("SELECT * FROM users_profile WHERE username = ?");
	$stmt->bind_param("s",$_SESSION['userData']);
	$stmt->execute();
	$res = $stmt->get_result();
	$roww = $res->fetch_assoc();
	$stmt->free_result();
	
	//getting hashed password
	$options = [
	'cost' => 11,
	];
	$link = password(10);
	$link_hash = password_hash($link, PASSWORD_BCRYPT, $options);
	
}
else{
	header('Location: ../../login.php');
}
//function to produce a random number password by using md5 algo
function password($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
{
    $str = '';
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $str .= $keyspace[random_int(0, $max)];
    }
  return $str;
}
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$err = "";
	
	$name = test_input(ucname($_POST["name"]));
	$gender = test_input($_POST["gender"]);
	$phone = test_input($_POST["phone"]);
	$email = test_input(mb_strtolower($_POST["email"]));
	$state = test_input($_POST["state"]);
	$city = test_input(ucfirst($_POST["city"]));
	$address =  mysqli_real_escape_string($db, test_input($_POST["address"]));
	
	//start validating inputs 
	$states = array("Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra", "Manipur","Meghalaya", "Mizoram","Nagaland","New Delhi","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu", "Telangana", "Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Union Territory");
	
	//name
	if(isset($name) && !empty($name)  && preg_match("/^[a-zA-Z ]*$/",$name) && (strlen($name) >9) && (strlen($name) < 101)){
	}
	else
		$err = $err . "Only Alphabets and white space allowed </br>";
	
	//gender
	if(isset($gender) && !empty($gender) && ($gender == 'male' || $gender == 'female')){	
	}
	else
		$err = $err . "Only Male and Female options are allowed </br>";
	
	//phone
	if(isset($phone) && !empty($phone) && preg_match("/^[0-9]*$/",$phone)){
	}
	else
		$err = $err . "Only Numbers are allowed </br>";
	
	//email
	if(isset($email) && !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) && (strlen($email) >10) && (strlen($email) < 255) ){
	}
	else
		$err = $err . "Invalid Email address </br>";
	
	//state
	if(isset($state) && !empty($state) && in_array($state, $states)){	
	}
	else
		$err = $err . "Only Available States are allowed </br>";
	
	//city
	if(isset($city) && !empty($city) && preg_match("/^[a-zA-Z ]*$/",$city)){
	}
	else
		$err = $err . "Only Alphabets are allowed </br>";
	
	//now we have validate all inputs then just go inside 
	if($err == "")
	{
		//first we will try to figure out about the users
		//if he is from facebook/google the only state, phone and address will update
		if($row['oauth_provider'] != 'normal')
		{
			//if he has update more than these then show him message
			if($name == $row['name'] && $email == $row['email'] && $gender == $row['gender'])
			{
				$flag = 0;
				if (($stmt = $db->prepare("UPDATE users_login SET phone = ? WHERE oauth_uid = ? "))) {
					if($stmt->bind_param("ss", $phone,$_SESSION['userData'])) {
						if ($stmt->execute()) {
							if(($stmtt = $db->prepare("UPDATE users_profile SET state = ?, city = ?, address = ?  WHERE username = ? "))){
								if($stmtt->bind_param("ssss", $state, $city, $address,$_SESSION['userData'])){
									if($stmtt->execute()){
										header("Location: index.php");	
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;

				if($flag == 1)
				{
					$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>";
				}  	 
			}
			else
				$err = $err . 'You have loggedIn using ' . $row['oauth_provider'] . ' and you can only update phone and address </br>';
		}
		
		//if he is a normal user then first check that did
		if($row['oauth_provider'] == 'normal')
		{
			//if email is not changed then just update the stuff
			//get image
			//starting profile pic coding
			$imgFile = $_FILES['file']['name'];
			$tmp_dir = $_FILES['file']['tmp_name'];
			$imgSize = $_FILES['file']['size'];
		
		  	if($imgFile)
  			{
   				$upload_dir = '../user_pictures/'; // upload directory 
   				$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
   				$valid_extensions = array('jpeg', 'jpg', 'png'); // valid extensions
   				$userpic = $_SESSION['userData'].".".$imgExt;
   				if(in_array($imgExt, $valid_extensions))
   				{   
   					if($imgSize < 1048576)
    				{	// don't want to delete the default pic
						if($row['picture'] != "default.png"){
    						unlink($upload_dir.$row['picture']);
						}
     					move_uploaded_file($tmp_dir,$upload_dir.$userpic);
    				}
    				else{
     					$err = "Sorry, your file is too large it should be less then 1 Mb";
    				}
   				}
   				else{
    				$err = "Sorry, only JPG, JPEG, PNG files are allowed.";  
   				} 
  			}
  			else{
   				// if no image selected the old image remain as it is.
   				$userpic = $row['picture']; // old image from database
  			}
			/* profile pic coading ends here */
			
			//if email and phone is not changed then just do a regular update
			if($row['email'] == $email && $row['phone'] == $phone)
			{
				$flag = 0;
				if (($stmt = $db->prepare("UPDATE users_login SET name = ?, email = ?, gender = ?, phone = ?, picture = ?  WHERE oauth_uid = ? "))) {
					if($stmt->bind_param("ssssss", $name, $email, $gender, $phone, $userpic, $_SESSION['userData'])) {
						if ($stmt->execute()) {
							if(($stmtt = $db->prepare("UPDATE users_profile SET state = ?, city = ?, address = ?  WHERE username = ? "))){
								if($stmtt->bind_param("ssss", $state, $city, $address,$_SESSION['userData'])){
									if($stmtt->execute()){
										header("Location: index.php");	
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;

				if($flag == 1){
					$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>";
				}  	 
			}
			
			//if phone is changed only
			if($row['phone'] != $phone)
			{
				$count = 0;

				$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
				$stm->bind_param("s",$phone);
				$stm->execute();
				$stm->store_result();
				$count = $stm->num_rows;
				$stm->free_result();
				
				if($count == 0)
				{
					$flag = 0;
					
					if (($stmt = $db->prepare("UPDATE users_login SET name = ?, email = ?, gender = ?, phone = ?, picture = ?  WHERE oauth_uid = ? "))) {
					//echo "Prepare failed: (" . $db->errno . ") " . $db->error;
					if($stmt->bind_param("ssssss", $name, $email, $gender, $phone, $userpic, $_SESSION['userData'])) {
						if ($stmt->execute()) {
							if(($stmtt = $db->prepare("UPDATE users_profile SET state = ?, city = ?, address = ?  WHERE username = ? "))){
								if($stmtt->bind_param("ssss", $state, $city, $address,$_SESSION['userData'])){
									if($stmtt->execute()){
										header("Location: index.php");	
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;
						}
						else
							$flag = 1;
					}
					else
						$flag = 1;
				}
				else
					$flag = 1;

					if($flag == 1){
						$err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue </br>";
					}  	 
				}
				else{
					$err = $err . "Phone is already registered !";
				}
			}
			
			//if email is changed only
			if($row['email'] != $email)
			{
				$count = 0;
				$stm = $db->prepare("SELECT email FROM users_login WHERE email = ? ");
				$stm->bind_param("s",$email);
				$stm->execute();
				$stm->store_result();
				$count = $stm->num_rows;
				$stm->free_result();
				
				if($count == 0)
				{
					//first check that whether alredy he done it or not
					$count = 0;
					$stm = $db->prepare("SELECT link FROM change_email WHERE username = ? ");
					$stm->bind_param("s",$_SESSION['userData']);
					$stm->execute();
					$stm->store_result();
					$count = $stm->num_rows;
					$stm->free_result();
					//if first time then insert a new record

					if($count == 0)
					{
						$flag = 0;
						  /* Prepared statement, stage 1: prepare */
							if (($stmt = $db->prepare("INSERT INTO change_email(username, link,new_email,start_time,end_time) VALUES (?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP + INTERVAL '3:00' HOUR_MINUTE)"))) {
								if ($stmt->bind_param("sss",$_SESSION['userData'],$link_hash,$email)) {
									if ($stmt->execute()) {
										
										echo '<script type="text/javascript">';
										echo 'setTimeout(function () { swal("Link Sent !","A link has been sent to your mail and will be active for 3 hours from now !","success");';
										echo '}, 100);</script>';
										
										$_SESSION['change_email'] = true;
										$_SESSION['email'] = $email;
										$_SESSION['name'] = $row['name'];
										$_SESSION['ssl'] = $link_hash;
										$_SESSION['page'] = '../dashboard/user/index.php';
										
										echo "<script>setTimeout(\"location.href = '../../email/change_email.php';\",100);</script>";
										
									}
									else
										$flag = 1;
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;

						  if($flag == 1)
						  {
							  $err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
						  }	
					}
					//if not then check for 3 hours and then update the row and send email
					else if($count == 1)
					{
						//first check the row that he is under 3 hours or not
						$count = 0;
						$stm = $db->prepare("SELECT username FROM change_email WHERE username = ? AND CURRENT_TIMESTAMP > start_time AND CURRENT_TIMESTAMP < end_time ");
						$stm->bind_param("s",$_SESSION['userData']);
						$stm->execute();
						$stm->store_result();
						$count = $stm->num_rows;
						$stm->free_result();
						
						//if count=1 then don't send email
						if($count == 1)
						{
							//get his email address details
							$stm = $db->prepare("SELECT new_email FROM change_email WHERE username = ? ");
							$stm->bind_param("s",$_SESSION['userData']);
							$stm->execute();
							$one = $stm->get_result()->fetch_object()->new_email;
							$stm->free_result();
							
							$err = $err . "We have already sent a email on ".$one." <br/> You need to wait for 3 hours to get a new activation link !";
						}
						else if($count == 0)
						{	
							//now 3 hour wait is over and we will change the last info and send new mail
							$flag = 0;
							if (($stmt = $db->prepare("UPDATE change_email SET link = ?, new_email = ? ,start_time = CURRENT_TIMESTAMP,end_time = CURRENT_TIMESTAMP + INTERVAL '3:00' HOUR_MINUTE WHERE username = ? "))) {
								if ($stmt->bind_param("sss",$link_hash,$email,$_SESSION['userData'])) {
									if ($stmt->execute()) {
										
										echo '<script type="text/javascript">';
										echo 'setTimeout(function () { swal("Link Sent !","A link has been sent to your mail and will be active for 3 hours from now !","success");';
										echo '}, 100);</script>';
										
										$_SESSION['change_email'] = true;
										$_SESSION['email'] = $email;
										$_SESSION['name'] = $row['name'];
										$_SESSION['ssl'] = $link_hash;
										$_SESSION['page'] = '../dashboard/user/index.php';
										
										echo "<script>setTimeout(\"location.href = '../../email/change_email.php';\",100);</script>";
										
									}
									else
										$err = $err . "Prepare failed: ('. $db->errno . ')'.$db->error.'";
								}
								else
									$flag = 1;
							}
							else
								$flag = 1;

						  if($flag == 1)
						  {
							  $err = $err . "Sorry Something Went Wrong While Processing Your Request. Please Contact Developer About this Issue !";
						  }
						}
					}
				}
				else{
					$err = $err . "Email is already registered !";
				}
			}
		}
		
		
	}
	if($err != ""){
		echo '<script type="text/javascript">';
		echo 'setTimeout(function () { swal("Error !","'.$err.'","error");';
		echo '}, 100);</script>';
	}
}
//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
//function to change the lowercase data to capitalize the first letter of every word
function ucname($string) {
    $string =ucwords(strtolower($string));

    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>
<!-- Favicon Icon Css
================================================== -->
<link rel="apple-touch-icon" sizes="180x180" href="../../favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../favicons/favicon-16x16.png">
<link rel="manifest" href="../../favicons/manifest.json">
<link rel="mask-icon" href="../../favicons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title><?php echo $row['name'] ?> | Profile</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="../../css/style.css">
<link rel="stylesheet" href="../../css/colors/green.css" id="colors">

<script src="../../scripts/errors/sweetalert2.min.js"></script>
<link rel="stylesheet" href="../../scripts/errors/sweetalert2.min.css">

<!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
<script src="../../scripts/errors/core.js"></script>

<style>
	.image {
  		display: block;
  		width: 150px;
  		height: 150px;
  		margin: 1em auto;
  		background-size: cover;
  		background-repeat: no-repeat;
  		background-position: center center;
  		-webkit-border-radius: 99em;
  		-moz-border-radius: 99em;
  		border-radius: 99em;
 		border: 5px solid #eee;
  		box-shadow: 0 3px 2px rgba(0, 0, 0, 0.3);  
	}
	.errspan {
    float: right;
    margin-right: 6px;
    margin-top: -40px;
    position: relative;
    z-index: 3;
	}
	
</style>
			

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div id="wrapper">


<!-- Header
================================================== -->
<header class="sticky-header">
<div class="container">
	<div class="sixteen columns">
		<!-- Logo -->
		<div id="logo">
			<h1><a href="../../index.php"><img src="../../images/logo.png" alt="CareerStairs Logo" /></a></h1>
		</div>

		<!-- Menu -->
		<nav id="navigation" class="menu">
			<ul id="responsive">
				<li><a href="index.php" >Home</a></li>
				<li><a href="profile.php" id="current">Profile</a></li>
				<li><a href="#">Resume</a>
					<ul>
						<li><a href="resume.php">View Resume</a></li>
						<li><a href="edit_resume.php">Edit Resume</a></li>
					</ul>
				</li>
				<li><a href="skills_match_jobs.php">Browse Jobs</a></li>
				<li><a href="applied_jobs.php">Applied Jobs</a></li>
				<li><a href="#"><?php echo $row['name'] ?></a>
					<ul>
						<li><a href="coupons.php"><i class="fa fa-sun-o"></i> Coupons</a></li>
						<?php if($row['oauth_provider'] == 'normal')
							{
								echo '<li><a href="change_password.php"><i class="fa fa-map-pin"></i> Change Password</a></li>';
							}
						?>
						
						<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
			<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
		</div>

	</div>
</div>
</header>
<div class="clearfix"></div>


<!-- Titlebar
================================================== -->
<div id="titlebar" class="photo-bg" style="background: url(../../images/polygon_3-wallpaper-1366x768.jpg)">
	<div class="container">
		<div class="ten columns">
			<h2><i class="fa fa-adjust"></i> Edit Profile </h2>
		</div>
	</div>
</div>

<!-- Content
================================================== -->
<div class="container">
	
	<!-- Submit Page -->
	<div class="sixteen columns">
		<div class="submit-page">

		<form autocomplete="off" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" onsubmit="return checkSize(524288)" autocomplete="off" enctype="multipart/form-data">
			<!-- Email -->
			<div class="form">
				<h5>Your Name</h5>
				<input class="search-field" type="text" pattern="[A-Za-z\s]{10,100}" placeholder="Enter Your full name" value="<?php echo $row['name'] ?>" required title="Please Use only Alphabets with a Max length of 100 characters" name="name" style="text-transform: capitalize" />
			</div>

			<!-- Email -->
			<div class="form">
				<h5>Your Email</h5>
				<input class="search-field" type="email" placeholder="mail@example.com" value="<?php echo $row['email'] ?>" maxlength="255" id="email" required style="text-transform: lowercase;" onBlur="checkemail()" name="email" />
				
				<div id="email-loading" class="errspan" style="display: none">
                	<i id="email-i"></i>
                </div>
			</div>

			<!-- gender -->
			
			<div class="form">
				<h5>Gender</h5>
				<select class="chosen-select" required name="gender" >
					<option value="" >Please select your Gender</option>
					<option value="male" <?php echo ($row['gender'] == 'male')?"selected":"" ?> >Male</option>
					<option value="female" <?php echo ($row['gender'] == 'female')?"selected":"" ?> >Female</option>
				</select>
			</div>
			
			<!-- Title -->
			<div class="form">
				<h5>Mobile No</h5>
				<input class="search-field" type="text" placeholder="+91" value="<?php echo $row['phone'] ?>" pattern="^\d{10}$" title="Enter 10 digit Phone number" required  id="phone" name="phone" onBlur="checkphone()" />
				
                <div id="phone-loading" class="errspan" style="display:none">
                	<i id="phone-i"></i>
                </div>
			</div>
			

			<!-- Location -->
			<div class="form">
				<h5>State</h5>
				<select class="chosen-select" required name="state" >
					<option value=""    >Please select your state</option>
					<option value="Andhra Pradesh"  <?php echo ($roww['state'] == 'Andhra Pradesh')?"selected":"" ?> >Andhra Pradesh</option>
					<option value="Arunachal Pradesh"  <?php echo ($roww['state'] == 'Arunachal Pradesh')?"selected":"" ?> >Arunachal Pradesh</option>
					<option value="Assam"  <?php echo ($roww['state']== 'Assam')?"selected":"" ?> >Assam</option>
					<option value="Bihar"  <?php echo ($roww['state'] == 'Bihar')?"selected":"" ?> >Bihar</option>
					<option value="Chhattisgarh"  <?php echo ($roww['state'] == 'Chhattisgarh')?"selected":"" ?> >Chhattisgarh</option>
					<option value="Goa"  <?php echo ($roww['state'] == 'Goa')?"selected":"" ?> >Goa</option>
					<option value="Gujarat"  <?php echo ($roww['state'] == 'Gujarat')?"selected":"" ?> >Gujarat</option>
					<option value="Haryana"  <?php echo ($roww['state'] == 'Haryana')?"selected":"" ?> >Haryana</option>
					<option value="Himachal Pradesh"  <?php echo ($roww['state'] == 'Himachal Pradesh')?"selected":"" ?> >Himachal Pradesh</option>
					<option value="Jammu and Kashmir"  <?php echo ($roww['state'] == 'Jammu and Kashmir')?"selected":"" ?> >Jammu and Kashmir</option>
					<option value="Jharkhand" <?php echo ($roww['state'] == 'Jharkhand')?"selected":"" ?> >Jharkhand</option>
					<option value="Karnataka" <?php echo ($roww['state'] == 'Karnataka')?"selected":"" ?> >Karnataka</option>
					<option value="Kerala" <?php echo ($roww['state'] == 'Kerala')?"selected":"" ?> >Kerala</option>
					<option value="Madhya Pradesh" <?php echo ($roww['state'] == 'Madhya Pradesh')?"selected":"" ?> >Madhya Pradesh</option>
					<option value="Maharashtra" <?php echo ($roww['state'] == 'Maharashtra')?"selected":"" ?> >Maharashtra</option>
					<option value="Manipur" <?php echo ($roww['state'] == 'Manipur')?"selected":"" ?> >Manipur</option>
					<option value="Meghalaya" <?php echo ($roww['state'] == 'Meghalaya')?"selected":"" ?> >Meghalaya</option>
					<option value="Mizoram" <?php echo ($roww['state'] == 'Mizoram')?"selected":"" ?> >Mizoram</option>
					<option value="Nagaland" <?php echo ($roww['state'] == 'Nagaland')?"selected":"" ?> >Nagaland</option>
					<option value="New Delhi" <?php echo ($roww['state'] == 'New Delhi')?"selected":"" ?> >New Delhi</option>
					<option value="Odisha" <?php echo ($roww['state'] == 'Odisha')?"selected":"" ?> >Odisha</option>
					<option value="Punjab" <?php echo ($roww['state'] == 'Punjab')?"selected":"" ?> >Punjab</option>
					<option value="Rajasthan" <?php echo ($roww['state'] == 'Rajasthan')?"selected":"" ?> >Rajasthan</option>
					<option value="Sikkim" <?php echo ($roww['state'] == 'Sikkim')?"selected":"" ?> >Sikkim</option>
					<option value="Tamil Nadu" <?php echo ($roww['state'] == 'Tamil Nadu')?"selected":"" ?> >Tamil Nadu</option>
					<option value="Telangana" <?php echo ($roww['state'] == 'Telangana')?"selected":"" ?> >Telangana</option>
					<option value="Tripura" <?php echo ($roww['state'] == 'Tripura')?"selected":"" ?> >Tripura</option>
					<option value="Uttar Pradesh" <?php echo ($roww['state'] == 'Uttar Pradesh')?"selected":"" ?> >Uttar Pradesh</option>
					<option value="Uttarakhand" <?php echo ($roww['state'] == 'Uttarakhand')?"selected":"" ?> >Uttarakhand</option>
					<option value="West Bengal" <?php echo ($roww['state'] == 'West Bengal')?"selected":"" ?> >West Bengal</option>
					<option value="Union Territory" <?php echo ($roww['state'] == 'Union Territory')?"selected":"" ?> >Union Territory</option>
    			</select>
			</div>
			
			<div class="form">
				<h5>City</h5>
				<input class="search-field" pattern="[A-Za-z]{2,50}" type="text" placeholder="Enter your City" value="<?php echo $roww['city'] ?>" name="city" required style="text-transform: capitalize" />
			</div>
			
			 <script>
 			 	var loadFile = function(event) {
    				var output = document.getElementById('output');
    				output.src = URL.createObjectURL(event.target.files[0]);
  					};
  			</script>
			
			<!-- pic show -->
			<img class="image" id="output">
			
			<!-- Logo -->
			<div class="form">
				<h5>Photo <span>(optional)</span></h5>
				<label class="upload-btn">
				    <input type="file" accept="image/*" onchange="loadFile(event)" id="upload" name="file" />
				    <i class="fa fa-upload"></i> Browse
				</label>
				<span class="fake-input">No file selected</span>
			</div>


			<!-- Description -->
			<div class="form">
				<h5>Address</h5>
				<textarea name="address" rows="1" style="resize:none" required spellcheck="true" maxlength="255" ><?php echo $roww['address'] ?></textarea>
			</div>


			<div class="divider margin-top-0 padding-reset"></div>
			<button class="button big margin-top-5" type="submit">Save <i class="fa fa-arrow-circle-right"></i></button>
			
			</form>
		</div>
	</div>

</div>


<!-- Footer
================================================== -->
<div class="margin-top-60"></div>

<div id="footer">
	<!-- Main -->
	<div class="container">

		<div class="eight columns" style="padding-right: 50px">
			<h4>About</h4>
			<p style="text-align: justify">CareerStairs is a unique tech-driven platform that aims to revolutionize the way hiring is done. Whether you are a job-seeker or an employer, we help you secure the best of job opportunities and talent. Our unique ranking algorithm helps candidates get noticed by recruiters on one hand while helping recruiters notice the right candidates on the other. Similarly, the ingenious Resume feature enables employers hire wisely while letting candidates showcase the best of their talent.
  			</p>
		</div>
		
	
		<div class="three columns">
			<h4>Company</h4>
			<ul class="footer-links">
				<li><a href="../../about.php">About Us</a></li>
				<li><a href="../../careers.php">Careers</a></li>
				<li><a href="www.blog.careerstairs.in">Our Blog</a></li>
				<li><a href="../../service.php">Terms of Service</a></li>
				<li><a href="../../policy.php">Privacy Policy</a></li>
				<li><a href="../../contact.html">Contact Us</a></li>
			</ul>
		</div>
	
		<div class="three columns">
			<h4>Follow Us</h4>
			<ul class="social-icons">
				<li><a target="_blank" class="facebook" href="https://www.facebook.com/careerstairsin-259421891127990/"><i class="icon-facebook"></i></a></li>
				<li><a target="_blank" class="twitter" href="https://twitter.com/CareerstairsI"><i class="icon-twitter"></i></a></li>
				<li><a target="_blank" class="gplus" href="https://plus.google.com/u/0/109522836028901433584"><i class="icon-gplus"></i></a></li>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/company/18031484/"><i class="icon-linkedin"></i></a></li>
			</ul>
			<br/>
			<br/>
			<br/>
			<div class="copyrights">©  Copyright 2017 by <a href="index.php">CareerStairs</a>. All Rights Reserved.</div>
		</div>
		

	</div>

	<!-- Bottom -->

</div>

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="../../scripts/jquery-2.1.3.min.js"></script>
<script src="../../scripts/custom.js"></script>
<script src="../../scripts/jquery.superfish.js"></script>
<script src="../../scripts/jquery.themepunch.tools.min.js"></script>
<script src="../../scripts/jquery.themepunch.revolution.min.js"></script>
<script src="../../scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="../../scripts/jquery.flexslider-min.js"></script>
<script src="../../scripts/chosen.jquery.min.js"></script>
<script src="../../scripts/jquery.magnific-popup.min.js"></script>
<script src="../../scripts/waypoints.min.js"></script>
<script src="../../scripts/jquery.counterup.min.js"></script>
<script src="../../scripts/jquery.jpanelmenu.js"></script>
<script src="../../scripts/stacktable.js"></script>
<script src="../../scripts/headroom.min.js"></script>

<!-- script to check email duplicasy via ajax -->
<script>
	function checkemail() {
		var name = $("#email").val();
		if(name.length > 10 && name != '<?php echo $row['email'] ?>' )
		{
		$('#email-loading').show();
		$("#email-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
		
		jQuery.ajax({
			url: "ajaxData.php",
			data:'email='+$("#email").val(),
			type: "POST",
			success:function(data){
				if(data == 1) {
					$("#email-i").removeClass();
					$("#email-i").addClass("fa fa-close fa-2x");
					$("#email-i").css("color", "red");
				
				}else{
					$("#email-i").removeClass();
					$("#email-i").addClass("fa fa-check fa-2x");
					$("#email-i").css("color", "green");
				}
				
			},
			error:function (){}
		});
	}
	else{
		$("#email-loading").hide();
		$("#email-i").removeClass();
		$("#email-i").css("color", "");
		if(name.length != 0)
			swal(
			  'Email Seems Incorrect !',
			  'The length of Email Must be more than 10 characters long ',
			  'warning'
		)
	}
}

//<!-- function to check phone duplicasy -->
	
	function checkphone() {
		var name = $("#phone").val();
		if(name.length > 7 && name != '<?php echo $row['phone'] ?>' )
		{
		$('#phone-loading').show();
		$("#phone-i").addClass("fa fa-spinner fa-pulse fa-2x fa-fw");
		
		jQuery.ajax({
			url: "ajaxData.php",
			data:'phone='+$("#phone").val(),
			type: "POST",
			success:function(data){
				if(data == 1) {
					$("#phone-i").removeClass();
					$("#phone-i").addClass("fa fa-close fa-2x");
					$("#phone-i").css("color", "red");
				
				}else{
					$("#phone-i").removeClass();
					$("#phone-i").addClass("fa fa-check fa-2x");
					$("#phone-i").css("color", "green");
				}
				
			},
			error:function (){}
		});
	}
	else{
		$("#phone-loading").hide();
		$("#phone-i").removeClass();
		$("#phone-i").css("color", "");
	}
}
	
	function checkSize(max_img_size)
	{
		var input = document.getElementById("upload");
		// check for browser support (may need to be modified)
		if(input.files && input.files.length == 1)
		{           
			if (input.files[0].size > max_img_size) 
			{
				swal(
					  'Warning',
					  'File Size Must be less than 500 Kb !',
					  'warning'
					)
				return false;
			}
		}
	
		return true;
	}
	
</script>

</body>

</html>