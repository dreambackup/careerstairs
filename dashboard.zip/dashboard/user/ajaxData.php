<?php
//Include database configuration file
include('../../db/config.php');
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['user'] == true) {
}
else{
	header('Location: ../../login.php');
}

// code to check email duplication

if(isset($_POST["email"]) && !empty($_POST["email"])){
    $email = test_input($_POST["email"]);
	$stm = $db->prepare("SELECT email FROM users_login WHERE email = ? ");
	$stm->bind_param("s",$email);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
	
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

// code to check phone duplicasy
if(isset($_POST["phone"]) && !empty($_POST["phone"])){
    $phone = test_input($_POST["phone"]);
	$stm = $db->prepare("SELECT phone FROM users_login WHERE phone = ? ");
	$stm->bind_param("s",$phone);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

// code to check phone duplicasy
if(isset($_POST["username"]) && !empty($_POST["username"])){
    $username = test_input($_POST["username"]);
	$count = 0;
	$stm = $db->prepare("SELECT oauth_uid FROM users_login WHERE oauth_uid = ? ");
	$stm->bind_param("s",$username);
	$stm->execute();
	$stm->store_result();
	$count = $stm->num_rows;
	$stm->free_result();
		
    //Display result list
    if($count > 0){
        echo '1';
    }else{
        echo '0';
    }
}

//function to do validation and triming data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>