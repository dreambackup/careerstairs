

© 2014 CakeMail®. All rights reserved. Designed in Montréal.
Click Me!, 2014


Description:
A template to send  forgotten passwords, confirmation emails, and anything else that require that your contacts take action.

Our Goal
Our goal is to help small businesses. We do this by providing an Email Marketing app (called CakeMail) as well as professional looking templates. 


Like the one you just downloaded.


The short and sweet of it
If you’re a small business, you can use the template, change the content, change the pictures, or keep it as is, and send it off to people who’ve signed up to get your newsletters, your existing customers, current employees or your family.


Although they’ve been optimized for CakeMail, they can be used with any other email marketing service or platform that allows you to paste html code to create emails.


(Everything under the line says pretty much what’s just been summed in two paragraphs, only it’s in Legalese.)


What is CakeMail?
CakeMail 4 is an email marketing application that’s simple to use, regardless of your area of expertise or experience in email marketing.


If you know how to email, you know how to CakeMail.


How do I open a CakeMail account?
Visit cakemail.com and click on Sign up. For more information about plans and pricing, visit cakemail.com/pricing


Questions? Get in touch with us:
Email: support@cakemail.com               
------------------

Who can use these templates?
Any marketer, business owner or small business that intends to use the template for communication with its customers.


Permitted uses
Email Marketing Templates can be downloaded, and the content may customized, manipulated to create a derivative work or left as is. The end result is an email campaign sent through an email marketing service provider, mailing list manager or through an email client. You are licensed to use the template to create an email campaign for yourself. 


You can make any number of copies of an email campaign based of enclosed template, as long as the email campaign is distributed pursuant to CAN SPAM and CASL legislation, and, if applicable, does not breach the terms of use as defined by your email marketing service provider.


You can only use the Item for lawful purposes. You can’t use the template in a way that creates a fake identity, implies personal endorsement of a product by the person, or in a way that is defamatory, obscene or demeaning, or in connection with sensitive subjects.


Prohibited uses
Unlicensed redistribution of templates, for free or for profit, without express, written consent by CakeMail.


Although you can modify the template and therefore delete unwanted components before creating your email campaign, you can’t extract and use a single component of the template (such as an image or sample copy) on a stand-alone basis.


Termination of license
Permission to use the template can be terminated if you breach any terms included but not limited to those enounced herein. If that happens, you must stop making copies of or distributing the email marketing campaign.
CakeMail retains ownership of the template but grants you the license on these terms. This license is between CakeMail, Inc. and you, your business and its representatives.


