<?php
$url = 'https://api.elasticemail.com/v2/email/send';

try{
        $post = array('from' => 'sunnysharma03@live.com',
		'fromName' => 'Carrer Stairs Team',
		'apikey' => 'eb8078c6-c3da-4792-a667-5f592d2f591c',
		'subject' => 'Registration Successfull !',
		'to' => 'sunnysharma03@live.com',
		'bodyHtml' => 'Testing the speed',
		'isTransactional' => false);
		
		$ch = curl_init();
		curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
			CURLOPT_SSL_VERIFYPEER => false
        ));
		
        $result=curl_exec ($ch);
        curl_close ($ch);
		
        echo $result;	
}
catch(Exception $ex){
	echo $ex->getMessage();
}
?>